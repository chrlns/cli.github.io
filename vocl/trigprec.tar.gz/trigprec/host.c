#include <sys/time.h>
#include <stdio.h>
#include <unistd.h>
#include <CL/opencl.h>
#include <memory.h>
#include <math.h>

const char* errorstr(cl_uint error)
{
	switch(error)
	{
		case CL_INVALID_PROGRAM:
			return "CL_INVALID_PROGRAM";
		case CL_INVALID_VALUE:
			return "CL_INVALID_VALUE";
		case CL_INVALID_DEVICE:
			return "CL_INVALID_DEVICE";
		case CL_INVALID_BINARY:
			return "CL_INVALID_BINARY";
		case CL_INVALID_BUILD_OPTIONS:
			return "CL_INVALID_BUILD_OPTIONS";
		case CL_INVALID_OPERATION:
			return "CL_INVALID_OPERATION";
		case CL_COMPILER_NOT_AVAILABLE:
			return "CL_COMPILER_NOT_AVAILABLE";
		case CL_BUILD_PROGRAM_FAILURE:
			return "CL_BUILD_PROGRAM_FAILURE";
	}
	return "UNKNOWN";
}

void randbuf(double* buf, int num)
{
	srand(25);
	for(int n = 0; n < num; n++) {
		buf[n] = rand() / (double)rand();
	}
}

int main(int argc, char* argv[])
{
	const int N = 1024 * 1024 * 16;
	char* kernel_src = malloc(4096);
	double* values = malloc(sizeof(double) * N);

	randbuf(values, N);
 
	FILE* file = fopen("trigprec.cl", "r");
	fread(kernel_src, 1, 4096, file);
	fclose(file);
	kernel_src[4095] = 0;

	cl_platform_id platforms[8];
	cl_uint num_platforms;

	// Query platform(s)
	if(clGetPlatformIDs(8, platforms, &num_platforms) != CL_SUCCESS) {
		printf("clGetPlatformIDs() failed!\n");
		return -1;
	}
	
	// Query devices 
	for(int n = 0; n < num_platforms; n++) {
		cl_device_id devices[8];
		cl_uint num_devices;
		if(clGetDeviceIDs(platforms[n], CL_DEVICE_TYPE_ALL, 8, devices, &num_devices) != CL_SUCCESS) {
			printf("clGetDeviceIDs() failed!\n");
			return -1;
		}
		
		for(int m = 0; m < num_devices; m++) {
			char dev_name[128];
			size_t dev_name_size;
			if(clGetDeviceInfo(devices[m], CL_DEVICE_NAME, 128, dev_name, &dev_name_size) 
				!= CL_SUCCESS) {
				printf("clDeviceInfo() failed!\n");
				return -1;
			}
			printf("OpenCL device: %s\n", dev_name);
			
			cl_uint errorcode;
			cl_context context = clCreateContext(NULL, 1, &(devices[m]), NULL, NULL, &errorcode);
			if(errorcode != CL_SUCCESS) {
				printf("clCreateContext() failed!\n");
				return -1;
			}

			cl_command_queue cmd_queue = clCreateCommandQueue(context, devices[m], 0, &errorcode);
			if(errorcode != CL_SUCCESS) {
				printf("clCreateCommandQueue() failed!\n");
				return -1;
			}

			// Create and build kernel
			cl_program program = 
				clCreateProgramWithSource(context, 1, (const char**)&kernel_src, NULL, &errorcode);
			if(errorcode != CL_SUCCESS) {
				printf("clCreateProgramWithSource() failed!\n");
				return -1;
			}

			errorcode = clBuildProgram(program, 1, devices + m, "", NULL, NULL); 
			if(errorcode != CL_SUCCESS) {
				printf("clBuildProgram() failed: %s\n", errorstr(errorcode));
				if(errorcode == CL_BUILD_PROGRAM_FAILURE) {
					char buf[1024];
					clGetProgramBuildInfo(program, devices[m], CL_PROGRAM_BUILD_LOG, 
						1024, buf, NULL);
					printf("Build log: %s\n", buf);
				}
				return -1;
			}

			cl_kernel kernel = clCreateKernel(program, "trigprec", &errorcode);
			if(errorcode != CL_SUCCESS) {
				printf("clCreateKernel() failed!\n");
				return -1;
			}

			// Set kernel parameters and buffers
			cl_mem input = clCreateBuffer(context, CL_MEM_READ_WRITE, 
				sizeof(double) * N, NULL, &errorcode);
			if(errorcode != CL_SUCCESS) {
				printf("clCreateBuffer() failed!\n");
				return -1;
			}
			if(clEnqueueWriteBuffer(cmd_queue, input, CL_TRUE, 0, 
				sizeof(double) * N, values, 0, NULL, NULL) != CL_SUCCESS) {
				printf("clEnqueueWriteBuffer() failed!\n");
				return;
			}
			if(clSetKernelArg(kernel, 0, sizeof(input), (void*)&input) != CL_SUCCESS) {
				printf("clSetKernelArg() failed!\n");
				return -1;
			}
			
			cl_mem output = clCreateBuffer(context, CL_MEM_READ_WRITE,
				sizeof(double) * N, NULL, &errorcode);
			if(errorcode != CL_SUCCESS) {
				printf("clCreateBuffer() failed!\n");
				return -1;
			}
			if(clSetKernelArg(kernel, 1, sizeof(output), (void*)&output) != CL_SUCCESS) {
				printf("clSetKernelArg() failed!\n");
				return -1;
			}

			// Execute kernels
			printf("Everything prepared. Starting kernel...\n");
			size_t num_glo[1];
			num_glo[0] = N;
			errorcode = clEnqueueNDRangeKernel(
				cmd_queue, 
				kernel, 
				1, // dimension 
				NULL, 
				num_glo, 
				NULL, 
				0, 
				NULL, 
				NULL);

			if(errorcode != CL_SUCCESS) {
				printf("clEnqueueNDRangeKernel() failed!\n");
				return -1;
			}
			
			double* output_buffer = malloc(sizeof(double) * N);
			if(clEnqueueReadBuffer(cmd_queue, output, CL_TRUE, 0, 
				sizeof(double) * N, output_buffer, 0, NULL, NULL) != CL_SUCCESS) {
				printf("clEnqueueReadBuffer() failed!\n");
				return -1;
			}
			
			printf("Enqueued. Waiting for finish...\n");			
			clFinish(cmd_queue);

			printf("Finished. Releasing program...\n");
			if(clReleaseProgram(program) != CL_SUCCESS) {
				printf("clReleaseProgram() failed!\n");
				return -1;
			}

			if(clReleaseCommandQueue(cmd_queue) != CL_SUCCESS) {
				printf("clReleaseCommandQueue() failed!\n");
				return -1;
			}
		}
	}

	free(kernel_src);
	return 0;
}
