#include <stdio.h>
#include <stdlib.h>
#ifndef WIN32
#include <unistd.h>
#include <sys/time.h>
#else
#define __WIN32_WINNT
#include <Windows.h>
#endif
#include <CL/opencl.h>
#include "oldstyle_mdct.h"
#include <memory.h>
#include <time.h>
#include <math.h>

#define KERN_INIT "init"
#define KERN_RESULT "result"
#define KERN_STEP1 "step1"
#define KERN_STEP2 "step2"
#define KERN_STEP3 "step3"
#define KERN_STEP4 "step4"
#define KERN_STEP5 "step5"
#define KERN_STEP6 "step6"
#define KERN_STEP7 "step7"
#define KERN_STEP8 "step8"
#define KERN_TWIDDLEA "twiddleA"
#define KERN_TWIDDLEC "twiddleC"
#define KERN_TWIDDLEB "twiddleB"

// 256 is the maximum on my Radeon HD4870
#define MAX_WORKGROUP_SIZE 256
#define SHIFTS 25 // 2^20 Sample size
#define N (1 << SHIFTS)
#define BITS (SHIFTS - 3) // (n/8)

//#define PROFILING

const char* errorstr(cl_uint error)
{
	switch(error)
	{
		case CL_INVALID_PROGRAM:
			return "CL_INVALID_PROGRAM";
		case CL_INVALID_VALUE:
			return "CL_INVALID_VALUE";
		case CL_INVALID_DEVICE:
			return "CL_INVALID_DEVICE";
		case CL_INVALID_BINARY:
			return "CL_INVALID_BINARY";
		case CL_INVALID_BUILD_OPTIONS:
			return "CL_INVALID_BUILD_OPTIONS";
		case CL_INVALID_OPERATION:
			return "CL_INVALID_OPERATION";
		case CL_COMPILER_NOT_AVAILABLE:
			return "CL_COMPILER_NOT_AVAILABLE";
		case CL_BUILD_PROGRAM_FAILURE:
			return "CL_BUILD_PROGRAM_FAILURE";
		case CL_INVALID_PROGRAM_EXECUTABLE:
			return "CL_INVALID_PROGRAM_EXECUTABLE";
		case CL_INVALID_KERNEL_NAME:
			return "CL_INVALID_KERNEL_NAME";
		case CL_INVALID_KERNEL_DEFINITION:
			return "CL_INVALID_KERNEL_DEFINITION";
		case CL_INVALID_COMMAND_QUEUE:
			return "CL_INVALID_COMMAND_QUEUE";
		case CL_INVALID_KERNEL:
			return "CL_INVALID_KERNEL";
		case CL_INVALID_CONTEXT:
			return "CL_INVALID_CONTEXT";
		case CL_INVALID_KERNEL_ARGS:
			return "CL_INVALID_KERNEL_ARGS";
		case CL_INVALID_BUFFER_SIZE:
			return "CL_INVALID_BUFFER_SIZE";
		case CL_INVALID_HOST_PTR:
			return "CL_INVALID_HOST_PTR";
		case CL_INVALID_WORK_DIMENSION:
			return "CL_INVALUD_WORK_DIMENSION";
		case CL_INVALID_GLOBAL_WORK_SIZE:
			return "CL_INVALID_GLOBAL_WORK_SIZE";
		case CL_INVALID_GLOBAL_OFFSET:
			return "CL_INVALID_GLOBAL_OFFSET";
		case CL_INVALID_WORK_GROUP_SIZE:
			return "CL_INVALID_WORK_GROUP_SIZE";
		case CL_INVALID_WORK_ITEM_SIZE:
			return "CL_INVALID_WORK_ITEM_SIZE";
	}
	return "UNKNOWN";
}

void randbuf(float* buf, int num)
{
	int n;
	srand(25);
	for(n = 0; n < num; n++) {
		buf[n] = (float)(rand() % 255);
	}
}

float bufsum(float* buf, int num)
{
	float sum = buf[0];
	for(int n = 1; n < num; n++) {
		sum += buf[n];
	}
	return sum;
}


double bufdiff(float* buf0, float* buf1, int num)
{
	double diff = 0;
	for(int n = 0; n < num; n++) {
		diff += abs(buf0[n] - buf1[n]);
	}
	return diff / num;
}

cl_device_id get_first_device(cl_device_type type)
{
	cl_platform_id platforms[8];
	cl_uint num_platforms;

	// Query platform(s)
	if(clGetPlatformIDs(8, platforms, &num_platforms) != CL_SUCCESS) {
		printf("clGetPlatformIDs() failed!\n");
		return NULL;
	}
	
	printf("%d platform(s) found!\n", num_platforms);

	for(cl_uint n = 0; n < num_platforms; n++) {
		cl_device_id devices[1];
		cl_uint num_devices;
		cl_int retcode = clGetDeviceIDs(platforms[n], type, 1, devices, &num_devices);
		if(retcode == CL_SUCCESS) {
			char dev_name[128];
			size_t dev_name_size;
			if(clGetDeviceInfo(devices[0], CL_DEVICE_NAME, 128, dev_name, &dev_name_size) 
				!= CL_SUCCESS) {
				printf("clDeviceInfo() failed!\n");
				return NULL;
			}
			printf("OpenCL device: %s\n", dev_name);
			return devices[0];
		} else if(retcode != CL_DEVICE_NOT_FOUND) {
			printf("glGetDeviceIDs() failed!\n");
			return NULL;
		}
	}
	return NULL;
}

cl_program create_program(const char* filename, cl_context context, cl_device_id device)
{
	cl_int errorcode;
	
	// Read kernel source
	char* buf = (char*)malloc(sizeof(char) * 4096 * 2);
	FILE* file = fopen(filename, "r");
	if(!file) {
		return NULL;
	}
	
	int len = 0;
	while(!feof(file)) {
		int r = fread(buf + len, sizeof(char), 4096 * 2 - len, file);
		len += r;
	}
	fclose(file);
	buf[len] = 0;	
	
	cl_program program = 
		clCreateProgramWithSource(context, 1, (const char**)&buf, NULL, &errorcode);
	if(errorcode != CL_SUCCESS) {
		printf("clCreateProgramWithSource() failed!\n");
		return NULL;
	}
	
	// if device is not given to clBuildProgram, the kernel is build
	// for all devices associated with the program's context
	errorcode = clBuildProgram(program, 0, NULL, "", NULL, NULL); 
	if(errorcode != CL_SUCCESS) {
		printf("clBuildProgram('%s') failed: %s\n", filename, errorstr(errorcode));
		if(errorcode == CL_BUILD_PROGRAM_FAILURE) {
			char* log = (char*)malloc(1024 * 1024);
			size_t retsize;
			errorcode = clGetProgramBuildInfo(program, device, CL_PROGRAM_BUILD_LOG, 1024 * 1024
				, log, &retsize);
			if(errorcode == CL_SUCCESS) {
				log[retsize - 1] = 0;
				printf("Build log ('%s'): %s\n", filename, log);
			} else {
				printf("clGetProgramBuildInfo() failed: %s\n", errorstr(errorcode));
			}
		}
		free(buf);
		return NULL;
	}
	free(buf);
	return program;
}

cl_kernel create_kernel(const char* func_name, cl_program program)
{
	cl_int errorcode;

	cl_kernel kernel = clCreateKernel(program, func_name, &errorcode);
	if(errorcode != CL_SUCCESS) {
		printf("clCreateKernel('%s') failed: %s\n", func_name, errorstr(errorcode));
		return NULL;
	}

	return kernel;
}

void wait_for(cl_command_queue cmd_queue, const char* kern_name)
{
	// Wait for kernels 
	printf("Waiting for %s...\n", kern_name);	
	if(clFinish(cmd_queue) != CL_SUCCESS) {
		printf("clFinish() failed!\n");
		exit(-1);
	}
}

void wait_for_profiler(cl_event profevt)
{
	cl_int errorcode;
	errorcode = clWaitForEvents(1, &profevt);
	if(errorcode != CL_SUCCESS) {
		printf("clWaitForEvents() failed!\n");
		exit(-1);
	}
	cl_ulong prof_start, prof_end;
	errorcode = clGetEventProfilingInfo(profevt, CL_PROFILING_COMMAND_START, sizeof(cl_ulong), &prof_start, NULL);
	if(errorcode != CL_SUCCESS) {
		printf("clGetEventProfilingInfo() failed!\n");
		exit(-1);
	}
	errorcode = clGetEventProfilingInfo(profevt, CL_PROFILING_COMMAND_END, sizeof(cl_ulong), &prof_end, NULL);
	if(errorcode != CL_SUCCESS) {
		printf("clGetEventProfilingInfo() failed!\n");
		exit(-1);
	}
	prof_end /= 1000000;
	prof_end /= 1000000;
	printf("Duration: (%ld - %ld) = %ldms\n", prof_end, prof_start, (prof_end - prof_start));
}

int bitreverse(unsigned int v, int bits)
{
	unsigned int r = 0;
	for(int n = 0; n < bits; n++) {
		int pos = (bits - 1 - n);
		r |= ((v & (1 << n)) >> n) << pos;
	}
	return r;
} 

int calc(cl_device_id device, float* diff) 
{
#ifndef WIN32
	struct timeval start, end;
	long mtime, seconds, useconds;
	
	gettimeofday(&start, NULL);
#else
	unsigned long long start, end;
	start = GetTickCount64();
#endif
	
	cl_int errorcode;
	cl_context context = clCreateContext(NULL, 1, &device, NULL, NULL, &errorcode);
	if(errorcode != CL_SUCCESS) {
		printf("clCreateContext() failed!\n");
		return -1;
	}
	
	// Create and build program
	cl_program program = create_program("ocldec.cl", context, device);
	
	// Create kernels
	cl_kernel kern_init   = create_kernel(KERN_INIT, program);
	cl_kernel kern_result = create_kernel(KERN_RESULT, program);
	cl_kernel kern_step1  = create_kernel(KERN_STEP1, program);
	cl_kernel kern_step2  = create_kernel(KERN_STEP2, program);
	cl_kernel kern_step3  = create_kernel(KERN_STEP3, program);
	cl_kernel kern_step4  = create_kernel(KERN_STEP4, program);
	cl_kernel kern_step5  = create_kernel(KERN_STEP5, program);
	cl_kernel kern_step6  = create_kernel(KERN_STEP6, program);
	cl_kernel kern_step7  = create_kernel(KERN_STEP7, program);
	cl_kernel kern_step8  = create_kernel(KERN_STEP8, program);
	cl_kernel kern_twiddlea = create_kernel(KERN_TWIDDLEA, program);
	//cl_kernel kern_twiddleb = create_kernel(KERN_TWIDDLEB, program);
	cl_kernel kern_twiddlec = create_kernel(KERN_TWIDDLEC, program);

#ifdef PROFILING
	cl_event profevt;
	cl_command_queue cmd_queue0 = clCreateCommandQueue(context, device, CL_QUEUE_PROFILING_ENABLE, &errorcode);
#else
	cl_command_queue cmd_queue0 = clCreateCommandQueue(context, device, 0, &errorcode);
#endif
	if(errorcode != CL_SUCCESS) {
		printf("clCreateCommandQueue('cmd_queue0') failed!\n");
		return -1;
	}
	
	int n = N;
	int bits = BITS; // (n/8)
	
	// Create buffers for twiddle factors
	cl_mem A = clCreateBuffer(context, CL_MEM_READ_WRITE, 
		sizeof(float) * n / 2, NULL, &errorcode);
	if(errorcode != CL_SUCCESS) {
		printf("clCreateBuffer('A') failed: %s\n", errorstr(errorcode));
		return -1;
	}
	cl_mem B = clCreateBuffer(context, CL_MEM_READ_WRITE, 
		sizeof(float) * n / 2, NULL, &errorcode);
	if(errorcode != CL_SUCCESS) {
		printf("clCreateBuffer('B') failed: %s\n", errorstr(errorcode));
		return -1;
	}
	cl_mem C = clCreateBuffer(context, CL_MEM_READ_WRITE, 
		sizeof(float) * n / 4, NULL, &errorcode);
	if(errorcode != CL_SUCCESS) {
		printf("clCreateBuffer('C') failed: %s\n", errorstr(errorcode));
		return -1;
	}
	
	float* Yback = (float*)malloc(sizeof(float) * n);
	float* uback = (float*)malloc(sizeof(float) * n);
	randbuf(Yback, n);
	printf("Y = %f\n", bufsum(Yback, n));
	printf("u = %f\n", bufsum(uback, n));
	
	// Create two buffers for input and output
	cl_mem dbuf0 = clCreateBuffer(context, CL_MEM_READ_WRITE, 
		sizeof(float) * n, NULL, &errorcode);
	if(errorcode != CL_SUCCESS) {
		printf("clCreateBuffer('dbuf0') failed: %s\n", errorstr(errorcode));
		return -1;
	}

	cl_mem dbuf1 = clCreateBuffer(context, CL_MEM_READ_WRITE, 
		sizeof(float) * n, NULL, &errorcode);
	if(errorcode != CL_SUCCESS) {
		printf("clCreateBuffer('dbuf1') failed: %s\n", errorstr(errorcode));
		return -1;
	}
	
	size_t num_glo[1];
	size_t num_loc[1];

	// Set A as parameter 0 of the twiddleA kernel
	if(clSetKernelArg(kern_twiddlea, 0, sizeof(A), (void*)&A) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Set B as parameter 1 of the twiddleA kernel
	if(clSetKernelArg(kern_twiddlea, 1, sizeof(B), (void*)&B) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}

	// Set n as parameter 2 of the twiddleA kernel
	if(clSetKernelArg(kern_twiddlea, 2, sizeof(int), &n) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Enqueue twiddleA kernel
	printf("Starting twiddleA kernel...\n");
	num_glo[0] = n / 4; 
	num_loc[0] = MAX_WORKGROUP_SIZE;
	errorcode = clEnqueueNDRangeKernel(
			cmd_queue0, 
			kern_twiddlea, 
			1, // dimension 
			NULL,    // global work offset
			num_glo, // global work size
			NULL, //num_loc, 
			0, 
			NULL,
#ifdef PROFILING
			&profevt);
#else
			NULL);
#endif

	if(errorcode != CL_SUCCESS) {
		printf("clEnqueueNDRangeKernel('twiddleA') failed: %s\n", errorstr(errorcode));
		return -1;
	}
	
#ifdef PROFILING
	wait_for_profiler(profevt);
#endif
	
/*	// Set B as parameter 0 of the twiddleB kernel
	if(clSetKernelArg(kern_twiddleb, 0, sizeof(B), (void*)&B) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Set n as parameter 1 of the twiddleB kernel
	if(clSetKernelArg(kern_twiddleb, 1, sizeof(int), &n) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Enqueue twiddleB kernel
	printf("Starting twiddleB kernel...\n");
	num_glo[0] = n / 4;
	num_loc[0] = MAX_WORKGROUP_SIZE;
	errorcode = clEnqueueNDRangeKernel(
			cmd_queue0, 
			kern_twiddleb, 
			1, // dimension 
			NULL,    // global work offset
			num_glo, // global work size
			num_loc, 
			0, 
			NULL, 
			NULL);*/
		
	// Set C as parameter 0 of the twiddleC kernel
	if(clSetKernelArg(kern_twiddlec, 0, sizeof(C), (void*)&C) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Set n as parameter 1 of the twiddleC kernel
	if(clSetKernelArg(kern_twiddlec, 1, sizeof(int), &n) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Enqueue twiddleC kernel
	printf("Starting twiddleC kernel...\n");
	num_glo[0] = n / 8;
	num_loc[0] = MAX_WORKGROUP_SIZE;
	errorcode = clEnqueueNDRangeKernel(
			cmd_queue0, 
			kern_twiddlec, 
			1, // dimension 
			NULL,    // global work offset
			num_glo, // global work size
			NULL, //num_loc, 
			0, 
			NULL, 
#ifdef PROFILING
			&profevt);
#else
			NULL);
#endif
			
	if(errorcode != CL_SUCCESS) {
		printf("clEnqueueNDRangeKernel() failed!\n");
		return -1;
	}
	
#ifdef PROFILING
	wait_for_profiler(profevt);
#endif
	wait_for(cmd_queue0, "setup finish");

#ifndef WIN32
	gettimeofday(&end, NULL); // End setup phase
	
    seconds  = end.tv_sec  - start.tv_sec;
    useconds = end.tv_usec - start.tv_usec;
    mtime = ((seconds) * 1000 + useconds/1000.0) + 0.5;

    printf("Setup time: %ld milliseconds\n", mtime);

	gettimeofday(&start, NULL);
#else
	end = GetTickCount64();
	printf("Setup time: %ld milliseconds\n", end - start);
	start = GetTickCount64();
#endif

	// Fill start buffer with initial data (dbuf1 = Y)
	if(clEnqueueWriteBuffer(cmd_queue0, dbuf1, CL_TRUE, 0, 
		sizeof(float) * n, Yback, 0, NULL, NULL) != CL_SUCCESS) {
		printf("clEnqueueWriteBuffer() failed!\n");
		return -1;
	}

	// Set u as parameter 0 of the init kernel
	if(clSetKernelArg(kern_init, 0, sizeof(dbuf0), (void*)&dbuf0) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Set Y as parameter 1 of the init kernel
	if(clSetKernelArg(kern_init, 1, sizeof(dbuf1), (void*)&dbuf1) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Set n as parameter 2 of the init kernel
	if(clSetKernelArg(kern_init, 2, sizeof(int), &n) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}

	// Enqueue init kernel
	printf("Starting init kernel...\n");
	num_glo[0] = n; 
	num_loc[0] = MAX_WORKGROUP_SIZE;
	errorcode = clEnqueueNDRangeKernel(
			cmd_queue0, 
			kern_init, 
			1, // dimension 
			NULL,    // global work offset
			num_glo, // global work size
			num_loc, 
			0, 
			NULL, 
#ifdef PROFILING
			&profevt);
#else
			NULL);
#endif

	if(errorcode != CL_SUCCESS) {
		printf("clEnqueueNDRangeKernel('init') failed: %s\n", errorstr(errorcode));
		return -1;
	}
	
#ifdef PROFILING
	wait_for_profiler(profevt);
#endif
	
	/*
	wait_for(cmd_queue0, "init and twiddleA");
	
	float* res0 = clEnqueueMapBuffer(cmd_queue0, dbuf0, CL_TRUE, 0, 0, 
		sizeof(float) * n, 0, NULL, NULL, &errorcode);
	if(errorcode != CL_SUCCESS) {
		printf("clEnqueueMapBuffer() failed!\n");
		return -1;
	}
	
	for(int i = 0; i < N; i++) {
		printf("res0[%d] = %f\n", i, res0[i]);
	}*/
	
	// Set parameter of step1 kernel
	// v: result step1 kernel
	if(clSetKernelArg(kern_step1, 0, sizeof(dbuf1), (void*)&dbuf1) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// u: result of init kernel
	if(clSetKernelArg(kern_step1, 1, sizeof(dbuf0), (void*)&dbuf0) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	if(clSetKernelArg(kern_step1, 2, sizeof(int), &n) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	if(clSetKernelArg(kern_step1, 3, sizeof(A), (void*)&A) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Enqueue step1 kernel
	printf("Starting step1 kernel...\n");
	num_glo[0] = n / 4;
	num_loc[0] = MAX_WORKGROUP_SIZE;
	errorcode = clEnqueueNDRangeKernel(
			cmd_queue0, 
			kern_step1, 
			1, // dimension 
			NULL,    // global work offset
			num_glo, // global work size
			num_loc, 
			0, 
			NULL, 
#ifdef PROFILING
			&profevt);
#else
			NULL);
#endif

	if(errorcode != CL_SUCCESS) {
		printf("clEnqueueNDRangeKernel() failed!\n");
		return -1;
	}

#ifdef PROFILING
	wait_for_profiler(profevt);
#endif
			
	/*
	wait_for(cmd_queue0, "step1");
	float* res1 = clEnqueueMapBuffer(cmd_queue0, dbuf1, CL_TRUE, 0, 0, 
		sizeof(float) * n, 0, NULL, NULL, &errorcode);
	if(errorcode != CL_SUCCESS) {
		printf("clEnqueueMapBuffer() failed!\n");
		return -1;
	}
	
	
	for(int i = 0; i < N; i++) {
		printf("res1[%d] = %f\n", i, res1[i]);
	}*/
	
	// Set parameter of step2 kernel
	// v: result of step1 kernel
	if(clSetKernelArg(kern_step2, 0, sizeof(dbuf1), (void*)&dbuf1) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// w: result of step2 kernel
	if(clSetKernelArg(kern_step2, 1, sizeof(dbuf0), (void*)&dbuf0) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	if(clSetKernelArg(kern_step2, 2, sizeof(int), &n) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	if(clSetKernelArg(kern_step2, 3, sizeof(A), (void*)&A) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Enqueue step2 kernel
	printf("Starting step2 kernel...\n");
	num_glo[0] = n / 8;
	num_loc[0] = MAX_WORKGROUP_SIZE;
	errorcode = clEnqueueNDRangeKernel(
			cmd_queue0, 
			kern_step2, 
			1, // dimension 
			NULL,    // global work offset
			num_glo, // global work size
			num_loc, 
			0, 
			NULL, 
#ifdef PROFILING
			&profevt);
#else
			NULL);
#endif
			
	if(errorcode != CL_SUCCESS) {
		printf("clEnqueueNDRangeKernel() failed!\n");
		return -1;
	}

#ifdef PROFILING
	wait_for_profiler(profevt);
#endif
	
	// Set parameter of step3 kernel
	// ud: result of this kernel
	if(clSetKernelArg(kern_step3, 0, sizeof(dbuf1), (void*)&dbuf1) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// w: result of step2 kernel
	if(clSetKernelArg(kern_step3, 1, sizeof(dbuf0), (void*)&dbuf0) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	if(clSetKernelArg(kern_step3, 2, sizeof(int), &n) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	if(clSetKernelArg(kern_step3, 3, sizeof(A), (void*)&A) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
#ifdef WIN32
	int step3_bits = (int)(log((float)n) / log(2.0f)) - 4;
#else
	int step3_bits = log2(n) - 4;
#endif
	if(clSetKernelArg(kern_step3, 4, sizeof(int), &step3_bits) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Enqueue step3 kernel
	printf("Starting step3 kernel...\n");
	num_glo[0] = 32;//;3 * 256; //log2(n) - 3;
	size_t num_glo3[3], num_loc3[3];
	num_glo3[0] = 32; //num_glo[0];
	num_glo3[1] = 32; //num_glo[0];
	num_glo3[2] = 32; //num_glo[0];	
	num_loc3[0] = 32;
	num_loc3[1] = 32;
	num_loc3[2] = 32;
	errorcode = clEnqueueNDRangeKernel(
			cmd_queue0, 
			kern_step3, 
			3, // dimension 
			NULL,    // global work offset
			num_glo3, // global work size
			NULL, //num_loc3, 
			0, 
			NULL, 
#ifdef PROFILING
			&profevt);
#else
			NULL);
#endif
			
	if(errorcode != CL_SUCCESS) {
		printf("clEnqueueNDRangeKernel('step3') failed: %s\n", errorstr(errorcode));
		return -1;
	}

#ifdef PROFILING
	wait_for_profiler(profevt);
#endif
	
	// Set parameter of step4 kernel
	// vd: result of this kernel
	if(clSetKernelArg(kern_step4, 0, sizeof(dbuf0), (void*)&dbuf0) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// ud: result of last kernel
	if(clSetKernelArg(kern_step4, 1, sizeof(dbuf1), (void*)&dbuf1) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	if(clSetKernelArg(kern_step4, 2, sizeof(int), &n) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	if(clSetKernelArg(kern_step4, 3, sizeof(int), &bits) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Enqueue step4 kernel
	printf("Starting step4 kernel...\n");
	num_glo[0] = n / 8; // - 2;
	num_loc[0] = MAX_WORKGROUP_SIZE;
	errorcode = clEnqueueNDRangeKernel(
			cmd_queue0, 
			kern_step4, 
			1, // dimension 
			NULL,    // global work offset
			num_glo, // global work size
			num_loc, 
			0, 
			NULL, 
#ifdef PROFILING
			&profevt);
#else
			NULL);
#endif
			
	if(errorcode != CL_SUCCESS) {
		printf("clEnqueueNDRangeKernel('step4') failed: %s\n", errorstr(errorcode));
		return -1;
	}

#ifdef PROFILING
	wait_for_profiler(profevt);
#endif
	
	// Set parameter of step5 kernel
	// vd: result of last kernel
	if(clSetKernelArg(kern_step5, 0, sizeof(dbuf0), (void*)&dbuf0) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// wd: result of this kernel
	if(clSetKernelArg(kern_step5, 1, sizeof(dbuf1), (void*)&dbuf1) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Enqueue step5 kernel
	printf("Starting step5 kernel...\n");
	num_glo[0] = n / 2;
	num_loc[0] = MAX_WORKGROUP_SIZE;
	errorcode = clEnqueueNDRangeKernel(
			cmd_queue0, 
			kern_step5, 
			1, // dimension 
			NULL,    // global work offset
			num_glo, // global work size
			num_loc, 
			0, 
			NULL, 
#ifdef PROFILING
			&profevt);
#else
			NULL);
#endif
			
	if(errorcode != CL_SUCCESS) {
		printf("clEnqueueNDRangeKernel('step5') failed!\n");
		return -1;
	}

#ifdef PROFILING
	wait_for_profiler(profevt);
#endif
	
	// Set parameter of step6 kernel
	// us: result of this kernel
	if(clSetKernelArg(kern_step6, 0, sizeof(dbuf0), (void*)&dbuf0) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// wd: result of last kernel
	if(clSetKernelArg(kern_step6, 1, sizeof(dbuf1), (void*)&dbuf1) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	if(clSetKernelArg(kern_step6, 2, sizeof(int), &n) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Enqueue step6 kernel
	printf("Starting step6 kernel...\n");
	num_glo[0] = n / 8;
	num_loc[0] = MAX_WORKGROUP_SIZE;
	errorcode = clEnqueueNDRangeKernel(
			cmd_queue0, 
			kern_step6, 
			1, // dimension 
			NULL,    // global work offset
			num_glo, // global work size
			num_loc, 
			0, 
			NULL, 
#ifdef PROFILING
			&profevt);
#else
			NULL);
#endif
	
	if(errorcode != CL_SUCCESS) {
		printf("clEnqueueNDRangeKernel('step6') failed!\n");
		return -1;
	}

#ifdef PROFILING
	wait_for_profiler(profevt);
#endif
	
	// Set parameter of step7 kernel
	// vs: result of this kernel
	if(clSetKernelArg(kern_step7, 0, sizeof(dbuf1), (void*)&dbuf1) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// us: result of last kernel
	if(clSetKernelArg(kern_step7, 1, sizeof(dbuf0), (void*)&dbuf0) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	if(clSetKernelArg(kern_step7, 2, sizeof(int), &n) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	if(clSetKernelArg(kern_step7, 3, sizeof(C), (void*)&C) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Enqueue step7 kernel
	printf("Starting step7 kernel...\n");
	num_glo[0] = n / 8;
	num_loc[0] = MAX_WORKGROUP_SIZE;
	errorcode = clEnqueueNDRangeKernel(
			cmd_queue0, 
			kern_step7, 
			1, // dimension 
			NULL,    // global work offset
			num_glo, // global work size
			num_loc, 
			0, 
			NULL, 
#ifdef PROFILING
			&profevt);
#else
			NULL);
#endif
	
	if(errorcode != CL_SUCCESS) {
		printf("clEnqueueNDRangeKernel('step7') failed!\n");
		return -1;
	}

#ifdef PROFILING
	wait_for_profiler(profevt);
#endif

	// Set vs as parameter 0 of the step8 kernel
	// vs: result of last kernel
	if(clSetKernelArg(kern_step8, 0, sizeof(dbuf1), (void*)&dbuf1) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Set X as parameter 1 of the step8 kernel
	// X: result of this kernel
	if(clSetKernelArg(kern_step8, 1, sizeof(dbuf0), (void*)&dbuf0) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}

	// Set B as parameter 2 of the step8 kernel
	if(clSetKernelArg(kern_step8, 2, sizeof(B), (void*)&B) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Set n as parameter 3 of the step8 kernel
	if(clSetKernelArg(kern_step8, 3, sizeof(int), &n) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Enqueue step8 kernel
	printf("Starting step8 kernel...\n");
	num_glo[0] = n / 4;
	num_loc[0] = MAX_WORKGROUP_SIZE;
	errorcode = clEnqueueNDRangeKernel(
			cmd_queue0, 
			kern_step8, 
			1, // dimension 
			NULL,    // global work offset
			num_glo, // global work size
			num_loc, 
			0, 
			NULL, 
#ifdef PROFILING
			&profevt);
#else
			NULL);
#endif
	
	if(errorcode != CL_SUCCESS) {
		printf("clEnqueueNDRangeKernel('step8') failed!\n");
		return -1;
	}

#ifdef PROFILING
	wait_for_profiler(profevt);
#endif
	
	// Set X as parameter 0 of the result kernel
	// X: result of last kernel
	if(clSetKernelArg(kern_result, 0, sizeof(dbuf0), (void*)&dbuf0) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}

	// Set y as parameter 1 of the result kernel
	// y: result of this kernel
	if(clSetKernelArg(kern_result, 1, sizeof(dbuf1), (void*)&dbuf1) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Set n as parameter 2 of the result kernel
	if(clSetKernelArg(kern_result, 2, sizeof(int), &n) != CL_SUCCESS) {
		printf("clSetKernelArg() failed!\n");
		return -1;
	}
	
	// Enqueue result kernel
	printf("Starting result kernel...\n");
	num_glo[0] = n;
	num_loc[0] = MAX_WORKGROUP_SIZE;
	errorcode = clEnqueueNDRangeKernel(
			cmd_queue0, 
			kern_result, 
			1, // dimension 
			NULL,    // global work offset
			num_glo, // global work size
			num_loc, 
			0, 
			NULL, 
#ifdef PROFILING
			&profevt);
#else
			NULL);
#endif
	
	if(errorcode != CL_SUCCESS) {
		printf("clEnqueueNDRangeKernel('result') failed!\n");
		return -1;
	}

#ifdef PROFILING
	wait_for_profiler(profevt);
#endif
	
	float* res = (float*)clEnqueueMapBuffer(cmd_queue0, dbuf1, CL_TRUE, 0, 0, 
		sizeof(float) * n, 0, NULL, NULL, &errorcode);
	if(errorcode != CL_SUCCESS) {
		printf("clEnqueueMapBuffer() failed!\n");
		return -1;
	}
					
	wait_for(cmd_queue0, "results");

#ifndef WIN32
	gettimeofday(&end, NULL);
	
    seconds  = end.tv_sec  - start.tv_sec;
    useconds = end.tv_usec - start.tv_usec;
    mtime = ((seconds) * 1000 + useconds/1000.0) + 0.5;

    printf("Calculation time: %ld milliseconds\n", mtime);
#else
	end = GetTickCount64();
	printf("Calculation time: %ld milliseconds\n", (end - start));
#endif
	
	printf("y = %f\n", bufsum(res, n));
	printf("diff = %f\n", bufdiff(res, diff, n));
	/*for(int i = 0; i < N; i++) {
		printf("y[%d] = %f\n", i, res[i]);
	}*/

	printf("Finished. Releasing program...\n");
	if(clReleaseProgram(program) != CL_SUCCESS) {
		printf("clReleaseProgram() failed!\n");
		return -1;
	}

	if(clReleaseCommandQueue(cmd_queue0) != CL_SUCCESS) {
		printf("clReleaseCommandQueue() failed!\n");
		return -1;
	}
	
	free(Yback);
	free(uback);

	return 0;
} 

int main(int argc, char* argv[])
{
	int n = N;
	float* in = (float*)malloc(n * sizeof(float));
	float* out = (float*)malloc(n * sizeof(float));
#ifndef WIN32
	struct timeval start, end;
	long mtime, seconds, useconds;
#else
	unsigned long long start, end;
#endif
	
	printf("Sample size N = %d\n", N);

	printf("Run oldstyle code...\n");
	mdct_lookup lu;
	mdct_init(&lu, n);
	randbuf(in, n);

#ifndef WIN32
	gettimeofday(&start, NULL);
#else
	start = GetTickCount64();
#endif
	mdct_backward(&lu, in, out);

#ifndef WIN32
	gettimeofday(&end, NULL);

    seconds  = end.tv_sec  - start.tv_sec;
    useconds = end.tv_usec - start.tv_usec;
    mtime = ((seconds) * 1000 + useconds/1000.0) + 0.5;
	
	/*for(int i = 0; i < N; i++) {
		printf("y[%d] = %f\n", i, out[i]);
	}*/

    printf("Calculation time: %ld milliseconds\n", mtime);
#else
	end = GetTickCount64();
	printf("Calculation time: %ld milliseconds\n", (end - start));
#endif

	printf("y = %f\n", bufsum(out, n));

	cl_device_id device;
	device = get_first_device(CL_DEVICE_TYPE_GPU);
	calc(device, out);

	device = get_first_device(CL_DEVICE_TYPE_CPU);
	calc(device, out);
	
	free(in);
	free(out);

	return 0;
}
