/*
 *   Fafnir Mail
 *   Copyright (C) 2007, 2008 by Christian Lins <christian.lins@web.de>
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fafnir;

import fafnir.config.Config;
import fafnir.config.Account;
import fafnir.gui.MainFrame;
import fafnir.gui.config.AccountEditFrame;
import javax.swing.UIManager;

/**
 * Main entrypoint class of Fafnir.
 * @author Christian Lins (christian.lins
 */
public class Main 
{
  public static final String VERSION = "0.1.0";
  public static final String TITLE   = "Fafnir/" + VERSION;
  
  public static void main(String[] args)
  {
    try
    {
      // Try to load new Nimbus LookAndFeel
      try
      {
        for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) 
        {
          if ("Nimbus".equals(info.getName())) 
          {
            UIManager.setLookAndFeel(info.getClassName());
            break;
          }
        }
      }
      catch(Exception e)
      {
        e.printStackTrace();
      }

      new MainFrame().setVisible(true);

      Account[] profiles = Config.inst().getProfiles();
      if(profiles.length == 0)
      {
        new AccountEditFrame().setVisible(true);
      }
    }
    catch(Throwable err)
    {
      
    }
  }
}
