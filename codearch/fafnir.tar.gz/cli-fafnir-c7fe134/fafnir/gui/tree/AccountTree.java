/*
 *   Fafnir Mail
 *   Copyright (C) 2007, 2008 by Christian Lins <christian.lins@web.de>
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fafnir.gui.tree;

import java.io.IOException;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 *
 * @author chris
 */
public class AccountTree extends JTree
{
  private AccountTreeModel model = new AccountTreeModel(new DefaultMutableTreeNode("Accounts"));
  
  public AccountTree()
  {
    setModel(model);
  }
  
  public void updateView()
  {
    try
    {
      this.model.updateAccounts();
      expandRow(0);
    }
    catch(IOException ex)
    {
      ex.printStackTrace();
    }
  }
}
