/*
 *   Fafnir Mail
 *   Copyright (C) 2007, 2008 by Christian Lins <christian.lins@web.de>
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fafnir.gui;

import fafnir.Main;
import java.awt.BorderLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;

/**
 * Main frame of Fafnir.
 * @author Christian Lins (christian.lins@web.de)
 */
public class MainFrame extends JFrame
{
  private MenuBar menuBar     = new MenuBar();
  private ToolBar toolBar     = new ToolBar();
  private ThreeViewPane view  = new ThreeViewPane();
  
  public MainFrame()
  {
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setSize(800, 600);
    setTitle(Main.TITLE);
    
    // Create GUI elements
    setJMenuBar(menuBar);
    getContentPane().setLayout(new BorderLayout());
    getContentPane().add(this.toolBar, BorderLayout.NORTH);
    getContentPane().add(this.view, BorderLayout.CENTER);
    
    addWindowListener(new WindowAdapter() 
    {
      public void windowOpened(WindowEvent arg0)
      {
        view.updateView();
      }

      public void windowClosing(WindowEvent arg0)
      {
        
      }

      public void windowClosed(WindowEvent arg0)
      {
        
      }
    });
  }
}
