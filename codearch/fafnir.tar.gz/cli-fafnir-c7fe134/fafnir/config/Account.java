/*
 *   Fafnir Mail
 *   Copyright (C) 2007, 2008 by Christian Lins <christian.lins@web.de>
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package fafnir.config;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * Contains basic information about an account.
 * @author Christian Lins (christian.lins@web.de)
 */
public class Account 
{  
  public static Account load(String baseDir)
    throws IOException
  {
    XStream xstream = new XStream(new DomDriver());
    return (Account)xstream.fromXML(new FileInputStream(baseDir + "/account.xml"));
  }
  
  public static void store(Account account)
    throws IOException
  {
    File dir = new File(account.baseDir);
    if(!dir.exists())
    {
      dir.mkdirs();
    }
    
    XStream xstream = new XStream(new DomDriver());
    xstream.toXML(account, new FileOutputStream(account.baseDir + "/account.xml"));
  }
  
  // Properties that are stored to the account.xml
  private String baseDir     = null;
  private String name        = "<unamed>";
  private String piName      = null;
  private String piEMail     = null;
  private String inboxType   = "IMAP";
  private String inboxServer = null;
  private String smtpServer  = null;
  private String userID      = null;
  
  public String getName()
  {
    return this.name;
  }
  
  public void setBaseDir(String path)
  {
    this.baseDir = path;
  }
  
  public void setName(String name)
  {
    this.name = name;
  }

  public String getPiName()
  {
    return piName;
  }

  public void setPiName(String piName)
  {
    this.piName = piName;
  }

  public String getPiEMail()
  {
    return piEMail;
  }

  public void setPiEMail(String piEMail)
  {
    this.piEMail = piEMail;
  }

  public String getInboxType()
  {
    return inboxType;
  }

  public void setInboxType(String inboxType)
  {
    this.inboxType = inboxType;
  }

  public String getInboxServer()
  {
    return inboxServer;
  }

  public void setInboxServer(String inboxServer)
  {
    this.inboxServer = inboxServer;
  }

  public String getSmtpServer()
  {
    return smtpServer;
  }

  public void setSmtpServer(String smtpServer)
  {
    this.smtpServer = smtpServer;
  }

  public String getUserID()
  {
    return userID;
  }

  public void setUserID(String userID)
  {
    this.userID = userID;
  }
}
