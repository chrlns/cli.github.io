/*
 *	Copyright (C) 2008,2010 Christian Lins <christian.lins@web.de>
 * 
 *	This program is free software: you can redistribute it and/or modify
 *	it under the terms of the GNU General Public License as published by
 *	the Free Software Foundation, either version 3 of the License, or
 *	(at your option) any later version.
 *
 *	This program is distributed in the hope that it will be useful,
 *	but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	See the
 *	GNU General Public License for more details.
 *
 *	You should have received a copy of the GNU General Public License
 *	along with this program. If not, see <http://www.gnu.org/licenses/>.
 *
 *	If you need a commercial license for this little piece of software,
 *	feel free to contact the author.
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <pthread.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>

#define printfv(fstr, ...) \
	if(verbose) { \
		printf("[sdns] "); \
		printf(fstr, __VA_ARGS__); \
		printf("\n"); \
	}

#define BUF_LEN 512 // Maximum length of an DNS packet
#define OPCODE_QUERY  0x0000
#define OPCODE_IQUERY 0x0001
#define OPCODE_STATUS 0x0002

// Aligment redefining should work on most compilers including gcc, m$, borland
#pragma pack(push)	/* push current alignment to stack */
#pragma pack(1)		/* set alignment to 1 byte boundary */

struct dns_header
{
	unsigned short id;			// ID of this message
	unsigned short flags;		// Important flags
	unsigned short num_quest;	// Number of questions, default: 1
	unsigned short anRR;
	unsigned short auRR;
	unsigned short addRR;
};

#pragma pack(pop)	/* restore original alignment from stack */

struct dns_question
{
	char*			name;
	unsigned short	type;
	unsigned short	class;
};

struct dns_record
{
	char*			name;
	unsigned short	type;
	unsigned short	class;
	unsigned int	ttl;
	unsigned short	len;
	char*			rdata;
};

/* An entry in the in-memory host-ip-table */
struct host_entry
{
	char*			hostname;
	unsigned char	ip4[4];

	struct host_entry* next;
};

static const char* hostfile = "/etc/hosts";
static bool	running = true;
static struct host_entry* hosttable;
#ifdef DEBUG
static bool verbose = true;
#else
static bool verbose = false;
#endif

#ifdef DEBUG
const char* error()
{
	switch(errno) {
		case EAFNOSUPPORT:
			return "EAFNOSUPPORT";
		case EAGAIN:
			return "[EAGAIN|EWOULDBLOCK]";
		case EBADF:
			return "EBADF";
		case ECONNRESET:
			return "ECONNRESET";
		case EINTR:
			return "EINTR";
		case EMSGSIZE:
			return "EMSGSIZE";
		case ENOTCONN:
			return "ENOTCONN";
		case ENOTSOCK:
			return "ENOTSOCK";
		case EOPNOTSUPP:
			return "EOPNOTSUPP";
		case EPIPE:
			return "EPIPE";
		case EIO:
			return "EIO";
		case ELOOP:
			return "ELOOP";
		case ENAMETOOLONG:
			return "ENAMETOOLONG";
		case ENOENT:
			return "ENOENT";
		case ENOTDIR:
			return "ENOTDIR";
		case EACCES:
			return "EACCES";
		case EDESTADDRREQ:
			return "EDESTADDRREQ";
		case EHOSTUNREACH:
			return "EHOSTUNREACH";
		case EINVAL:
			return "EINVAL";
		case EISCONN:
			return "EISCONN";
		default:
			return "[Unknown]";
	}
}
#endif

bool compare_ip4(char* ip, struct host_entry* entry)
{
	int n;
	for(n = 3; n >= 0; n--) {
		if(entry->ip4[n] != ip[n]) {
			return false;
		}
	}
	return true;
}

bool compare_host(char* host, struct host_entry* entry)
{
	if(strcmp((const char*)host, (const char*)entry->hostname) == 0) {
		return true;
	} else {
		return false;
	}
}

/* The DNS specifies a _strange_ format of the given strings, so we have to rebuild that */
void dns_to_cstr(char* str)
{
	int n, m, i;

	for(n = 0; str[n] != 0; n++) {
		m = str[n];
		for(i = n; i < n+m; i++) {
			str[i] = str[i+1];
		}
		str[i] = '.';
		n = i;
	}
	str[n-1] = '\0';
}

struct host_entry* search_table(char* ip_or_host, bool (*cmp_func)(char*, struct host_entry*))
{
	struct host_entry* entry;

	entry = hosttable;
	while(entry != NULL) {
		if(cmp_func(ip_or_host, entry) == true) {
			return entry;
		} else {
			entry = entry->next;
		}
	}
	return NULL;
}

/* Processes a dns request and replies to the client */
void process_request(int len, char* buf, struct sockaddr_in* from, socklen_t* from_len, int reply_socket)
{
	int n, m;
	struct host_entry*		entry;
	struct dns_header*		header;
	struct dns_question*	questions;
	char*					ret_buf;
	struct sockaddr_in		to;

	ret_buf = buf; // Store pointer to buffer

	// Prepare sending address
	to.sin_addr.s_addr = from->sin_addr.s_addr;
	to.sin_family			= AF_INET;
	to.sin_port				= from->sin_port;

	// "Reading" header; this works only because the struct is byte-aligned
	header = (struct dns_header*)buf;
	// On little-endian platforms we have to do byte swapping
	header->id			= ntohs(header->id);
	header->flags		= ntohs(header->flags);
	header->num_quest	= ntohs(header->num_quest);
	header->anRR		= ntohs(header->anRR);
	header->auRR		= ntohs(header->auRR);
	header->addRR		= ntohs(header->addRR);
	
	printfv("[sdns] Header->ID = 0x%x\n", header->id);
	printfv("[sdns] Header->NumQuests = 0x%x\n", header->num_quest);

	// Move buffer pointer
	buf += 12;

	// Read questions
	if(header->num_quest > 0) {
		questions = malloc(sizeof(struct dns_question) * header->num_quest);
	} else {
		questions = NULL;
	}

	for(n = 0; n < header->num_quest; n++) {
		// Read name
		questions[n].name = buf;
		for(m = 0; *(questions[n].name++) != 0; m++); // Loop until zero is reached in the string
		questions[n].name = malloc(sizeof(char) * (++m));
		strcpy(questions[n].name, buf);
		buf += m;
		dns_to_cstr(questions[n].name); // DNS-string to C-string

		// Type
		questions[n].type  = *(buf++);
		questions[n].type |= *(buf++) << 8;
		questions[n].type  = ntohs(questions[n].type);
		
		// Class
		questions[n].class  = *(buf++) << 8;
		questions[n].class |= *(buf++);
		questions[n].class  = ntohs(questions[n].class);
	}

	// Switch request type
	for(n = 0; n < header->num_quest; n++) {
		switch(questions[n].type) {
			case 0x0001: {
				printfv("[sdns] A Query for %s\n", questions[n].name);
				entry = search_table(questions[n].name, compare_host);
				if(entry == NULL) {
					printfv("[sdns] No entry for host %s. Reply with master NS.\n", 
						questions[n].name);
				} else {
					printfv("[sdns] Reply with %u.%u.%u.%u\n", 
						entry->ip4[0], entry->ip4[1], entry->ip4[2], entry->ip4[3]);

					// Build response
					header->flags |= htons(0x8000);	// Set bit 16 (response=1)
					header->flags &= htons(~0x0080); // Unset bit 8 (server does allow recursive queries)

					// On little-endian platforms we have to do byte swapping
					header->id			= htons(header->id);
					header->flags		= htons(header->flags);
					header->num_quest	= htons(header->num_quest);
					header->anRR		= htons(header->anRR);
					header->auRR		= htons(header->auRR);
					header->addRR		= htons(header->addRR);

					m = sendto(reply_socket, ret_buf, len, 0, (struct sockaddr*)&to, sizeof(to));

					if(m == -1) {
						printfv("[sdns] Sending failed with error %s!\n", error());
					} else {
						printfv("[sdns] %u bytes sent.\n", m);
					}
				}
				break;
			}
			/*case OPCODE_IQUERY:
			{
				printf("[%s] Inverse Query for %s\n", SERVER_NAME, questions[n].name);
				break;
			}*/
			default:
				printfv("[sdns] Unknown query type %u\n", questions[n].type);
		}
	}

	free(questions);
}

int read_hosts_file(const char* file)
{
	unsigned int		address[4];
	struct host_entry*	cur_el;
	int					elements;
	char				name[255];

	FILE* fp = fopen(file, "r");
	if(file == NULL) {
		return -1;
	}

	hosttable = NULL; // Initialize HostTable with NULL pointer

	// Loop through hosts file
	while((elements = fscanf(fp, "%u.%u.%u.%u %254s\n", address, address+1, address+2, address+3, name))) {
		if(elements == EOF) {
			break;
		}

		if(elements == 5) {
			printfv("Found %u.%u.%u.%u for %s", 
				address[0], address[1], address[2], address[3], name);
			// Create new host_entry
			cur_el					 = malloc(sizeof(struct host_entry));
			cur_el->hostname = malloc(sizeof(char) * (strlen(name) + 1)); // Don't forget the terminating character
			strcpy(cur_el->hostname, (const char*)name); // Copy from buffer to queue element
			cur_el->ip4[0]	= (unsigned char)address[0];
			cur_el->ip4[1]	= (unsigned char)address[1];
			cur_el->ip4[2]	= (unsigned char)address[2];
			cur_el->ip4[3]	= (unsigned char)address[3];
			cur_el->next	= hosttable;
			// Set current element as new queue head
			hosttable = cur_el;
		}
	}
	
	fclose(fp);

	return 0;
}

/* The program entry point */
int main(int argc, char* argv[])
{
	// Declare some variables
	struct sockaddr_in sock_addr_server;
	struct sockaddr_in sock_addr_client;

	// Read host file and create table
	if(read_hosts_file(hostfile) == -1) {
		printf("[sdns] Could not read hosts file!\n");
		return -1;
	}

	// Create a socket
	int sock = socket(PF_INET, SOCK_DGRAM, 0);
	if(sock == -1) {
		printf("[sdns] Could not create a socket!\n");
		return -1;
	}

	// Create a socket address for out socket
	sock_addr_server.sin_addr.s_addr	= INADDR_ANY;	// Bind to all interfaces
	sock_addr_server.sin_port			= htons(53);	// Port 53 is the default DNS port
	sock_addr_server.sin_family			= AF_INET;		// We use the IP protocol of course

	// Bind socket to all interfaces
	if(bind(sock, (struct sockaddr*)&sock_addr_server, sizeof(sock_addr_server)) == -1) {
		printf("[sdns] Could not bind to interface! Are you the superuser?\n");
		return -1;
	}

	// Print version information
	printfv("Started on port %u", 53);

	char buffer[BUF_LEN];
	ssize_t recv_bytes;
	socklen_t sock_addr_client_size;

	while(running) {
		// Accept connections
		recv_bytes = recvfrom(sock, buffer, BUF_LEN, MSG_WAITALL, 
			(struct sockaddr*)&sock_addr_client, &sock_addr_client_size);
		if(recv_bytes >= 0) {
			printfv("%i bytes received\n", recv_bytes);
			// Process received data
			process_request(recv_bytes, buffer, &sock_addr_client, &sock_addr_client_size, sock);
		} else {
			printfv("Error receiving packet from client. Error: %s", error());
		}
	}

	// Free resources
	close(sock);

	return 0;
}
