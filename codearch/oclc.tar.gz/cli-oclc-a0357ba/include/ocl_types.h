#define __global
#define __local
#define __kernel

// Vector types
typedef struct
{
	unsigned char _0;
	unsigned char _1;
	unsigned char _2;
	unsigned char _3;
} 
uchar4;
