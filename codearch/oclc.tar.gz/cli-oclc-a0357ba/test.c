#include <ocl_types.h>

__kernel 
void blocktest(__global  uchar4  * output  ,
                __global  uchar4  * input   ,
                __local   uchar4  * block0  
            )
{
    unsigned int blockIdx = get_group_id(0);
    unsigned int localIndex = get_local_id(0);
    unsigned int globalIndex = blockIdx * get_local_size(0) + localIndex;
    block0[localIndex]  = input[globalIndex];
    output[globalIndex] =  block0[localIndex];
}
