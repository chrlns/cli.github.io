int clEnqueueNDRangeKernel(
	cl_command_queue* commandQueue,
	cl_kernel* kernel,
	void* res0,
	int dimension,
	int numGlobalThreads,
	int numLocalThreads,
	int res1,
	void* res2,
	cl_event* evt)
{
	// Determine number of compute units available, normally this is the
	// number of logical CPU cores available.
	int numCUs;
	
	// We spawn at least numCUs worker threads but we need to know how
	// many worker groups are running simultaneously (at least 1).
	int parallelLocal = min(1, numCUs / numLocalThreads);
}
