#include <stdio.h>

int read_fully(const char* path, char** buf_ptr)
{
	FILE* file = fopen(path, "rb");
	fseek(file, 0, SEEK_END);
	int len = ftell(file);
	fseek(file, 0, SEEK_SET);
	*buf_ptr = malloc(sizeof(char) * len);
	fread(*buf_ptr, 0, len, file);
	fclose(file);
}

int write_buffer(const char* path, char* buf, int len)
{
	FILE* file = fopen(path, "wb");
	fwrite(buf, 0, len, file);
	fclose(file);
}

int write_output_header(FILE* file)
{
	fprint(file, "#include <ocl_types.h>\n");
}
