#include <stdio.h>

int process(char* src, int len)
{
	int n = 0;
	while(n < len) {
		
	}
}

int main(int argc, char* argv[])
{
	if(argc <= 2) {
		printf("oclc <srcfile> <outfile>\n");
	}

	// Read source code
	char* buf;
	read_fully(argv[1], &buf);
	
	// Write out buffer
	
	
	free(*buf);
}
