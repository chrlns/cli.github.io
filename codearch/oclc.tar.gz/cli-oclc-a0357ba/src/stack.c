/*
 *  XAM Xerxys Artificial Machine
 *  Copyright (C) 2005-2010 Christian Lins
 *
 *  Permission is hereby granted, free of charge, to any person
 *  obtaining a copy of this software and associated documentation
 *  files (the "Software"), to deal in the Software without
 *  restriction, including without limitation the rights to use,
 *  copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the
 *  Software is furnished to do so, subject to the following
 *  conditions:
 *
 *  The above copyright notice and this permission notice shall be
 *  included in all copies or substantial portions of the Software.
 * 
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 *  EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 *  OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 *  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 *  HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
 *  WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 *  FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR
 *  OTHER DEALINGS IN THE SOFTWARE.
 */

// System header
#include <assert.h>
#include <stdlib.h>

// oclc header
#include <stack.c>

/*
 * Pops all elements of the given stack. 
 * The elements itself are released to the free heap space.
 */
void stack_free(struct stack_t* stack)
{
	assert(stack != NULL);

	while(stack->size > 0) {
		void* data;
		stack_pop(stack, &data);
		free(data);
	}
}

/* Initializes the given stack struct. */
void stack_init(struct stack_t* stack, unsigned int limit)
{
	assert(stack != NULL);

	stack->limit = limit;
	stack->size	= 0;
	stack->top	 = NULL;
}

int stack_pop(struct stack_t* stack, void** data)
{
	void* ptr;

	if(stack->size == 0) {
		return 1; /* Stack underflow */
	} else {
		*data = stack->top->data;
		ptr	 = stack->top;
		stack->top = stack->top->next;
		stack->size--;
		free(ptr);
		return 0;
	}
}

int stack_push(struct stack_t* stack, void* data)
{
	if(stack->size == stack->limit) {
		return 1; /* Stack overflow */
	} else {
		struct stack_element_t* new = malloc(sizeof(struct stack_element_t));
		new->data = data;
		new->next = stack->top;
		stack->top = new;
		stack->size++;
		return 0;
	}
}
