#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>

static int global_size;
static int local_size;

static int current_thread = -1;
static int finished_threads = 0;
static int blocked_threads = 0;	// Number of local threads waiting at barrier

static char* local_mem;
static pthread_mutex_t mut = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t cond = PTHREAD_COND_INITIALIZER;
static int local_barrier;

// Called by a kernel to wait for the other kernels
void barrier(void)
{
	pthread_mutex_lock(&mut);
	local_barrier--;
	if(local_barrier > 0) {
		while(local_barrier > 0) {
			pthread_cond_wait(&cond, &mut);
		}
	} else {
		pthread_cond_broadcast(&cond);
	}
	pthread_mutex_unlock(&mut);
	
	pthread_mutex_lock(&mut);
	local_barrier = local_size;
	pthread_mutex_unlock(&mut);
}

void* invoke(void* args)
{
	current_thread++;

	current_thread--;
}

// argv[1]: global size (number of overall threads)
// argv[2]: local size (number of threads per work group)
// argv[3]: global shared memory
// argv[4]: local memory size
int main(int argc, char* argv[])
{
	// We do not check the validity of argv as this
	// program should only be called by a working library function...
	int global_size = atoi(argv[1]);
	int local_mem_size = atoi(argv[4]);
	local_size = atoi(argv[2]);
	pthread_t threads[local_size];

	local_mem = malloc(local_mem_size);

	for(int n = 0; n < global_size; n += local_size) {
		// Spawn local threads
		for(int m = 0; m < local_size; m++) {
			if(pthread_create(&(threads[m]), NULL, invoke, NULL) != 0) {
				return -2;
			}
		}

		// Wait for local threads to exit
		for(int m = 0; m < local_size; m++) {
			pthread_join(threads[m], NULL);
		}
	}

	free(local_mem);

	return 0;
}
