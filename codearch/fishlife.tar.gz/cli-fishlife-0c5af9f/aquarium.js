var aquarium	= null;
var context2D	= null;
var timerDraw	= null;
var timerFPS	= null;
var avgFrames	= 0;
var numFrames	= 0;

function framesCallback()
{
	avgFrames = numFrames;
	numFrames = 0;
}

function drawCanvas()
{
	// Draw the aquarium background water
	var lingrad = context2D.createLinearGradient(0, 0, 0, window.innerHeight);
	lingrad.addColorStop(0, 'rgb(0,0,200)');
	lingrad.addColorStop(0.2, 'rgb(0,0,30)');

	context2D.fillStyle = lingrad;
	context2D.fillRect (0, 0, window.innerWidth, window.innerHeight);

	// Draw the bubbles
	var radgrad = context2D.createRadialGradient(25,25,5,25,25,20);	
	radgrad.addColorStop(0, '#A7D30C');	
	radgrad.addColorStop(0.9, '#019F62');	
	radgrad.addColorStop(1, 'rgba(1,159,98,0)');
	context2D.fillStyle = radgrad;	
	context2D.fillRect(0,0,50,50);

	context2D.strokeStyle = "#000000";
	context2D.fillStyle = "#FFFFFF";
	context2D.fillText(avgFrames + " fps", 5, 15);	

	numFrames++;
}

function fillAquarium()
{
	aquarium	= document.getElementById('aquarium');
	if(aquarium.getContext) 
	{
		context2D = aquarium.getContext('2d');
		timerDraw = window.setInterval('drawCanvas()', 100);
		timerFPS  = window.setInterval('framesCallback()', 1000);
	}
}
