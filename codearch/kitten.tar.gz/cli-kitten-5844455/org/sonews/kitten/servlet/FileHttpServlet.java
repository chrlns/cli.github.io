/*
 *  Kitten
 *  Copyright 2008, 2009 Christian Lins <cli@openoffice.org>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.sonews.kitten.servlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.sonews.kitten.Main;

/**
 * Simple servlet that serves files.
 * @author Christian Lins
 */
public class FileHttpServlet extends HttpServlet
{
  
  private static final long serialVersionUID = 24582844834535L;
  
  private String createDirectoryListing(File dir)
  {
    StringBuffer buf = new StringBuffer();
    
    buf.append("<html><body>");
    buf.append("<h1>");
    buf.append("Index of ");
    buf.append(dir.getName());
    buf.append("</h1>");
    
    File[] files = dir.listFiles();
    for(File file : files)
    {
      buf.append(file.getName());
      buf.append("</br>");
    }
    
    buf.append("</body></html>");
    
    return buf.toString();
  }

  /**
   * 
   * @param dir 
   * @return File object of the directory's index file.
   */
  private File determineIndexFile(File dir)
  {
    if(dir.isDirectory())
    {
      File[] files = dir.listFiles(new FilenameFilter() 
      {
        public boolean accept(File dir, String name)
        {
          return name.startsWith("index") || name.startsWith("default");
        }
      });

      if(files.length > 0)
        return files[0];
    }
      
    return dir;
  }

  @Override
  public void doGet(HttpServletRequest req, HttpServletResponse resp)
  {
    InputStream in = null;

    try
    {
      String url = req.getPathTranslated();
      File file = new File(Main.DOCUMENT_ROOT + "/" + url);

      // Check if file exists
      if(!file.exists())
      {
        resp.sendError(HttpServletResponse.SC_NOT_FOUND);
        return;
      }

      // If file is a directory, determine an index file
      file = determineIndexFile(file);
      
      if(file.isDirectory())
      {
        // Create directory listing
        String dirList = createDirectoryListing(file);
        //return dirList.getBytes("UTF-8");
      }
      else // is a file
      { // TODO: Read chunks instead of full file
        byte[] buffer = new byte[(int)file.length()];
        in = new FileInputStream(file);
        in.read(buffer);
        //return buffer;
      }
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
      //return null;
    }
    finally
    {
      try
      {
        if(in != null)
          in.close();
      }
      catch(IOException ex)
      {
        ex.printStackTrace();
      }
    }
  }
  
}
