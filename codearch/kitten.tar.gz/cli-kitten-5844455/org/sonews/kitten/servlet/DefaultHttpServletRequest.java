/*
 *  Kitten
 *  Copyright 2008, 2009 Christian Lins <cli@openoffice.org>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.sonews.kitten.servlet;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.security.Principal;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Vector;
import java.util.regex.Pattern;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletInputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Christian Lins
 */
public class DefaultHttpServletRequest implements HttpServletRequest
{

  protected String              method        = "GET";
  protected Map<String, String> parameterMap  = new HashMap<String, String>();
  protected String              requestString = null;
  protected Principal           userPrincipal = null;
  
  public String getAuthType()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getContextPath()
  {
    Pattern  spltPttrn = Pattern.compile("[/?]");
    String[] path      = spltPttrn.split(this.requestString);
    
    if(path.length > 1)
    {
      return path[1];
    }
    else
    {
      return "";
    }
  }

  public Cookie[] getCookies()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public long getDateHeader(String arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getHeader(String arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public Enumeration getHeaderNames()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public Enumeration getHeaders(String arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public int getIntHeader(String arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getMethod()
  {
    return this.method;
  }
  
  public void setMethod(String method)
  {
    this.method = method;
  }

  public String getPathInfo()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getPathTranslated()
  {
    int idx = this.requestString.indexOf("/");
    if(idx > 0)
    {
      return this.requestString.substring(0, idx);
    }
    else
    {
      return null;
    }
  }

  public String getQueryString()
  {
    int idx = this.requestString.indexOf("?");
    if(idx > 0)
    {
      return this.requestString.substring(idx);
    }
    else
    {
      return null;
    }
  }

  public String getRemoteUser()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getRequestURI()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public StringBuffer getRequestURL()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getRequestedSessionId()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getServletPath()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public HttpSession getSession(boolean arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public HttpSession getSession()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public Principal getUserPrincipal()
  {
    return this.userPrincipal;
  }

  public boolean isRequestedSessionIdFromCookie()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public boolean isRequestedSessionIdFromURL()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  @Deprecated
  public boolean isRequestedSessionIdFromUrl()
  {
    return isRequestedSessionIdFromURL();
  }

  public boolean isRequestedSessionIdValid()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public boolean isUserInRole(String arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public Object getAttribute(String arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public Enumeration getAttributeNames()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getCharacterEncoding()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public int getContentLength()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getContentType()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public ServletInputStream getInputStream() throws IOException
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getLocalAddr()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getLocalName()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public int getLocalPort()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public Locale getLocale()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public Enumeration getLocales()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getParameter(String param)
  {
    return this.parameterMap.get(param);
  }

  public Map getParameterMap()
  {
    return this.parameterMap;
  }

  public Enumeration getParameterNames()
  {
    return new Vector<String>(this.parameterMap.keySet()).elements();
  }

  public String[] getParameterValues(String arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getProtocol()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public BufferedReader getReader() throws IOException
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  @Deprecated
  public String getRealPath(String arg0)
  {
    throw new UnsupportedOperationException("Deprecated.");
  }

  public String getRemoteAddr()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getRemoteHost()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public int getRemotePort()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public RequestDispatcher getRequestDispatcher(String arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getScheme()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getServerName()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public int getServerPort()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public boolean isSecure()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void removeAttribute(String arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void setAttribute(String arg0, Object arg1)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void setCharacterEncoding(String arg0) throws UnsupportedEncodingException
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }
  
  public void setQueryString(String query)
    throws UnsupportedEncodingException
  {
    query = URLDecoder.decode(query, "UTF-8");
    Map<String, String> params = new HashMap<String, String>();
    String[] qchunks = query.split("&");
    for (String qchunk : qchunks)
    {
      String[] param = qchunk.split("=");
      if (param.length == 2)
      {
        params.put(param[0], param[1]);
      }
      else
      {
        params.put(qchunk, "");
      }
    }

    this.parameterMap = params;
  }
  
  public void setRequestString(String requestString)
  {
    this.requestString = requestString;
  }

}
