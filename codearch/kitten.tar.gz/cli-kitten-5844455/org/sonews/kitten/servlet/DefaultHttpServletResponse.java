/*
 *  Kitten
 *  Copyright 2008, 2009 Christian Lins <cli@openoffice.org>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.sonews.kitten.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Locale;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Christian Lins
 */
public class DefaultHttpServletResponse implements HttpServletResponse
{

  private String                     ctype  = "text/html";
  private DefaultServletOutputStream out    = new DefaultServletOutputStream();
  private PrintWriter                outw   = null;
  private int                        status = 0;
  
  public void addCookie(Cookie arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void addDateHeader(String arg0, long arg1)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void addHeader(String arg0, String arg1)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void addIntHeader(String arg0, int arg1)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public boolean containsHeader(String arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String encodeRedirectURL(String arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  @Deprecated
  public String encodeRedirectUrl(String url)
  {
    return encodeRedirectURL(url);
  }

  public String encodeURL(String arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  @Deprecated
  public String encodeUrl(String url)
  {
    return encodeURL(url);
  }

  public void sendError(int arg0, String arg1) throws IOException
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void sendError(int arg0) throws IOException
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void sendRedirect(String arg0) throws IOException
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void setDateHeader(String arg0, long arg1)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void setHeader(String arg0, String arg1)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void setIntHeader(String arg0, int arg1)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public int getStatus()
  {
    return this.status;
  }
  
  public void setStatus(int status)
  {
    this.status = status;
  }

  @Deprecated
  public void setStatus(int status, String str)
  {
    throw new UnsupportedOperationException("Not supported. Deprecated");
  }

  public void flushBuffer() throws IOException
  {
    this.out.flush();
    if(this.outw != null)
      this.outw.flush();
  }

  public int getBufferSize()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getCharacterEncoding()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public String getContentType()
  {
    return this.ctype;
  }

  public Locale getLocale()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public ServletOutputStream getOutputStream() throws IOException
  {
    return this.out;
  }

  public PrintWriter getWriter() throws IOException
  {
    if(outw == null)
    {
      outw = new PrintWriter(out);
    }
    return outw;
  }

  public boolean isCommitted()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void reset()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void resetBuffer()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void setBufferSize(int arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void setCharacterEncoding(String arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void setContentLength(int arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void setContentType(String contentType)
  {
    this.ctype = contentType;
  }

  public void setLocale(Locale arg0)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

}
