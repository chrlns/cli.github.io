/*
 *  Kitten
 *  Copyright 2008, 2009 Christian Lins <cli@openoffice.org>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.sonews.kitten;

import org.sonews.kitten.daemon.ContextMapping;
import org.sonews.kitten.daemon.TCPKitten;

/**
 * Main entrypoint for standalone Kitten.
 * @author Christian Lins
 */
public class Main
{

  public static final String VERSION = "kitten/0.2.0beta1";
  
  public static volatile String DOCUMENT_ROOT = ".";
  
  /**
   * @param args the command line arguments
   */
  public static void main(String[] args)
  {
    
    for(int n = 0; n < args.length; n++)
    {
      if(args[n].equals("-h") || args[n].equals("-help"))
      {
        printArguments();
        return;
      }
      if(args[n].equals("-root"))
      {
        DOCUMENT_ROOT = args[++n];
      }
      else if(args[n].equals("-s"))
      { // Parameter expects: servletclass@context
        String[] servlet = args[++n].split("@");
        setServletContext(servlet[0], servlet[1]);
      }
    }
    
    new TCPKitten(8080).start();
    System.out.println(VERSION + " started");
  }
  
  private static boolean setServletContext(String servletClassName, String context)
  {
    try
    {
      Class<?> clazz = Class.forName(servletClassName);
      ContextMapping.getInstance().setServletFor(clazz, context);
    }
    catch(InstantiationException ex)
    {
      System.err.println(ex);
    }
    catch(IllegalAccessException ex)
    {
      System.err.println(ex);
    }
    catch(ClassNotFoundException ex)
    {
      System.err.println(ex);
    }
    catch(NoClassDefFoundError err)
    {
      System.err.println(err);
    }
    return false;
  }
  
  private static void printArguments()
  {
    System.out.println(Resource.getAsString("helpers/usage", true));
  }

}
