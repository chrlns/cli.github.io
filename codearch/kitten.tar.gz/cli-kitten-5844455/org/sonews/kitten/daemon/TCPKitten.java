/*
 *  Kitten
 *  Copyright 2008, 2009 Christian Lins <cli@openoffice.org>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.sonews.kitten.daemon;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * The daemon thread.
 * @author Christian Lins
 */
public class TCPKitten extends Thread
{

  private int       port;
  private boolean   running;
  
  public TCPKitten(int port)
  {
    this.port         = port;
    this.running      = true;
  }
  
  @Override
  public void run()
  {
    // The TCPKitten listens on a socket for incoming connections.
    // Per default all incoming connections are processed by a HttpServlet
    // that directs the connections to more specific servlets using
    // the context mappings.
    
    try
    {
      ServerSocket serverSocket = new ServerSocket(port);
      
      try
      {
        while(running)
        {
          Socket socket = serverSocket.accept();

          BufferedInputStream  in  = new BufferedInputStream(socket.getInputStream());
          BufferedOutputStream out = new BufferedOutputStream(socket.getOutputStream());
          
          // Add servlet in processing queue
          HttpServletRunner runner = new HttpServletRunner(in, out);
          new Thread(runner).start(); // TODO: Do not spawn that many threads
        }
      }
      catch(Exception ex)
      {
        System.err.println(ex.getLocalizedMessage());
      }
    }
    catch(IOException ex)
    {
      ex.printStackTrace();
    }
  }
  
}
