/*
 *  Kitten
 *  Copyright 2008, 2009 Christian Lins <cli@openoffice.org>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.sonews.kitten.daemon;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServlet;

/**
 * With the ContextMapping class Kitten is able to choose the fitting
 * application servlet using the connection type and connection port.
 * @author Christian Lins
 */
public class ContextMapping
{
  
  private static final ContextMapping instance = new ContextMapping();
  
  public static ContextMapping getInstance()
  {
    return instance;
  }
  
  private Map<String, HttpServlet> mappings = new HashMap<String, HttpServlet>();
  
  private ContextMapping() 
  {
    FileInputStream fin = null;
    BufferedReader in = null;

    try
    {
      // Load context.map file that contains the context mappings
      fin = new FileInputStream("context.map");
      in  = new BufferedReader(new InputStreamReader(fin));
      
      String line = in.readLine();
      while(line != null)
      {
        String[] lineToks = line.split("=");
        
        // Load the Servlet class
        try
        {
          Class<?> clazz = Class.forName(lineToks[1]);
          setServletFor(clazz, lineToks[0]);
        }
        catch(ClassNotFoundException ex)
        {
          System.out.println("ClassNotFoundException: " + lineToks[1]);
        }
        
        line = in.readLine();
      }
    }
    catch(FileNotFoundException ex)
    {
      System.out.println("ContextMapping file context.map not found!");
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
    }
    finally
    {
      try
      {
        if(in != null)
          in.close();
        
        if(fin != null)
          fin.close();
      }
      catch(IOException ex)
      {
        throw new RuntimeException(ex);
      }
    }
  }
  
  public HttpServlet getServletFor(String context)
  {
    try
    {      
      HttpServlet servlet = this.mappings.get(context);
      if(servlet == null)
      {
        System.out.println("No mapping found for context " + context);
        
        int lastSlashIdx = context.lastIndexOf("/");
        if(lastSlashIdx > 0)
        {
          context = context.substring(0, lastSlashIdx);
          return getServletFor(context);
        }
        else
        {
          return null;
        }
      }
      else
      {
        return servlet;
      }
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
      return null;
    }
  }
  
  public void setServletFor(Class<?> clazz, String context)
    throws IllegalAccessException, InstantiationException
  {
    if(!context.startsWith("/"))
      context = "/" + context;

    this.mappings.put(context, (HttpServlet)clazz.newInstance());
    System.out.println("Using " + clazz + " for context '" + context + "'");
  }
  
}
