/*
 *  Kitten
 *  Copyright 2008, 2009 Christian Lins <cli@openoffice.org>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.sonews.kitten.daemon;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServlet;
import org.sonews.kitten.servlet.DefaultHttpServletRequest;
import org.sonews.kitten.servlet.DefaultHttpServletResponse;
import org.sonews.kitten.servlet.DefaultServletOutputStream;
import org.sonews.kitten.servlet.NoContextServlet;
import org.sonews.kitten.servlet.ServletErrorResponse;

/**
 *
 * @author Christian Lins
 */
public class HttpServletRunner implements Runnable
{
  
  public static final String NEWLINE = "\r\n";
  
  private InputStream  ins;
  private OutputStream outs;
  
  public HttpServletRunner(InputStream in, OutputStream out)
  {
    this.ins  = in;
    this.outs = out;
  }
  
  @Override
  public void run()
  {
    try
    {
      request(ins, outs);
    }
    catch(IOException ex)
    {
      ex.printStackTrace();
    }
  }
  
    /**
   * Parses the HTTP header, reads all input data and calls the appropriate
   * requestGET or requestPOST methods.
   * @param in
   * @param out
   */
  public void request(InputStream ins, OutputStream outs)
    throws IOException
  {
    outs = new BufferedOutputStream(outs);
    BufferedReader in  = new BufferedReader(new InputStreamReader(ins));
    PrintWriter    out = new PrintWriter(outs);
    
    Map<String, String> header = new HashMap<String, String>();
    
    String   line    = in.readLine();
    String[] lineTok = line.split(" ");
    String   method  = lineTok[0];
    String[] query = lineTok[1].split("\\?");
   
    
    // Determine Servlet to handle this request
    HttpServlet servlet = ContextMapping.getInstance().getServletFor(query[0]);
    if(servlet == null) // No context found
      servlet = new NoContextServlet();
    
    for(;;)
    {
      line    = in.readLine();
      if(line.equals(""))
        break;
      lineTok = line.split(":", 2);
      header.put(lineTok[0].trim(), lineTok[1].trim());
    }
    
    DefaultHttpServletRequest  req  = new DefaultHttpServletRequest();
    DefaultHttpServletResponse resp = new DefaultHttpServletResponse();

    // Set request values
    req.setMethod(method);
    req.setRequestString(query[0]);
    if(query.length == 2)
      req.setQueryString(query[1]);
    
    try
    {
      // Call the Servlet's methods
      servlet.service(req, resp);
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
      resp = new ServletErrorResponse(ex);
    }
      
    // Send response to client
    byte[] raw = ((DefaultServletOutputStream)resp.getOutputStream())
        .toByteArray();
      
    // First line
    out.print("HTTP/1.1 ");
    out.print(resp.getStatus());
    out.print(" OK\r\n");
      
    // Content-Type
    out.print("Content-Type: ");
    out.print(resp.getContentType());
    out.print(NEWLINE);

    // Content-Length
    out.print("Content-Length: ");
    out.print(raw.length);
    out.print(NEWLINE);

    // Connection
    out.print("Connection: close");
    out.print(NEWLINE);

    // And finally the content
    out.print(NEWLINE);
    out.flush();
    outs.write(raw); // PrintWriter has no such method so we 
    outs.flush();    // write to OutputStream directly.

    out.flush();
    out.close();
    in.close();
  }
  
}
