/*
 *  Javid
 *  Copyright (C) 2008 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package javid;

import java.io.InputStream;
import java.net.URL;

import javax.swing.JApplet;

import javid.channel.Playlist;
import javid.channel.PlaylistPlayer;

/**
 * The applet for integration into websites.
 * @author Christian Lins (christian.lins@web.de)
 */
public class Applet extends JApplet
{
  public void init()
  {
    int flags = 0;
    
    // Load parameter
    String  param  = null;
    boolean random = false;
    
    // --random
    if(getParameter(Main.PARAM_RANDOM) != null)
      random = true;
      
    // --playlist
    try
    {
      param = getParameter(Main.PARAM_PLAYLIST);
      if(param != null)
      {
        InputStream    in     = new URL(param).openStream();
        Playlist       list   = new Playlist(in);
        PlaylistPlayer player = new PlaylistPlayer(list, random);
        
        player.start();
      }
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
    }
  }
  
  public void start()
  {
    setSize(300, 200);
  }
}
