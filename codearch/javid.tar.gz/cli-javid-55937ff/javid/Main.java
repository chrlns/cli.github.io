/*
 *  Javid
 *  Copyright (c) 2007, 2008 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package javid;

import java.io.InputStream;
import java.net.URL;

import javax.swing.UIManager;
import javid.api.AudioPlayer;
import javid.api.VideoPlayer;
import javid.channel.Playlist;
import javid.channel.PlaylistPlayer;
import javid.gui.JavidFrame;

/**
 * The Main entrypoint for the standalone Javid player.
 * For use as applet use javid.Applet instead.
 * @author Christian Lins (christian.lins@web.de)
 */
public class Main
{
  public static final String PARAM_NO_VISUAL = "--no-visual";
  public static final String PARAM_PLAYLIST  = "--playlist";
  public static final String PARAM_RANDOM    = "--random";
  
  public static final String VERSION = "Javid/0.1";
  
  /** The current running audio player */
  public static AudioPlayer AudioPlayer = null;
  
  /** The current running video player */
  public static VideoPlayer VideoPlayer = null;
  
  /**
   * @param args
   */
  public static void main(String[] args)
    throws Exception
  {
    System.out.println(VERSION);
    
    boolean random = false;
    
    for(int n = 0; n < args.length; n++)
    {
      if(args[n].equals(PARAM_PLAYLIST))
      {
        InputStream    in     = new URL(args[++n]).openStream();
        Playlist       list   = new Playlist(in);
        PlaylistPlayer player = new PlaylistPlayer(list, random);
      
        player.start();
      }
      else if(args[n].equals(PARAM_RANDOM))
        random = true;
    }
    
    // Load stunning Nimbus LookAndFeel if available
    try
    {
      for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
      {
        if ("Nimbus".equals(info.getName()))
        {
          UIManager.setLookAndFeel(info.getClassName());
          break;
        }
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }

    new JavidFrame().setVisible(true);
  }

}
