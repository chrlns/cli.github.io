/*
 *  Javid
 *  Copyright (c) 2007 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package javid.channel.rss;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

import org.jdom.Document;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;

/**
 * Class loading RSS Feeds using the following specs:
 * - http://www.rssboard.org/rss-specification
 * - http://search.yahoo.com/mrss
 * - http://www.kbcafe.com/rss/usm.html
 * @author Christian Lins (christian.lins@web.de)
 */
public class RSSFeed
{
  public RSSFeed(URL url)
    throws IOException, JDOMException
  {
    URLConnection conn = url.openConnection();
    load(conn.getInputStream());
  }

  public RSSFeed(String urlStr)
    throws IOException, JDOMException, MalformedURLException
  {
    this(new URL(urlStr));
  }

  public RSSFeed(InputStream input)
    throws IOException, JDOMException
  {
    load(input);
  }
  
  private void load(InputStream in)
    throws IOException, JDOMException
  {
    Document doc = new SAXBuilder().build(in);
  }
}
