/*
 *  Javid
 *  Copyright (c) 2008 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package javid.channel;

import java.net.URL;
import java.util.Random;

import javid.api.Controlable;
import javid.audio.flac.apps.Player;
import javid.audio.mp3.Mp3Stream;
import javid.gui.ToolBar;
import javid.io.SupportedFilesFilter;

public class PlaylistPlayer 
  extends Thread
  implements Controlable
{
  private Playlist list;
  private boolean  random;
  private Thread   player;
  private boolean  playOnStart = false;
  
  public PlaylistPlayer(Playlist list, boolean random)
  {
    this.list   = list;
    this.random = random;
  }
  
  public void run()
  {
    int currentItem = 0;
    if(random)
      currentItem = new Random().nextInt(list.size());
    
    for(;;)
    {
      if(currentItem >= list.size())
      {
        currentItem = 0;
        try
        {
          Thread.sleep(1000);
        }catch(Exception e){}
      }
      
      String filename = list.get(currentItem++);
      
      try
      {
        /*if(SupportedFilesFilter.isMP3File(new URL(filename).openStream()))
        {
          player = new Mp3Stream(new URL(filename).openStream());
        }
        else */if(SupportedFilesFilter.isFLACFile(new URL(filename).openStream()))
        {
          player = new Player(new URL(filename).openStream());
        }
        else
        {
          System.err.println(filename + " is currently not supported!");
          continue;
        }
        
        // Start player and wait for it to end
        System.out.println("Start playing " + filename);
        ToolBar.getInstance().setPlayingThread(this);
        
        player.start();
        if(!playOnStart)
          player.suspend();
        else
          playOnStart = false;
       
        player.join();
      }
      catch(Exception ex)
      {
        ex.printStackTrace();
      }
    }
  }
  
  // Controlable methods
  public void pausePlayback()
  {
    System.out.println("Pause playlist player");
    player.suspend();
  }
  
  public void startPlayback()
  {
    System.out.println("Resume playlist player");
    player.resume();
  }
  
  public void seekBackward(int samples)
  {
    
  }
  
  public void seekForward(int samples)
  {
    
  }
  
  public void stepBackward()
  {
    
  }
  
  public void stepForward()
  {
    playOnStart = true;
    player.stop();
  }
  
  public void stopPlayback()
  {
    
  }
}
