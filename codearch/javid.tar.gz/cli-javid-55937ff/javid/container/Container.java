package javid.container;

import java.io.IOException;
import java.io.InputStream;

import javid.container.mpeg.MPEGContainer;
import javid.container.ogg.OggContainer;

public abstract class Container
{
  public static boolean checkMagic(byte[] magic, byte[] buffer)
  {
    for(int n = 0; n < magic.length; n++)
    {
      if(buffer[n] != magic[n])
        return false;
    }
    return true;
  }
  
  public static boolean isSupported(InputStream in)
    throws IOException
  {
    byte[] buffer = new byte[32];
    in.read(buffer);
    
    // Check for Ogg-Container
    if(checkMagic(OggContainer.MAGIC, buffer))
      return true;
    
    // Check for MPEG-Container
    if(checkMagic(MPEGContainer.MAGIC, buffer))
      return true;
    
    in.close();
    
    return false;
  }
  
  public abstract String getName();
}
