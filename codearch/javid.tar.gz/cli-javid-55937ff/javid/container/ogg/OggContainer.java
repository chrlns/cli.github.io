package javid.container.ogg;

import java.io.InputStream;

import javid.container.Container;

/**
 * The Ogg Container format aims for a generic, linear media
 * transport format to enable both file-based storage and stream-based
 * transmission of one or several interleaved media streams independent
 * of the encoding format of the media data.  Such an encapsulation
 * format needs to provide:
 *
 *  o  framing for logical bitstreams.
 *  o  interleaving of different logical bitstreams.
 *  o  detection of corruption.
 *  o  recapture after a parsing error.
 *  o  position landmarks for direct random access of arbitrary positions
 *     in the bitstream.
 *  o  streaming capability (i.e., no seeking is needed to build a 100%
 *     complete bitstream).
 *  o  small overhead (i.e., use no more than approximately 1-2% of
 *     bitstream bandwidth for packet boundary marking, high-level
 *     framing, sync and seeking).
 *  o  simplicity to enable fast parsing.
 *  o  simple concatenation mechanism of several physical bitstreams.
 *  
 * @author Christian Lins (christian.lins@web.de)
 */
public class OggContainer extends Container
{
  public static final byte[] MAGIC = "OggS".getBytes();
  
  private InputStream in;
  
  public OggContainer(InputStream in)
  {
    this.in = in;
  }
  
  @Override
  public String getName()
  {
    return "Physical (Ogg) Bitstream";
  }

}
