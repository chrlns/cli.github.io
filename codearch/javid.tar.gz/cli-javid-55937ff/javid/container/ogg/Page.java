package javid.container.ogg;

class Page
{
  public static final byte[] CAPTURE_PATTERN = new byte[4];
  public static final byte   VERSION         = 0;   // Currently zero
  
  static
  {
    CAPTURE_PATTERN[0] = 0x4F;  // 'O'
    CAPTURE_PATTERN[1] = 0x67;  // 'g'
    CAPTURE_PATTERN[2] = 0x67;  // 'g'
    CAPTURE_PATTERN[3] = 0x53;  // 'S'
  }
}
