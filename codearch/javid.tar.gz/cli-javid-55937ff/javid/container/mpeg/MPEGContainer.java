package javid.container.mpeg;

import javid.container.Container;

public class MPEGContainer extends Container
{
  public static final byte[] MAGIC = new byte[4];
  
  static
  {
    MAGIC[0] = 0x00;
    MAGIC[1] = 0x00;
    MAGIC[2] = 0x01;
    MAGIC[3] = (byte)0xBA;
  }
  
  @Override
  public String getName()
  {
    return "MPEG Container";
  }
}
