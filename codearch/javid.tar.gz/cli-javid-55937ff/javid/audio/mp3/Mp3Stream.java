/*
 *  Javid
 *  Copyright (c) 2008 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package javid.audio.mp3;

import java.io.DataInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Arrays;

import javid.io.EnhancedDataInputStream;

public class Mp3Stream extends Thread
{
  public static final byte[] MAGIC_ID3 = "ID3".getBytes();
  public static final char   SCAN_SYNC = 0x7FF; // 11 Bits '1'
  
  private EnhancedDataInputStream in;
  
  public Mp3Stream(InputStream in)
  {
    this.in = new EnhancedDataInputStream(in);
    
    setPriority(Thread.MAX_PRIORITY);
  }
  
  private boolean readHeader()
    throws IOException
  {
    byte buf = 0;
    
    // Scan for sync
    int  pos   = 0;
    byte id    = 0;
    byte layer = 0;
    
    do
    {
      pos = in.scanTo(SCAN_SYNC);
      buf = in.readByte();
      id  = (byte)(buf >> 6);
      layer = (byte)((0x30 & buf) >> 4);
    }
    while(id != 0 && id != 2 && id != 3
        && layer != 1 && layer != 2 && layer != 3);
    
    System.out.println("Frame at: " + pos);
    System.out.println("MPEG-ID: " + id);
    System.out.println("Layer:" + layer);
    
    return true;
  }
  
  public void run()
  {
    try
    {
      readHeader();
    }
    catch(IOException e)
    {
      e.printStackTrace();
    }
  }
}
