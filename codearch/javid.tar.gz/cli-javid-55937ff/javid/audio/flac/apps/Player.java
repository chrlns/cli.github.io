package javid.audio.flac.apps;

/* libFLAC - Free Lossless Audio Codec library
 * Copyright (C) 2000-2003  Josh Coalson
 * Partly Copyright (C) 2008 by Christian Lins
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 *
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the
 * Free Software Foundation, Inc., 59 Temple Place - Suite 330,
 * Boston, MA  02111-1307, USA.
 */

import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Vector;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineListener;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;

import javid.api.AudioPlayer;
import javid.audio.flac.FLACDecoder;
import javid.audio.flac.FrameListener;
import javid.audio.flac.PCMProcessor;
import javid.audio.flac.frame.Frame;
import javid.audio.flac.metadata.Metadata;
import javid.audio.flac.metadata.StreamInfo;
import javid.audio.flac.util.ByteData;
import javid.gui.Timeline;

/**
 * Play a FLAC file application.
 * @author Josh Coalson
 * @author Christian Lins (christian.lins@web.de)
 */
public class Player 
  extends AudioPlayer 
  implements FrameListener, PCMProcessor
{
  private FLACDecoder          decoder;
  private AudioFormat          fmt;
  private InputStream          in;
  private DataLine.Info        info;
  private SourceDataLine       line;
  private Vector<LineListener> listeners = new Vector<LineListener>();
  
  public Player(File file)
    throws IOException
  {
    this(new FileInputStream(file));
  }
  
  public Player(InputStream in)
  {
    super(in);
    this.in = in;
  }
  
  /**
   * Process metadata records.
   * @param metadata the metadata block
   * @see javid.audio.flac.FrameListener#processMetadata(javid.audio.flac.metadata.MetadataBase)
   */
  public void processMetadata(Metadata metadata) 
  {
    //System.out.println(metadata);

  }
  
  /**
   * Process data frames.
   * @param frame the data frame
   * @see javid.audio.flac.FrameListener#processFrame(javid.audio.flac.frame.Frame)
   */
  public void processFrame(Frame frame) 
  {
    long maxSamples = decoder.getStreamInfo().getTotalSamples();

    int sec = (int)(frame.header.sampleNumber / frame.header.sampleRate);

    Timeline.getInstance().setMax((int)(maxSamples / frame.header.sampleRate));
    Timeline.getInstance().update(sec);
  }
 
  /**
   * Called for each frame error detected.
   * @param msg   The error message
   * @see javid.audio.flac.FrameListener#processError(java.lang.String)
   */
  public void processError(String msg) 
  {
    System.out.println(msg);
  }
  
  public void addListener(LineListener listener)
  {
    listeners.add(listener);
  }

  /**
   * Decode and play an input FLAC file.
   * @param inFileName    The input FLAC file name
   * @throws IOException  Thrown if error reading file
   * @throws LineUnavailableException Thrown if error playing file
   */
  public void decode() 
    throws IOException, LineUnavailableException
  {
    decoder = new FLACDecoder(in);
    decoder.addPCMProcessor(this);
    decoder.addFrameListener(this);
    try
    {
      decoder.decode();
    }
    catch (EOFException e)
    {
      // skip
    }

    line.drain();
    line.close();

    //  We're going to clear out the list of listeners as well, so that everytime through
    //  things are basically at the same starting point.
    listeners.clear();
  }

  /**
   * Process the StreamInfo block.
   * @param streamInfo the StreamInfo block
   * @see javid.audio.flac.PCMProcessor#processStreamInfo(javid.audio.flac.metadata.StreamInfo)
   */
  public void processStreamInfo(StreamInfo streamInfo)
  {
    try
    {
      fmt = streamInfo.getAudioFormat();
      info = new DataLine.Info(SourceDataLine.class, fmt,
          AudioSystem.NOT_SPECIFIED);
      line = (SourceDataLine) AudioSystem.getLine(info);

      //  Add the listeners to the line at this point, it's the only
      //  way to get the events triggered.
      int size = listeners.size();
      for (int index = 0; index < size; index++)
        line.addLineListener((LineListener) listeners.get(index));

      line.open(fmt, AudioSystem.NOT_SPECIFIED);
      line.start();
    }
    catch (LineUnavailableException e)
    {
      e.printStackTrace();
    }
  }

  /**
   * Process the decoded PCM bytes.
   * @param pcm The decoded PCM data
   * @see javid.audio.flac.PCMProcessor#processPCM(javid.audio.flac.util.ByteSpace)
   */
  public void processPCM(ByteData pcm)
  {
    line.write(pcm.getData(), 0, pcm.getLen());
  }

  public void removeListener(LineListener listener)
  {
    listeners.removeElement(listener);
  }

  /**
   * The main routine.
   * <p>args[0] is the input file name
   * @param args  Command line arguments
   */
  public void run()
  {
    try
    {
      decode();
    }
    catch (FileNotFoundException e)
    {
      e.printStackTrace();
    }
    catch (IOException e)
    {
      e.printStackTrace();
    }
    catch (LineUnavailableException e)
    {
      e.printStackTrace();
    }
  }
  
  // Controlable methods
  public void pausePlayback()
  {
    
  }
  
  public void startPlayback()
  {
    
  }
  
  public void seekBackward(int samples)
  {
    
  }
  
  public void seekForward(int samples)
  {
    
  }
  
  public void stepBackward()
  {
    
  }
  
  public void stepForward()
  {
    
  }
  
  public void stopPlayback()
  {
    
  }
}
