/*
 *  Javid
 *  Copyright (C) 2007 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*-----------------------------------------------------------------------
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *----------------------------------------------------------------------
 *
 *  Alan Blount 3/7/00
 */

package javid.audio.player;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PipedOutputStream;

import javid.audio.decoder.JavaLayerException;

/**
 * The <code>EightBitAudioDevice</code> implements an audio
 * device by using the sun.audio.AudioPlayer class
 * 
 * @author Alan Blount
 */
public class EightBitAudioDevice extends AudioDeviceBase
{
	private int outputCapacity = 8192 * 4;
	private byte[] byteBuf = new byte[1024];

	public BigPipedInputStream pis;
	OutputStream pos;

	public boolean isEightBitEightKhzMuLaw() {
		return true;
	}

	protected void openImpl() throws JavaLayerException {
		try {
			pis = new BigPipedInputStream(outputCapacity);
			pos = new PipedOutputStream(pis);

		} catch (IOException ex) {
			System.out.println("Trouble creating pis/pos " + ex);
		}

		play();

		// Set decoder to create 8-bit ulaw audio
		getDecoder().getParams().setDownconvert();
	}

	protected void closeImpl() { }
	
	protected void writeImpl(short[] samples, int offset, int len) throws JavaLayerException {

		byte[] output = getByteArray(len);
		int count = toByteArray(samples, offset, len, output, getDecoder().getOutputChannels() > 1);
		
		try {
			//System.out.println("Audio Writing " + count + " buf fill: " + pis.available());
			pos.write(output, 0, count);
		} catch (IOException ex) {
			// System.out.println("Trouble writing to pis/pos " + ex);		
			throw new JavaLayerException("No audio possible...", ex);
		}
		
		// System.out.println("writeImpl done");
	}
	
	protected byte[] getByteArray(int length) {
		if (byteBuf.length < length) {
			byteBuf = new byte[length + 1024];
		}
		return byteBuf;
	}
	
	int toByteArray(short[] samples, int offset, int len, byte[] b, boolean stereoToMono) {
		int idx = 0, preMu, signBit;

		while (len-- > 0) {

			if (stereoToMono) {
				preMu = (samples[offset++] + samples[offset++]) >> 1;
				len--;
			} else {
				preMu = samples[offset++];
			}

			// Cap preMu
			preMu = preMu < -32767 ? -32767 : preMu > 32767 ? 32767 : preMu;

            if (preMu >= 0) {
                signBit = 128;
            } else {
                preMu = -preMu;
                signBit = 0;
            }

            preMu = 132 + preMu >> 3;
            if (preMu < 32)
                b[idx++] = (byte)(signBit | 0x70 | 31 - preMu);
            else if (preMu < 64)
                b[idx++] = (byte)(signBit | 0x60 | 31 - (preMu >> 1));
            else if (preMu < 128)
                b[idx++] = (byte)(signBit | 0x50 | 31 - (preMu >> 2));
            else if (preMu < 256)
                b[idx++] = (byte)(signBit | 0x40 | 31 - (preMu >> 3));
            else if (preMu < 512)
                b[idx++] = (byte)(signBit | 0x30 | 31 - (preMu >> 4));
            else if (preMu < 1024)
                b[idx++] = (byte)(signBit | 0x20 | 31 - (preMu >> 5));
            else if (preMu < 2048)
                b[idx++] = (byte)(signBit | 0x10 | 31 - (preMu >> 6));
            else if (preMu < 4096)
                b[idx++] = (byte)(signBit | 31 - (preMu >> 7));
            else
                b[idx++] = (byte)signBit;
		}
		return idx;
	}
	
	protected void flushImpl() {
		// FIXME
	}
	
	public int getBufferPosition() {		
		try
		{
			return pis.available() / 8;
		}
		catch(Exception e)
		{
			System.out.println("getPosition--> "+e);
		}
		return -1;
	}

	public int getPosition()
	{
		return -1;
	}
		

	public float getFillRatio() {
		float ret = 0;
		try {
			ret = (float)pis.available() / (float) outputCapacity;
		} catch (IOException ex) {
		}
		return ret;
	}

	/**
	 * Start player playing
	 */
	public void play() {
		try
		{
			//AudioPlayer.player.start(pis);
		}
		catch(Exception e)
		{
			System.out.println("Could not start AudioPlayer (sun.audio)");
		}
	}

	/**
	 * Stop player playing
	 */
	public void stop() {
		try {
			pis.close();
			pos.close();
		} catch (IOException ex) { System.out.println("EightBitAudioDevice::stop(): Trouble--caught IOException"); }
		//AudioPlayer.player.stop(pis);
	}

	/**
	 * Runs a short test by playing a short silent sound. 
	 */
	public boolean test() throws JavaLayerException {
		return true;
	}
}
