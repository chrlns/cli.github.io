/*
 *  Javid
 *  Copyright (c) 2007, 2008 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package javid.io;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.Charset;

import javax.swing.ImageIcon;

/**
 * Provides static methods for loading resources.
 * @author Christian Lins (christian.lins@web.de)
 */
public class Resource
{
  /**
   * Laedt eine Bilddatei von einer lokalen Resource.
   * @param name
   * @return Gibt null zurueck, falls das Bild nicht
   * gefunden oder geladen werden konnte.
   */
  public static ImageIcon getImage(String name)
  {
    ClassLoader cl = null;
    try
    {
      cl = name.getClass().getClassLoader();
      if(cl == null)
        cl = ClassLoader.getSystemClassLoader();
    }
    catch(Exception e)
    {
      return null;
    }
    
    URL url = cl.getResource(name);
    
    if(url == null)
      return null;
    
    return new ImageIcon(url);
  }
  
  /**
   * Laedt eine Resource und gibt einen Verweis auf sie als
   * URL zurueck.
   * @return
   */
  public static URL getAsURL(String name)
  {
    return name.getClass().getClassLoader().getResource(name);
  }
  
  /**
   * Laedt eine Resource und gibt einen InputStream darauf
   * zurueck.
   * @param name
   * @return
   */
  public static InputStream getAsStream(String name)
  {
    try
    {
      URL url = getAsURL(name);
      return url.openStream();
    }
    catch(IOException e)
    {
      e.printStackTrace();
      return null;
    }
  }

  /**
   * Laedt eine Textdatei komplett in einen String.
   */
  public static String getAsString(String name, boolean withNewline)
  {
    try
    {
      BufferedReader in  = new BufferedReader(
          new InputStreamReader(getAsStream(name), Charset.forName("UTF-8")));
      StringBuffer   buf = new StringBuffer();

      for(;;)
      {
        String line = in.readLine();
        if(line == null)
          break;

        buf.append(line);
        if(withNewline)
          buf.append('\n');
      }

      return buf.toString();
    }
    catch(Exception e)
    {
      return null;
    }
  }
}
