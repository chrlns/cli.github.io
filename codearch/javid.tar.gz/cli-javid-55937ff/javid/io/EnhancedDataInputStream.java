package javid.io;

import java.io.DataInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;

public class EnhancedDataInputStream extends DataInputStream
{
  public EnhancedDataInputStream(InputStream in)
  {
    super(in);
  }
  
  /**
   * Scans to the specified pattern. Align at two-byte borders.
   * @param pattern
   * @return
   */
  public int scanTo(char pattern)
    throws EOFException, IOException
  {
    int pos = 0;
    while((readChar() & pattern) != pattern)
      pos += 2;
    
    return pos;
  }
}
