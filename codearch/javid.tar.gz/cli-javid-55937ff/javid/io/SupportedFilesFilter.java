package javid.io;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.swing.filechooser.FileFilter;

import javid.container.Container;

public class SupportedFilesFilter extends FileFilter
{
  public static final byte[] MAGIC_FLAC = "fLaC".getBytes();
  public static final byte[] MAGIC_MP3  = "ID3".getBytes();
  
  private static boolean isMediaFile(File file)
    throws IOException
  {    
    if(isMP3File(file))
      return true;
    
    if(isFLACFile(file))
      return true;
    
    return false;
  }
  
  public static boolean isFLACFile(File file)
    throws IOException
  {
    FileInputStream in = new FileInputStream(file);
    return isFLACFile(in);
  }
  
  public static boolean isMP3File(File file)
    throws IOException
  {
    FileInputStream in = new FileInputStream(file);
    return isMP3File(in);
  }
  
  public static boolean isFLACFile(InputStream in)
    throws IOException
  {
    byte[] buffer = new byte[4];
    
    in.read(buffer);
    in.close();
    
    if(Container.checkMagic(MAGIC_FLAC, buffer))
      return true;
    
    return false;
  }
  
  public static boolean isMP3File(InputStream in)
    throws IOException
  {
    byte[] buffer = new byte[3];
    
    in.read(buffer, 0, buffer.length); // The other read method does not block
    in.close();
    
    if(Container.checkMagic(MAGIC_MP3, buffer))
      return true;
    
    return false;
  }
  
  @Override
  public boolean accept(File file)
  {
    try
    {
      return file.isDirectory() 
        || isMediaFile(file)
        || Container.isSupported(new FileInputStream(file));
    }
    catch(IOException ex)
    {
      System.err.println(ex.getLocalizedMessage());
      return false;
    }
  }

  @Override
  public String getDescription()
  {
    return "Supported media files";
  }

}
