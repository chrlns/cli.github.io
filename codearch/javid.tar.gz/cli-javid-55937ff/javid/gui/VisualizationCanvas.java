package javid.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;

import javax.swing.JComponent;

import javid.io.Resource;

public class VisualizationCanvas extends JComponent
{
  public VisualizationCanvas()
  {
    setPreferredSize(new Dimension(320, 240));
    setSize(new Dimension(320, 240));
  }
  
  public void paintComponent(Graphics g)
  {
    g.setColor(Color.BLACK);
    g.fillRect(0, 0, 1920, 1440);
    g.drawImage(
        Resource.getImage("resource/video-x-generic-large.png").getImage(), 
        getWidth() / 2 - 128, 
        getHeight() / 2 - 128, null);
  }
}
