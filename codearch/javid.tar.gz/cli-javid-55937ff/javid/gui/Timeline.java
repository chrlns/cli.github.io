/*
 *  Javid
 *  Copyright (C) 2007, 2008 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package javid.gui;

import java.awt.BorderLayout;
import java.awt.Font;

import javax.swing.JSlider;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.border.EmptyBorder;

public class Timeline extends JToolBar
{
  public static interface Listener
  {
    void update(int sec); 
  }
  
  private static Timeline instance = null;
  
  public synchronized static Timeline getInstance()
  {
    if(instance == null)
      instance = new Timeline();
    
    return instance;
  }
  
  private JSlider     slider          = new JSlider();
  private JTextField  txtCurrentTime  = new JTextField(6);
  
  private Timeline()
  {
    setLayout(new BorderLayout());
    add(txtCurrentTime, BorderLayout.WEST);
    add(slider, BorderLayout.CENTER);
    
    // Initialize components
    slider.setValue(0); // Start value 0
    txtCurrentTime.setBorder(new EmptyBorder(1,1,1,1));
    txtCurrentTime.setFont(new Font("Serif", 0, 9));
  }
  
  public void setMax(int maxSamples)
  {
    slider.setMaximum(maxSamples);
  }
  
  public void update(int sec)
  {
    slider.setValue(sec);
    
    // Format time
    int seconds = sec % 60;
    int hours   = sec / 3600;
    int minutes = sec / 60;
    txtCurrentTime.setText(hours + ":" + minutes + ":" + seconds);
  }
}
