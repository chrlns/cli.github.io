/*
 *  Javid
 *  Copyright (c) 2007, 2008 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package javid.gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.JButton;
import javax.swing.JToolBar;
import javax.swing.Timer;

import javid.api.Controlable;
import javid.io.Resource;

/**
 * The toolbar provides buttons for several actions of the media player.
 * @author Christian Lins (christian.lins@web.de)
 */
public class ToolBar extends JToolBar
{
  private static ToolBar instance = null;
  
  public static synchronized ToolBar getInstance()
  {
    if(instance == null)
      instance = new ToolBar();
    
    return instance;
  }
  
  private JButton     btnOpen     = new JButton();
  private JButton     btnStepBack = new JButton();
  private JButton     btnSeekBack = new JButton();
  private JButton     btnPlay     = new JButton();
  private JButton     btnStop     = new JButton();
  private JButton     btnSeekForw = new JButton();
  private JButton     btnStepForw = new JButton();
  private JButton     btnPlaylist = new JButton();
  private JButton     btnLibrary  = new JButton();
  private Controlable player      = null;
  private boolean     suspended   = true;
  
  private ToolBar()
  {
    btnOpen.setIcon(Resource.getImage("resource/document-open.png"));
    btnOpen.setBorderPainted(false);
    btnOpen.setToolTipText("Open media file or media stream");
    add(btnOpen);
    
    addSeparator();
    
    btnStepBack.setIcon(Resource.getImage("resource/media-skip-backward.png"));
    btnStepBack.setBorderPainted(false);
    add(btnStepBack);
    
    btnSeekBack.setIcon(Resource.getImage("resource/media-seek-backward.png"));
    btnSeekBack.setBorderPainted(false);
    add(btnSeekBack);
    
    btnPlay.setIcon(Resource.getImage("resource/media-playback-start.png"));
    btnPlay.setBorderPainted(false);
    btnPlay.setToolTipText("Play file or stream");
    add(btnPlay);
    
    btnStop.setIcon(Resource.getImage("resource/media-playback-stop.png"));
    btnStop.setBorderPainted(false);
    add(btnStop);
    
    btnSeekForw.setIcon(Resource.getImage("resource/media-seek-forward.png"));
    btnSeekForw.setBorderPainted(false);
    add(btnSeekForw);
    
    btnStepForw.setIcon(Resource.getImage("resource/media-skip-forward.png"));
    btnStepForw.setBorderPainted(false);
    add(btnStepForw);

    addSeparator();
    btnLibrary.setIcon(Resource.getImage("resource/user-home.png"));
    btnLibrary.setBorderPainted(false);
    btnLibrary.setToolTipText("Media library");
    add(btnLibrary);
    
    // Add action listener
    btnOpen.addMouseListener(new MouseAdapter()
    {
      @Override
      public void mouseClicked(MouseEvent event)
      {
        openButtonClicked(event);
      }
    });
    
    btnPlay.addMouseListener(new MouseAdapter()
    {
      public void mouseClicked(MouseEvent event)
      {
        playButtonClicked(event);
      }
    });
    
    btnStepForw.addMouseListener(new MouseAdapter()
    {
      public void mouseClicked(MouseEvent event)
      {
        if(player != null)
          player.stepForward();
      }
    });

    this.btnLibrary.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent e)
      {
        JavidFrame.getInstance().setCenterPanel(new LibraryPanel());
      }
    });
    
    // Add timer
    Timer timer = new Timer(250, new ActionListener()
    {
      public void actionPerformed(ActionEvent event)
      {
        if(player == null || suspended)
          btnPlay.setIcon(Resource.getImage("resource/media-playback-start.png"));
        else
          btnPlay.setIcon(Resource.getImage("resource/media-playback-pause.png"));
      }
    });
    timer.start();
  }
  
  public void setPlayingThread(Controlable player)
  {
    if(this.player != null)
      this.player.stopPlayback();
    
    this.player = player;
  }
  
  private void openButtonClicked(MouseEvent event)
  {
    new OpenMenu().show(btnOpen, 0, btnOpen.getHeight());
  }
  
  private void playButtonClicked(MouseEvent event)
  {
    if(suspended)
    {
      player.startPlayback();
    }
    else
    {
      player.pausePlayback();
    }
    
    suspended = !suspended;
  }
}
