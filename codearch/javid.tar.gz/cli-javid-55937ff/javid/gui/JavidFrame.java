/*
 *  Javid
 *  Copyright (c) 2007 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package javid.gui;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.DirectColorModel;
import java.io.FileInputStream;
import java.io.InputStream;

import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

import javid.Main;
import javid.audio.player.Player;
import javid.io.Resource;
import javid.video.mpeg1.CutBuffer;
import javid.video.mpeg1.IoTool;
import javid.video.mpeg1.MovieScreen;
import javid.video.mpeg1.MpegVideo;
import javid.video.mpeg1.VideoElement;

/**
 * The Player Frame.
 */
public class JavidFrame 
  extends JFrame 
{
  private static JavidFrame instance = null;

  public static JavidFrame getInstance()
  {
    return instance;
  }

  private InputStream inputStream = null;       // THE MPEG resource

  private int last_P_or_I = 0;        // last P or I frame;
  private final DirectColorModel cm = new DirectColorModel(24, 0xff0000, 0xff00, 0xff);

  private int Frame_nr = 0;       // The last frame in "EL_ARR[]"
  private final int MAXELEMENT = 5;     // Number of "Element"s in "EL_ARR[]"
  private final VideoElement EL_ARR[] = new VideoElement[MAXELEMENT]; // Small buffer for evt. frame rearangement

  private boolean playAfterLoad = false;      // Should it wait for entire file

  private MpegVideo videoDecoder;      // The video decoder
  private Player audioDecoder;       // The audio player/decoder
  private IoTool mpeg_stream;        // The stream with only video-frames

  private MovieScreen movieScreen = new MovieScreen();
  private boolean _stopping = false;      // Are we stopping the applet...
  private int playedSeconds = 0;
  private int playedFrames = 0;
  private JComponent centerPanel = null;
  
  public JavidFrame()
    throws Exception
  {
    instance = this;

    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setIconImage(Resource.getImage("resource/applications-multimedia.png").getImage());
    
  //  StreamSwitch switchstream = new StreamSwitch();
  //  switchstream.addStream(new Stream("Video", new FileInputStream("../kfee_auto.mpg")));
  //  switchstream.switchTo("Video");
//    inputStream = new CutBuffer(new FileInputStream("../lions.mpg"), true, false);
    
    setSize(360, 300);
    setCenterPanel(new VisualizationCanvas());
    setTitle(Main.VERSION);

    getContentPane().add(ToolBar.getInstance(), BorderLayout.NORTH);
    getContentPane().add(Timeline.getInstance(), BorderLayout.SOUTH);

    setVisible(true);
    
    doLayout();
   // setDim(getSize().width, getSize().height);
    //startAll();
    //movieScreen.playing = true;
  }

  public void setCenterPanel(JComponent comp)
  {
    if(this.centerPanel == null)
    {
      getContentPane().add(comp, BorderLayout.CENTER);
      this.centerPanel = comp;
    }

    if(comp.getClass().equals(this.centerPanel.getClass()))
    {
      getContentPane().remove(this.centerPanel);
      getContentPane().add(comp, BorderLayout.CENTER);
      this.centerPanel = comp;
    }

    repaint();
  }

  public boolean isStopped()
  {
    return _stopping;
  }

  public MpegVideo getVideoDecoder()
  {
    return videoDecoder;
  }

  public void resetVideo()
  {
    videoDecoder.stop();
    mpeg_stream = new IoTool((CutBuffer)inputStream, IoTool.TYPE_VIDEO);
    videoDecoder = new MpegVideo(this, mpeg_stream);
    videoDecoder.start();
  }

  /***
   * Start all the things that need to be started... DUH! ;)
   */
  private void startAll()
  {
    if (inputStream != null)
    {
      mpeg_stream  = new IoTool((CutBuffer)inputStream, IoTool.TYPE_VIDEO);
      videoDecoder = new MpegVideo(this, mpeg_stream);

      audioDecoder = null;
      
      try
      {
        //audioDecoder = new Player(inputStream);
      }
      catch(Exception e)
      {
        System.out.println(e);
      }
      
      // It seems that we does not need an audioDecoder...??
      //((CutBuffer)inputStream).setAudioPlayer(audioDecoder);
      ((CutBuffer)inputStream).start(); 

      movieScreen.init(mpeg_stream);

      if (!playAfterLoad)
        videoDecoder.start();
    }
    
    // Start refreshing timer
    // TODO: This is only a hack to get the movie running
    ActionListener task = new ActionListener()
    {
      public void actionPerformed(ActionEvent event)
      {
        repaint();
        playedFrames++;
        //System.out.println("FPS: " + ((CutBuffer)inputStream).getFramesPerSecond());
      }
    };
    
    ActionListener taskB = new ActionListener()
    {
      public void actionPerformed(ActionEvent event)
      {
        playedSeconds++;
        System.out.println("FPS: " + playedFrames / (float)playedSeconds);
        System.out.println("Start TS: " + ((CutBuffer)inputStream).getFirstTimeStamp());
        System.out.println("End TS: " + ((CutBuffer)inputStream).getLastTimeStamp());
      }
    };
    
    new Timer(1000 / 30, task).start();
    new Timer(1000, taskB).start();
  }

  public void onEOF()
  {
    if (!_stopping && playAfterLoad)
      videoDecoder.start();
  }
  
  /**
   *  Stop the whole player.
   */
  public synchronized void stop() 
  {
    System.out.println("JavidApplet::stop()");
    _stopping = true;

    // cleans up a lot of the memory in use...
    if (inputStream != null && inputStream instanceof CutBuffer)
      ((CutBuffer)inputStream).stop();

    if (videoDecoder != null)
      videoDecoder.stop();
    if (audioDecoder != null)
      audioDecoder.stop();

    videoDecoder = null;
    audioDecoder = null;

    // stop playing in the moviescreen
    //movieScreen.playing = false;

    movieScreen = null;
   // timeBar = null;
    mpeg_stream = null;
  }

  public long getLastVideoPts()
  {
    if (movieScreen != null)
      return movieScreen.getLastVPts();
    return -1;
  }

  public long getLastAudioPts()
  {
    if (movieScreen != null)
      return movieScreen.getLastAPts();
    return -1;
  }

  /**
   * This method is necessary because the scanner must have the possibility
   * to resize the applet and (possibly) the frame once he has recognized
   * the dimensions of the MPEG frames.
   * This method is called by the "ScanThread".
   */
  public void setDim(int width, int height) 
  {
    // produce the "MAXELEMENT" "Elements":
    for (int i = 0; i < MAXELEMENT; i++) 
    {
      EL_ARR[i] = new VideoElement(this, cm, width, height);
    }

  //  int frameWidth  = width + getInsets().left + getInsets().right;
  //  int frameHeight = height + getInsets().top + getInsets().bottom + toolbar.getHeight() + timeline.getHeight();
    
 //   setSize(frameWidth, frameHeight);

    doLayout();
    //pack();
    
  //  System.out.println("Video size: " + width + "x" + height + " (" + frameWidth + "x" + frameHeight + ")");
  }

  /**
   * The method "setPixels" expects the pixel data, the type and number
   * of the next frame in display order to change the pixel values of
   * the next image. It determins the number of the next frame in display
   * order (which differes from coding order) and passes it to the
   * "AnimatorThread" by means of the "Dispatcher".
   */
  public void setPixels(final int Pixels[][], final int f_idx, final int f_type, final long pts, final int Pic_rate) 
  {
    if (movieScreen == null)
      return;

    final VideoElement elem = EL_ARR[Frame_nr];
    elem.makePicture(Pixels/*, f_idx, f_type */);
    elem.setPts(pts);
    elem.setPicRate(Pic_rate);
    
    // put the frame into the list in display order:
    if (f_type == MpegVideo.B_TYPE)   // B - Frames are already in display order
      movieScreen.setElement(EL_ARR[Frame_nr]);
    else          // a P or I frame; they are not necessary in display order
    {
      movieScreen.setElement(EL_ARR[last_P_or_I]);
      last_P_or_I = Frame_nr;   // notice for later insertion;
    }

    Frame_nr = (Frame_nr + 1) % MAXELEMENT; // wrap around!
  }

  public Player getAudioPlayer()
  {
    return audioDecoder;
  }
}
