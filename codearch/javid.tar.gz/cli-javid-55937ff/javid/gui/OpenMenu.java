/*
 *  Javid
 *  Copyright (c) 2007, 2008 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package javid.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileInputStream;

import javax.swing.JFileChooser;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

import javid.audio.flac.apps.Player;
import javid.audio.mp3.Mp3Stream;
import javid.io.SupportedFilesFilter;

class OpenMenu extends JPopupMenu
{
  private JMenuItem mnuOpenFile   = new JMenuItem("Open file...");
  private JMenuItem mnuOpenStream = new JMenuItem("Open stream...");
  
  public OpenMenu()
  {
    add(mnuOpenFile);
    add(mnuOpenStream);
    
    mnuOpenFile.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent event)
      {
        openFile();
      }
    });
    
    mnuOpenStream.addActionListener(new ActionListener()
    {
      public void actionPerformed(ActionEvent event)
      {
        openStream();
      }
    });
  }
  
  private void openFile()
  {
    JFileChooser fc = new JFileChooser();
    fc.addChoosableFileFilter(new SupportedFilesFilter());
    
    if(fc.showOpenDialog(this) != JFileChooser.APPROVE_OPTION)
      return;
    
    File file = fc.getSelectedFile();
    try
    {
      if(SupportedFilesFilter.isMP3File(file))
      {
        Thread player = new Mp3Stream(new FileInputStream(file));
        player.start();
      }
      else if(SupportedFilesFilter.isFLACFile(file))
      {
        Player player = new Player(file);
        player.start();
      }
      else
      {
        System.err.println(file + " is currently not supported!");
      }
    }
    catch(Exception e)
    {
      e.printStackTrace();
    }
  }
  
  private void openStream()
  {
    
  }
}
