package javid.api;

public abstract class VideoPlayer 
  extends Thread
  implements Controlable
{

}
