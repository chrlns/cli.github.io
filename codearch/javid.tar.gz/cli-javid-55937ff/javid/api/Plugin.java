package javid.api;

/**
 * Every plugin must implement this interface in at least one class.
 * The Javid-Plugin-Manager will load the plugin using this interface
 * and retrieves the necessary information from this plugin.
 * @author Christian Lins (christian.lins@web.de)
 */
public interface Plugin
{
  public static final int TYPE_AUDIO      = 1;
  public static final int TYPE_CONTAINER  = 2;
  public static final int TYPE_VIDEO      = 4;
  
  /**
   * @return The class of the AudioPlayer provided by this plugin. Can be
   * null if this plugin provides no AudioPlayer.
   */
  public Class<AudioPlayer> getAudioPlayer();
  
  /**
   * @return The type of this plugin.
   */
  public int getType();
}
