package javid.api;

public interface Controlable
{
  void pausePlayback();
  void startPlayback();
  void seekBackward(int samples);
  void seekForward(int samples);
  void stepBackward();
  void stepForward();
  void stopPlayback();
}
