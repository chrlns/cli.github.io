package javid.api;

import java.io.InputStream;

/**
 * This abstract class is the main interface for implementing an
 * audio player that encodes a specific audio format.
 * This is work-in-progress because it takes years to rewrite the
 * aggregated audio decoding code and wipeout the redundant code.
 * @author Christian Lins (christian.lins@web.de)
 */
public abstract class AudioPlayer 
  extends Thread
  implements Controlable
{
  public AudioPlayer(InputStream in)
  {
  }
}
