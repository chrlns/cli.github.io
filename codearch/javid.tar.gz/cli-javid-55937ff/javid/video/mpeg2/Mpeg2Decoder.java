/*
 *  Javid
 *  Copyright (C) 2007 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package javid.video.mpeg2;

import java.io.InputStream;
import java.math.BigInteger;

public class Mpeg2Decoder
{
  private BitInputStream in;
  
  /**
   * The function bytealigned () returns 1 if the current position is on a 
   * byte boundary, that is the next bit in the bitstream is the first bit 
   * in a byte. Otherwise it returns 0.
   */
  public int bytealigned()
  {
    if(in.getPosition() % 8 == 0)
      return 1;
    else
      return 0;
  }
  
  // Darf man hier direkt lesen?
  public boolean nextbits(BigInteger compareValue)
  {
    for(int n = 0; n < compareValue.bitLength(); n++)
    {
      if(compareValue.testBit(n) && 1 == in.readBit() ||
          !compareValue.testBit(n) && 0 == in.readBit())
        continue;
      else
        return false;
    }
    return true;
  }
  /*
  video_sequence() {                                             
    next_start_code()
    sequence_header()
    if ( nextbits() == extension_start_code ) {
          sequence_extension()
          do {
               extension_and_user_data( 0 )
               do {
                     if (nextbits() == group_start_code) {
                          group_of_pictures_header()
                          extension_and_user_data( 1 )
                     }
                     picture_header()
                     picture_coding_extension()
                     extensions_and_user_data( 2 )
                     picture_data()
               } while ( (nextbits() == picture_start_code) ||
                          (nextbits() == group_start_code) )
               if ( nextbits() != sequence_end_code ) {
                     sequence_header()
                     sequence_extension()
               }
          } while ( nextbits() != sequence_end_code )
    } else {
          /* ISO/IEC 11172-2 */
    //}

}
