/*
 *  Javid
 *  Copyright (C) 2007 by Christian Lins <christian.lins@web.de>
 *  Copyright (C) 2002 by Ron
 *  Copyright (C) by Joerg Anders <ja@informatik.tu-chemnitz.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

//This file contains the class "MPEG_video". The object of this class scans the MPEG-
//video stream, extracts the information (especially the DCT values), activates the
//IDCT, applies the motion vectors and passes the pixel values to the applet.
//Furthermore it resizes the applet and (possibly) the frame once it has recognized
//the dimensions of the frame.

//To understand how the video scanner works knowledge of the MPEG file format is
//needed (See ISO 11172-2).

package javid.video.mpeg1;

import javid.gui.JavidFrame;

public class MpegVideo implements Runnable
{
  private IoTool mpegStream; // input filter

  private Huffmann Huf = null; // the VLC (Hufmann) decoder

  private final static int nullmatrix[] = new int[64]; // a matrix of zeros

  private final static int intramatrix[] = { // the default intramatrix
    8, 16, 19, 22, 26, 27, 29, 34, 16, 16, 22, 24, 27, 29, 34, 37, 19, 22, 26,
    27, 29, 34, 34, 38, 22, 22, 26, 27, 29, 34, 37, 40, 22, 26, 27, 29, 32,
    35, 40, 48, 26, 27, 29, 32, 35, 40, 48, 58, 26, 27, 29, 34, 38, 46, 56,
    69, 27, 29, 35, 38, 46, 56, 69, 83 };

  private final static int zigzag[] = { // the reverse zigzag scan order
    0, 1, 8, 16, 9, 2, 3, 10, 17, 24, 32, 25, 18, 11, 4, 5, 12, 19, 26, 33, 40,
    48, 41, 34, 27, 20, 13, 6, 7, 14, 21, 28, 35, 42, 49, 56, 57, 50, 43, 36,
    29, 22, 15, 23, 30, 37, 44, 51, 58, 59, 52, 45, 38, 31, 39, 46, 53, 60,
    61, 54, 47, 55, 62, 63 };

  private final IDCT idct = new IDCT(); // an IDCT object to tranform the DCT
  // coefficients

  private final int dct_recon[] = new int[64]; // the values before IDCT
  // transformation

  private final int non_intramatrix[] = new int[64];

  private boolean lum_block; // is it the first luminance block ???

  private int dct_dc_cr_past, dct_dc_cb_past, dct_dc_y_past; // value of past
  // DC values

  /**
   * The "Pel_buffer" is a main feature of the video scanner. 3 frames are
   * stored at: Pel_buffer[0] Pel_buffer[1] Pel_buffer[2] The frame at index
   * "ak_idx" is the frame coming into being. The frame at index "pred_idx" is
   * the frame for forward prediction. The frame at index "back_idx" is the
   * frame for backward prediction. The method "Parse_Picture" administers the
   * values of these 3 variables. The index in second dimension determins
   * whether the information is:
   * 
   * luminance information - Pel_buffer[?][0] chrominance information (cr) -
   * Pel_buffer[?][1] chrominance information (cb) - Pel_buffer[?][2]
   */

  private int Pel_buffer[][][];

  private int ak_idx = 0, pred_idx = -1, back_idx = -1; // "who is who ???"

  private JavidFrame Player; // Reference to the applet

  private boolean size_changed; // has the size changed with last SEQ

  private static final int SEQ_START_CODE = 0x000001b3;

  private static final int GOP_START_CODE = 0x000001b8;

  private static final int PICTURE_START_CODE = 0x00000100;

  private static final int SLICE_MIN_START_CODE = 0x00000101;

  private static final int SLICE_MAX_START_CODE = 0x000001af;

  private static final int EXT_START_CODE = 0x000001b5;

  private static final int USER_START_CODE = 0x000001b2;

  public static final int I_TYPE = 0x1;

  public static final int P_TYPE = 0x2;

  public static final int B_TYPE = 0x3;

  // MPEG parameters:
  private int width, Height, aspectRatio, Pic_rate;

  private int mb_width, mb_height;

  private int Bit_rate, VBV_buffer;

  private boolean const_param, quant_matrix;

  private int Hour, Minute, second, Pict_Count;

  private boolean Drop_Flag, Closed_Group, Broken_Link;

  /**
   * The method "Parse_macroblock" parses a macroblock according to ISO 11172-2.
   * It is one of the most complex methods because of the great variety of the
   * constitution of a macroblock. The constitution and existence of the the
   * most information fields depends on the constitution and existence of
   * information fields before. Furthermore the decoding process is controlled
   * by this method. In some situations some variables must be reset to some
   * default values or in case of skipped macroblocks implizit values must be
   * applied. Bear in mind that some variables used in this method are member
   * (class) variables for later reference!
   */

  private final void parseMacroBlock(final int b_nr)
    throws InterruptedException
  {
    try
    {
      int inc = 0; // if the macro block increment is
      // greater than 1 some blocks are
      // skipped; this requires special treatment.
      int cbp = 0x3f; // coded block pattern: it determins which of
      // the 6 blocks are really coded
      int inc_tmp, mb_a_tmp, mb_r_tmp, mb_c_tmp; // working variables
      int values[]; // return values of the Hufmann decoder

      while (mpegStream.next_bits(0xf, 11))
      {
        mpegStream.skip_bits(11); // skip macro block escape
      }
      while (mpegStream.next_bits(0x8, 11))
      {
        mpegStream.skip_bits(11); // macro block skipping
        inc += 33; // every skip means +33
      }
      values = Huf.decode(11, Huf.macro_block_inc);
      inc += values[2]; // decode macro block increment
      if (inc > 1)
      { // special treatment for skipped macroblocks
        dct_dc_y_past = dct_dc_cr_past = dct_dc_cb_past = 1024; // default
        // values
        if (Pic_Type == B_TYPE && b_nr > 0)
        { // in this case the motion vectors rest valid
          for (inc_tmp = inc - 1, mb_a_tmp = macro_block_address + 1; inc_tmp-- > 0; mb_a_tmp++)
          {
            mb_r_tmp = mb_a_tmp / mb_width; // compute the macroblock row and
            mb_c_tmp = mb_a_tmp % mb_width; // column for the next skipped block
            if (macro_block_motion_forward)
            { // apply forward prediction
              if (!macro_block_motion_backward)
              {
                Forward.copy_area(mb_r_tmp, mb_c_tmp, Pel_buffer[pred_idx],
                    Pel_buffer[ak_idx]);
              }
              else
              {
                Forward
                .get_area(mb_r_tmp, mb_c_tmp, Pel_buffer[pred_idx], pel1);
              }
            }
            if (macro_block_motion_backward)
            { // apply backward prediction
              if (!macro_block_motion_forward)
              {
                Backward.copy_area(mb_r_tmp, mb_c_tmp, Pel_buffer[back_idx],
                    Pel_buffer[ak_idx]);
              }
              else
              {
                Backward.get_area(mb_r_tmp, mb_c_tmp, Pel_buffer[back_idx],
                    pel2);
                Backward.putArea(mb_r_tmp, mb_c_tmp, pel1, pel2,
                    Pel_buffer[ak_idx]);
              }
            }
          }
        }
        else if (Pic_Type != I_TYPE)
        { // in P_TYPE the motion vector is to be reset
          Forward.reset_prev();
          if (b_nr > 0 && !macro_block_motion_backward
              && !macro_block_motion_backward)
          {
            for (inc_tmp = inc - 1, mb_a_tmp = macro_block_address + 1; inc_tmp-- > 0; mb_a_tmp++)
            {
              mb_r_tmp = mb_a_tmp / mb_width; // compute the macroblock row and
              mb_c_tmp = mb_a_tmp % mb_width; // column for the next skipped
              // block
              Forward.copy_unchanged(mb_r_tmp, mb_c_tmp, Pel_buffer[pred_idx],
                  Pel_buffer[ak_idx]);
            }
          }
        }
      }
      macro_block_address += inc; // (but) now: compute the new macro block
      // address
      mb_row = macro_block_address / mb_width;
      mb_column = macro_block_address % mb_width;
      switch (Pic_Type)
      { // depending on the frame type the existence of some information
      // fields must be determined
      case I_TYPE:
        macro_block_motion_forward = // these information is certainly not
          macro_block_motion_backward = // suppplied in intra coded frames
            macro_block_pattern = false;
        macro_block_intra = true; // Of course!
        if (mpegStream.getBits(1) == 1)
        { // possibly a
          macro_block_quant = false; // new quantization
        } // factor is
        else
        { // supplied
          macro_block_quant = true;
          mpegStream.skip_bits(1);
        }
        break;
      case P_TYPE:
        values = Huf.decode(6, Huf.p_type_mb_type); // decode
        macro_block_quant = values[2] != 0; // extract
        macro_block_motion_forward = (values[3] == 1);
        macro_block_motion_backward = false;
        macro_block_pattern = (values[4] == 1);
        if (!(macro_block_intra = values[5] != 0))
        { // default values
          dct_dc_y_past = dct_dc_cr_past = dct_dc_cb_past = 1024;
          cbp = 0;
        }
        break;
      case B_TYPE:
        values = Huf.decode(6, Huf.b_type_mb_type); // decode
        macro_block_quant = values[2] != 0; // extract
        macro_block_motion_forward = (values[3] == 1);
        macro_block_motion_backward = (values[4] == 1);
        macro_block_pattern = (values[5] == 1);
        if (!(macro_block_intra = values[6] != 0))
        { // default values
          dct_dc_y_past = dct_dc_cr_past = dct_dc_cb_past = 1024;
          cbp = 0;
        }
        break;
      default:
      {
        System.err.println("Unknown Frame-Type : " + Pic_Type);
      }
      Player.repaint();
      return;
      }
      if (macro_block_quant)
      { // extract new quantization factor
        Quant_scale = mpegStream.getBits(5);
      }
      if (macro_block_motion_forward)
      { // motion vector for forward prediction exists
        values = Huf.decode(11, Huf.motion_code); // decode horizontal motion
        // information
        motion_horiz_forw_code = values[2]; // extract horizontal motion
        // information
        if (forward_f != 1 && motion_horiz_forw_code != 0)
        {
          motion_horiz_forw_r = mpegStream.getBits(forward_r_size);
        }
        values = Huf.decode(11, Huf.motion_code); // decode vertical motion
        // information
        motion_verti_forw_code = values[2]; // extract vertical motion
        // information
        if (forward_f != 1 && motion_verti_forw_code != 0)
        {
          motion_verti_forw_r = mpegStream.getBits(forward_r_size);
        }
        // according to this information the motion vector must be decoded
        Forward.computeMotionVector(motion_horiz_forw_code,
            motion_verti_forw_code, motion_horiz_forw_r, motion_verti_forw_r);

        // grab the referred area into "pel1"
        if (Pic_Type != B_TYPE || !macro_block_motion_backward)
        { // no backward prediction
          // put the grabbed area into the actual frame:
          Forward.copy_area(mb_row, mb_column, Pel_buffer[pred_idx],
              Pel_buffer[ak_idx]);
        }
        else
        {
          Forward.get_area(mb_row, mb_column, Pel_buffer[pred_idx], pel1);
        }
      }
      else if (Pic_Type != B_TYPE)
      { // (only) in P_TYPE the motion vector is to be reset.
        Forward.reset_prev(); // (in B_TYPE it rests valid)
      }
      if (macro_block_motion_backward)
      { // motion vector for backward prediction exists
        values = Huf.decode(11, Huf.motion_code); // decode horizontal motion
        // information
        motion_horiz_back_code = values[2]; // extract horizontal motion
        // information
        if (backward_f != 1 && motion_horiz_back_code != 0)
        {
          motion_horiz_back_r = mpegStream.getBits(backward_r_size);
        }
        values = Huf.decode(11, Huf.motion_code); // decode vertical motion
        // information
        motion_verti_back_code = values[2]; // extract vertical motion
        // information
        if (backward_f != 1 && motion_verti_back_code != 0)
        {
          motion_verti_back_r = mpegStream.getBits(backward_r_size);
        }
        // according to this information the motion vector must be decoded
        Backward.computeMotionVector(motion_horiz_back_code,
            motion_verti_back_code, motion_horiz_back_r, motion_verti_back_r);

        if (!macro_block_motion_forward)
        { // no forward prediction
          // put the grabbed area into the actual frame:
          Backward.copy_area(mb_row, mb_column, Pel_buffer[back_idx],
              Pel_buffer[ak_idx]);
        }
        else
        { // forward and backward prediction:
          // grab the refered area into "pel2"
          Backward.get_area(mb_row, mb_column, Pel_buffer[back_idx], pel2);
          // put the average of the 2 areas into the actual frame:
          Backward.putArea(mb_row, mb_column, pel1, pel2, Pel_buffer[ak_idx]);
        }
      }

      if (macro_block_pattern)
      { // coded block pattern supplied
        values = Huf.decode(9, Huf.block_pattern); // decode coded block
        // pattern
        cbp = values[2]; // extract
      }

      if (Pic_Type == P_TYPE && !macro_block_motion_backward
          && !macro_block_motion_forward)
      {
        Forward.copy_unchanged(mb_row, mb_column, Pel_buffer[pred_idx],
            Pel_buffer[ak_idx]);
      }
      lum_block = false; // there wasn't any luminace block in this macroblock
      for (int i = 0; i < 6; i++)
      { // all 6 blocks
        if ((cbp & (1 << (5 - i))) != 0)
        { // block information supplied ?
          parseBlock(i); // yes --> get block information

          try
          { // corrupt video could generate an error here...
            if (macro_block_intra)
            { // in intra macro blocks the values are absolute
              if (i < 4)
                set_lum_pixel(i);
              else
                set_col_pixel(i);
            }
            else
            { // in inter coded macroblocks the values are correctings
              if (i < 4)
                correct_lum_pixel(i);
              else
                correct_col_pixel(i);
            }
          }
          catch (final Exception e)
          {
            error_count++;
            if (error_count < 5)
              System.out.println("Could not draw macroblock... corrupt video?");
            else if (error_count == 5)
              System.out.println("Ignoring minor errors in MPEG_video...");
          }
        }
      }
      if (Pic_Type == B_TYPE && macro_block_intra) // otherwise the motion
      {
        Forward.reset_prev();
        Backward.reset_prev(); // vectors rest valid
      }

    }
    catch (final Exception e) // VERY corrupt video -> skip to next GOP-START
    {
      mpegStream.next_start_code();
      while (!mpegStream.next_bits(GOP_START_CODE, 32))
      {
        mpegStream.getBits(8);
      }
      System.out.println("Hmmm... What is this you are feeding me... I'm not eating THAT!!");
      e.printStackTrace();
    }
  }

  private int Temp_ref, Pic_Type, Frame_nr_offset = -1, Frame_nr = 0;

  private int VBV_Delay;

  // Values for forward prediction:
  private boolean Full_pel_forw_vector;

  private int forw_f_code, forward_f, forward_r_size;

  private int motion_horiz_forw_code, motion_horiz_forw_r;

  private int motion_verti_forw_code, motion_verti_forw_r;

  // Values for backward prediction:
  private boolean Full_pel_back_vector;

  private int backward_f_code, backward_f, backward_r_size;

  private int motion_horiz_back_code, motion_horiz_back_r;

  private int motion_verti_back_code, motion_verti_back_r;

  private int Quant_scale; // quantization factor

  private int macro_block_address, past_intra_address; // actual and past MB
  // address

  private int mb_row, mb_column; // actual position of the macro block

  // what other information are available in current macroblock:
  private boolean macro_block_motion_forward, macro_block_motion_backward,
  macro_block_pattern;

  private boolean macro_block_quant = false, macro_block_intra = false;

  // 2 variables to grab the referred area from predicted frame:
  private final int pel1[] = new int[16 * 16 + 2 * 8 * 8], pel2[] = new int[16
                                                                            * 16 + 2 * 8 * 8];

  // 2 objects of class "motion_data" to notice and compute the motion values:
  private final MotionData Forward = new MotionData();

  private final MotionData Backward = new MotionData();

  // working variables:
  private int pixel_per_lum_line, pixel_per_col_line, lum_y_incr, col_y_incr;

  private volatile Thread video_thread; // The video decoder runs as thread

  private boolean _stopped = false; // A nicer way to stop this thread

  private int error_count = 0;

  /**
   * The constructor only notices the parameter and creates an VLC (Huffmann)
   * decoder object.
   */
  public MpegVideo(final JavidFrame play, final IoTool tool)
  {
    Player = play; // notice
    for (int i = 0; i < 64; i++)
    {
      non_intramatrix[i] = 16; // initialization
      nullmatrix[i] = 0;
    }

    // The necessity of the following to calls is only understandable after
    // reading "http://rnvs.informatik.tu-chemnitz.de/~ja/MPEG/HTML/IDCT.html"

    // idct.norm(intramatrix);
    // idct.norm(non_intramatrix);

    mpegStream = tool;
    Huf = new Huffmann(mpegStream);// create VLC (Hufmann) decoder
  }

  public Thread getThread()
  {
    return video_thread;
  }

  public void resetBuffer()
  {
    size_changed = true;
  }

  public void start()
  {
    video_thread = new Thread(this, "Video Decoder");
    video_thread.start();
  }

  public synchronized void stop()
  {
    // System.out.println("MPEG_video::stop(): stopping video decoder");
    /*
     * if (video_thread != null) { Thread moribund = video_thread; video_thread =
     * null; moribund.interrupt();
     *  // Wait until video dead try { moribund.join(); } catch
     * (InterruptedException ex) { System.out.println("strange---interrupted"); } }
     */

    _stopped = true;

    System.out.println("MPEG_video::stop(): video decoder dead");
  }

  /**
   * The method "parse_video_stream" parses the MPEG video stream according to
   * ISO 11172-2 and performs some initial steps.
   */
  public void run()
  {
    final Thread thisThread = Thread.currentThread();
    try
    {
      while (!mpegStream.next_bits(SEQ_START_CODE, 32))
      {
        mpegStream.skip_bits(8);
        mpegStream.next_start_code();
      }

      mpegStream.next_start_code();
      do
      {
        parseSequenceHeader();

        /*
         * After reading the header the dimensions are known. Therefore let's
         * resize the applet and (probably) the frame and initialize the 2
         * prediction objects. Then create the pel buffer:
         */

        if (Pel_buffer == null || size_changed)
        { // The sequence header can appear many times
          size_changed = false;

          Player.setDim(mb_width * 16, mb_height * 16);
          Pel_buffer = new int[3][3][mb_width * 16 * mb_height * 16];

          // ak_idx = 0;
          // pred_idx = -1;
          // back_idx = -1;

          // some derived values used in "set_lum_pixel", "set_col_pixel",
          // "correct_lum_pixel" and "correct_col_pixel":

          pixel_per_lum_line = mb_width << 4;
          pixel_per_col_line = mb_width << 3;
          lum_y_incr = pixel_per_lum_line - 8;
          col_y_incr = pixel_per_col_line - 8;
          Forward.init(pixel_per_lum_line, pixel_per_col_line,
              pixel_per_lum_line - 16, col_y_incr);
          Backward.init(pixel_per_lum_line, pixel_per_col_line,
              pixel_per_lum_line - 16, col_y_incr);
        }

        do
        {
          parseGroupOfPictures();
        }
        while (!_stopped && thisThread == video_thread &&
            !mpegStream.is_eof() && mpegStream.next_bits(GOP_START_CODE, 32));

        // go to next SEQ_CODE... <-- I know... it should be there already...
        // but... :)
        while (!_stopped && !mpegStream.next_bits(SEQ_START_CODE, 32)
            && !mpegStream.is_eof() && thisThread == video_thread)
        {
          mpegStream.getBits(8);
        }
      }
      while (!_stopped && thisThread == video_thread &&
          !mpegStream.is_eof() && mpegStream.next_bits(SEQ_START_CODE, 32));

    }
    catch (final InterruptedException ex)
    {
      System.out.println("MPEG_video::run() caught InterruptedException.");
      try
      {
        mpegStream.close();
      }
      catch(Exception ex2)
      {
        ex2.printStackTrace();
      }
    }

    System.out.println("MPEG_video::run(): saying goodnight.  Tip your waitresses.");
  }

  /**
   * The method "Parse_sequence_header" parses the sequence header according to
   * ISO 11172-2.
   */
  private void parseSequenceHeader() throws InterruptedException
  {
    if (mpegStream.getBits(32) != SEQ_START_CODE)
    {
      System.out.println("ERROR: NO SEQ_START_CODE FOUND!!!");
      // Err.Msg = "SEQ_START_CODE expected";
      Player.repaint();
      return;
    }
    final int w = width;
    final int h = Height;

    width = mpegStream.getBits(12);
    Height = mpegStream.getBits(12);

    size_changed |= (w != width || h != Height);

    mb_width = (width + 15) / 16;
    mb_height = (Height + 15) / 16;
    aspectRatio = mpegStream.getBits(4);
    Pic_rate = mpegStream.getBits(4);
    Bit_rate = mpegStream.getBits(18);
    mpegStream.skip_bits(1);
    VBV_buffer = mpegStream.getBits(10);
    const_param = mpegStream.getBits(1) == 1;
    quant_matrix = mpegStream.getBits(1) == 1;
    if (quant_matrix)
    {
      for (int i = 0; i < 64; intramatrix[i++] = (0xff & mpegStream
          .getBits(8)))
        ;
      // idct.norm(intramatrix);
    }
    quant_matrix = mpegStream.getBits(1) == 1;
    if (quant_matrix)
    {
      for (int i = 0; i < 64; non_intramatrix[i++] = (0xff & mpegStream
          .getBits(8)))
        ;
      // idct.norm(non_intramatrix);
    }
    mpegStream.next_start_code();

    //
    // Note: this is not compliant. The spec allows for only one user_data
    // block,
    // yet it appears that at least one encoder creates more than one.
    //
    while (mpegStream.next_bits(USER_START_CODE, 32))
    {
      mpegStream.skip_bits(32);
      while (!mpegStream.next_bits(0x1, 24))
      {
        mpegStream.skip_bits(8);
      }
    }
  }

  /**
   * The method "Parse_group_of_pictures" parses the group of pictures according
   * to ISO 11172-2. The information is simply ignored.
   */
  private void parseGroupOfPictures() throws InterruptedException
  {
    int bits = mpegStream.getBits(32);
    if (bits != GOP_START_CODE)
    {
      System.err.println("NO GOP_START_CODE found !!!");
      System.err.println("Instead 0x" + Integer.toHexString(bits) + " where read.");
      Player.repaint();
      return;
    }

    Drop_Flag = mpegStream.getBits(1) == 1;
    Hour = mpegStream.getBits(5);
    Minute = mpegStream.getBits(6);
    mpegStream.skip_bits(1);
    second = mpegStream.getBits(6);
    Pict_Count = mpegStream.getBits(6);
    Closed_Group = mpegStream.getBits(1) == 1;
    Broken_Link = mpegStream.getBits(1) == 1;
    mpegStream.next_start_code();

    if (mpegStream.next_bits(EXT_START_CODE, 32))
    {
      while (!mpegStream.next_bits(0x1, 24))
      {
        mpegStream.getBits(8);
      }
      System.out.println("Cannot deal with MPEG-2 data stream!");
      return;
    }

    if (mpegStream.next_bits(USER_START_CODE, 32))
    {
      while (!mpegStream.next_bits(0x1, 24))
      {
        mpegStream.getBits(8);
      }
    }

    // notice the frame number because it is reset to zero
    // at group of pictures

    Frame_nr_offset = Frame_nr + 2; // don't know why ???

    while (!_stopped && !mpegStream.is_eof()
        && mpegStream.next_bits(PICTURE_START_CODE, 32))
    {
      parsePicture();
    }
  }

  /**
   * The method "Parse_picture" parses a picture according to ISO 11172-2. It
   * determines the frame number in display order and the picture type.
   * Depending on the picture type some special actions are performed.
   * Especially the index of the referred frame for forward and backward
   * prediction is to be defined.
   */
  private void parsePicture() throws InterruptedException
  {
    int start_c;

    // Get presentation timestamp (if any)
    // FIXME: this fails when PICTURE_START_CODE crosses packet boundary
    // (only if the mpeg_stream buffer is empty right now
    //
    long pts = -1;
    if (mpegStream.getStream() instanceof CutBuffer)
      pts = (mpegStream.getStream()).getTimeStamp();

    // -- long ago, when people still used MPEG_scan... :)
    // long pts = mpeg_stream.getPts();

    if (mpegStream.getBits(32) != PICTURE_START_CODE)
    {
      System.out.println("NO PICTURE_START_CODE FOUND!!!");
      Player.repaint();
      return;
    }

    Temp_ref = mpegStream.getBits(10); // picture number in display order
    Frame_nr = Frame_nr_offset + Temp_ref;
    Pic_Type = mpegStream.getBits(3);
    VBV_Delay = mpegStream.getBits(16); // ignored
    if (Pic_Type == P_TYPE || Pic_Type == I_TYPE)
      pred_idx = back_idx;
    if (Pic_Type == P_TYPE || Pic_Type == B_TYPE)
    {
      if (pred_idx == -1)
      {
        // System.out.println("Warning: No predictive Frame in P_FRAME");
        pred_idx = (ak_idx + 2) % 3;
      }

      Full_pel_forw_vector = mpegStream.getBits(1) == 1; // meaning of motion
      // data
      forw_f_code = mpegStream.getBits(3); // THE
      forward_r_size = forw_f_code - 1; // MOTION
      forward_f = 1 << forward_r_size; // DATA

      Forward.set_pic_data(forward_f, Full_pel_forw_vector);// (forward)
    }
    if (Pic_Type == B_TYPE)
    {
      if (back_idx == -1)
      {
        System.out.println("Warning: No Backward Predictive Frame in B_TYPE");
        back_idx = (ak_idx + 1) % 3;
      }
      Full_pel_back_vector = mpegStream.getBits(1) == 1; // meaning of motion
      // data
      backward_f_code = mpegStream.getBits(3); // THE
      backward_r_size = backward_f_code - 1; // MOTION
      backward_f = 1 << backward_r_size; // DATA

      Backward.set_pic_data(backward_f, Full_pel_back_vector);// (backward)
    }
    while (mpegStream.next_bits(0x1, 1))
    {
      mpegStream.skip_bits(8);
    }
    mpegStream.skip_bits(1);
    mpegStream.next_start_code();

    if (mpegStream.next_bits(EXT_START_CODE, 32))
    {
      mpegStream.skip_bits(32);
      while (!mpegStream.next_bits(0x1, 24))
      {
        mpegStream.skip_bits(8);
      }
    }

    if (mpegStream.next_bits(USER_START_CODE, 32))
    {
      mpegStream.skip_bits(32);
      while (!mpegStream.next_bits(0x1, 24))
      {
        mpegStream.skip_bits(8);
      }
    }
    if (Pic_Type == 4)
    { // TODO: Implement D-Frames although I've never seen them in wildlife
      System.err.println("can't decode D-Type Frames");
      return;
    }

    start_c = mpegStream.peek_bits(32);
    while (start_c >= SLICE_MIN_START_CODE && start_c <= SLICE_MAX_START_CODE)
    {
      parseSlice();
      start_c = mpegStream.peek_bits(32);
    }

    // A frame (picture) is ready. Pass the YUV values to the applet:
    if (Pic_Type != 4)
    {
      Player.setPixels(Pel_buffer[ak_idx], Frame_nr, Pic_Type, pts, Pic_rate);
    }
    if (Pic_Type == P_TYPE || Pic_Type == I_TYPE)
    { // reorder the indexes
      back_idx = ak_idx;
      ak_idx = (ak_idx + 1) % 3;
    }
  }

  /**
   * The method "Parse_slice" parses a slice according to ISO 11172-2. It
   * determines quantization scale and the macroblock address of the first macro
   * block of the slice.
   */
  private final void parseSlice() throws InterruptedException
  {
    final int k = mpegStream.getBits(32); // this field contains the
    // macro block address
    int b_nr = 0; // macroblock nr in slice

    past_intra_address = -2; // initialization (see ISO 11172-2)
    dct_dc_y_past = dct_dc_cb_past = dct_dc_cr_past = 1024; // dito
    Forward.reset_prev();
    Backward.reset_prev(); // reset motion data
    macro_block_address = ((k & 0xff) - 1) * mb_width - 1; // extract MB
    // address
    if (k < SLICE_MIN_START_CODE || k > SLICE_MAX_START_CODE)
    {
      System.out.println("SLICE START CODE expected");
      Player.repaint();
      return;
    }
    Quant_scale = mpegStream.getBits(5);

    while (mpegStream.next_bits(0x1, 1))
    {
      mpegStream.skip_bits(9);
      // mpeg_stream.get_bits(1);
      // mpeg_stream.get_bits(8);
    }
    mpegStream.skip_bits(1);

    // while (!mpeg_stream.next_bits(0x0, 23))
    do
    {
      parseMacroBlock(b_nr++);
    }
    while (!mpegStream.next_bits(0x0, 23));
    mpegStream.next_start_code();
  }

  /**
   * The method "parseBlock" parses a block according to ISO 11172-2. Thereby
   * the DC and AC coefficients are reconstructed and placed into the
   * "dct_recon" field in de-"zigzag"-ed order. After that the IDCT routine is
   * called. The method counts the coefficients and calls a sparse IDCT method
   * if the coefficient count is 1.
   */
  // TODO: Takes a lot of time!
  private final void parseBlock(final int nr) throws InterruptedException
  {
    int idx = 0, size, sign, idx_run = 0, level; // working variables
    int coeffCount = 0; // coefficient count
    int pos = 0; // the actual (de-"zigzag"-ed) position of the coefficient
    int values[]; // return values of the Hufmann decoder
    int pValues; // Integer-packed dual huffman value

    System.arraycopy(nullmatrix, 0, dct_recon, 0, 64); // initialization
    if (macro_block_intra)
    {
      if (nr < 4)
      { // luminance block
        values = Huf.decode(7, Huf.dct_size_luminance);
        size = values[2]; // size of the DC coefficient
        if (size != 0)
        {
          set_dct_diff(mpegStream.getBits(size), size);
        }
        if (lum_block)
        { // not first luminance block
          dct_dc_y_past = dct_recon[0] = dct_dc_y_past + (dct_recon[0] << 3);
        }
        else
        { // first luminance block
          lum_block = true;
          dct_recon[0] <<= 3;
          if (macro_block_address - past_intra_address > 1)
          {
            dct_dc_y_past = dct_recon[0] += 1024;
          }
          else
          { // relative if no skipping
            dct_dc_y_past = dct_recon[0] += dct_dc_y_past;
          }
        }
        past_intra_address = macro_block_address; // notice
      }
      else
      { // chrominance block
        values = Huf.decode(8, Huf.dct_size_crominance);
        size = values[2];
        if (size != 0)
        {
          set_dct_diff(mpegStream.getBits(size), size);
        }
        switch (nr)
        {
        case 4:
          dct_recon[0] <<= 3;
          if (macro_block_address - past_intra_address > 1)
          {
            dct_dc_cb_past = dct_recon[0] += 1024;
          }
          else
          { // relative if no skipping
            dct_dc_cb_past = dct_recon[0] += dct_dc_cb_past;
          }
          break;
        case 5:
          dct_recon[0] <<= 3;
          if (macro_block_address - past_intra_address > 1)
          {
            dct_dc_cr_past = dct_recon[0] += 1024;
          }
          else
          { // relative if no skipping
            dct_dc_cr_past = dct_recon[0] += dct_dc_cr_past;
          }
          break;
        }
      }
      past_intra_address = macro_block_address; // notice
      if (dct_recon[0] != 0)
        coeffCount = 1; // count coefficients
      // dct_recon[0] <<= idct.VAL_BITS - 3; // because of the IDCT technique:
      // dct_recon[0] <<= idct.ROW_SHIFT - 3; // because of the IDCT technique:
      // the DC values are not quantized;
      // therefore the fix point translation
      // must be performed
    }
    else
    { // no intra coded block --> first AC value
      if (mpegStream.next_bits(0x1, 1))
      { // special treatment of the VLC "1"
        idx = 0;
        mpegStream.skip_bits(1);
        sign = level = mpegStream.getBits(1) == 0 ? 1 : -1; // the sign
        // follows
        // sign = 0;
      }
      else
      {
        pValues = Huf.decodeCoeff(); // decode AC value
        idx = pValues & 0xff; // extract AC value
        if (idx == Huffmann.DCT_ESCAPE)
        { // special treatment
          idx = mpegStream.getBits(6); // once again
          if ((((level = mpegStream.getBits(8)) & 0x7f) == 0))
          { // 16 bit
            level = (level << 8) | mpegStream.getBits(8);
            if ((level & 0x8000) != 0)
              level |= 0xffffff00; // sign ??
          }
          else if ((0x80 & level) != 0)
          { // sign ??
            level |= 0xffffff00;
          }
        }
        else
        { // "normal" treatment (no escape); extract AC coefficient
          level = mpegStream.getBits(1) == 0 ? pValues >> 8 : -(pValues >> 8);
        }
        sign = (level == 0) ? 0 : ((level < 0) ? -1 : 1); // determine sign
      }
      pos = zigzag[idx]; // de-"zigzag"

      // Quantization:

      dct_recon[pos] = ((level + sign) * Quant_scale * non_intramatrix[pos]) >> 3;
        // dct_recon[pos] = (level * Quant_scale * non_intramatrix[pos]) >> 3;
        // dct_recon[pos] = 0;

        /* oddification */

        if ((dct_recon[pos] & 1) == 0)
        {
          if (dct_recon[pos] >= 0)
            dct_recon[pos]--;
          else
            dct_recon[pos]++;
        }

        /*
         * ++++++ ATTENTION: The "oddification" absences here. Feel free to insert
         * the code. ++++
         */
        /*
         * ++++++ I've regarded this as a waste of time because I can't recognize
         * ++++
         */
        /* ++++++ any difference. ++++ */

        /* FIXED oddification... -- Ron -- */

        if (level != 0)
          coeffCount++; // count the coefficients
    }
    pValues = Huf.decodeCoeff(); // decode AC value
    while ((idx_run = (pValues & 0xff)) != Huffmann.EOB)
    { // no end of block; read the other AC values
      if (idx_run == Huffmann.DCT_ESCAPE)
      { // special treatment
        idx_run = mpegStream.getBits(6); // once again
        if ((((level = mpegStream.getBits(8)) & 0x7f) == 0))
        { // 16 bit
          level = (level << 8) | mpegStream.getBits(8);
          if ((level & 0x8000) != 0)
            level |= 0xffffff00; // sign ??
        }
        else if ((0x80 & level) != 0)
        { // sign ??
          level |= 0xffffff00;
        }
        idx += idx_run + 1; // the position is now given as a difference
      }
      else
      { // "normal" treatment (no escape); extract AC coefficient
        idx += idx_run + 1; // the position is now given as a difference
        level = mpegStream.getBits(1) == 0 ? (pValues >> 8) : -(pValues >> 8);
      }

      if (idx > 63)
        idx = 63;
      pos = zigzag[idx]; // de-"zigzag"

      if (macro_block_intra)
      { // different treatment of quantization depending on type
        dct_recon[pos] = (level * Quant_scale * intramatrix[pos]) >> 3;
      }
      else
      {
        sign = (level == 0) ? 0 : ((level < 0) ? -1 : 1);
        dct_recon[pos] = ((level + sign) * Quant_scale * non_intramatrix[pos]) >> 3;
        // dct_recon[pos] = (level * Quant_scale * non_intramatrix[pos]) >> 3;
      }

      /* oddification */

      if ((dct_recon[pos] & 1) == 0)
      {
        if (dct_recon[pos] >= 0)
          dct_recon[pos]--;
        else
          dct_recon[pos]++;
      }

      /*
       * ++++++ ATTENTION: The "oddification" absences here. Feel free to insert
       * the code. ++++
       */
      /*
       * ++++++ I've regarded this as a waste of time because I can't recognize
       * ++++
       */
      /* ++++++ any difference. ++++ */

      /* FIXED oddification... -- Ron -- */

      if (level != 0)
        coeffCount++; // count the coefficients
      pValues = Huf.decodeCoeff(); // decode next value
    }

    // this works ;)
    /*
     * if (coeffCount == 1) { // only one coefficient ?? idct.invers_dct_special
     * (dct_recon, pos); // call a sparse method } else {
     * idct.invers_dct(dct_recon); // full decoding }
     */
    idct.simple_idct(dct_recon);

    /*
     * // If you want to kill something, kill this code!! :) for (int i=0; i<64;
     * i++) { //dct_recon[i] >>= 1; //if (!macro_block_intra) //dct_recon[i] +=
     * (count++%2 == 0) ? 1 : 0; // tries to counter greenish-bug //dct_recon[i] +=
     * (count%4 == 0) ? 0 : 1; // tries to counter greenish-bug }
     */

    // count++;
  }

  // private static final double D = (256.0 / Math.pow(256.0, 1.2));

  /* The method "set_dct_diff" computes the DCT difference according to */
  /* ISO 11172-2. Is sets "dct_recon[0]". */

  private void set_dct_diff(final int dct_diff, final int dct_size)
  {
    if ((dct_diff & (1 << (dct_size - 1))) != 0)
      dct_recon[0] = dct_diff;
    else
      dct_recon[0] = ((-1) << (dct_size)) | (dct_diff + 1);
  }

  /**
   * The method "set_lum_pixel" takes the re-transformed luminance values and
   * places them at the appropriate position. Note that the variables:
   * 
   * pixel_per_lum_line mb_row mb_column
   * 
   * are computed in "run()" as soon it was possible.
   */
  private void set_lum_pixel(final int nr)
  {
    int j, pos = pixel_per_lum_line * ((mb_row << 4) + ((nr & 0x2) << 2))
    + (mb_column << 4) + ((nr & 0x1) << 3);

    final int[] pb0 = Pel_buffer[ak_idx][0];

    for (j = 0; j < 64; j += 8)
    {
      // System.out.println("pb length: " + dct_recon.length + " " + j + " " +
      // pb0.length + " " + pos);
      // System.out.println("pixel_per_lum_line: " + pixel_per_lum_line + "
      // mb_row " + mb_row + " nr " + nr + " mb_column " + mb_column);
      System.arraycopy(dct_recon, j, pb0, pos, 8);
      pos += pixel_per_lum_line;
    }
  }

  /**
   * The method "set_col_pixel" takes the re-transformed chrominance values and
   * places them at the appropriate position. Note that the variables:
   * 
   * pixel_per_col_line mb_row mb_column
   * 
   * are computed in "run()" as soon it was possible.
   */
  private void set_col_pixel(final int nr)
  {
    int j, pos = pixel_per_col_line * (mb_row << 3) + (mb_column << 3);

    switch (nr)
    {
    case 4:
      final int[] pb2 = Pel_buffer[ak_idx][2];
      for (j = 0; j < 64; j += 8)
      {
        System.arraycopy(dct_recon, j, pb2, pos, 8);
        pos += pixel_per_col_line;
      }
      break;
    case 5:
      final int[] pb1 = Pel_buffer[ak_idx][1];
      for (j = 0; j < 64; j += 8)
      {
        System.arraycopy(dct_recon, j, pb1, pos, 8);
        pos += pixel_per_col_line;
      }
      break;
    }
  }

  /**
   * The method "correct_lum_pixel" is called in predicted macro blocks. Because
   * the values in "dct_recon" are motion compensation information the task of
   * this method is to correct the already supplied (copied) values.
   * 
   * Note that the variables:
   * 
   * pixel_per_lum_line lum_y_incr mb_row mb_column
   * 
   * are computed in "run()" as soon it was possible.
   */
  private void correct_lum_pixel(final int nr)
  {
    int i, j, k = 0;
    int pos = pixel_per_lum_line * ((mb_row << 4) + ((nr & 0x2) << 2))
    + (mb_column << 4) + ((nr & 0x1) << 3);

    final int[] pb0 = Pel_buffer[ak_idx][0];

    for (j = 8; j > 0; j--)
    {
      for (i = 8; i > 0; i--)
      {
        pb0[pos++] += dct_recon[k++];
      }
      pos += lum_y_incr; // pixel_per_lum_line - 8
    }
  }

  /**
   * The method "correct_col_pixel" is called in predicted macro blocks. Because
   * the values in "dct_recon" are motion compensation information the task of
   * this method is to correct the already supplied (copied) values.
   * 
   * Note that the variables:
   * 
   * pixel_per_col_line col_y_incr mb_row mb_column
   * 
   * are computed in "run()" as soon it was possible.
   */
  private void correct_col_pixel(final int nr)
  {
    int i, j, k = 0;
    int pos = pixel_per_col_line * (mb_row << 3) + (mb_column << 3);

    switch (nr)
    {
    case 4:
      final int[] pb2 = Pel_buffer[ak_idx][2];
      for (j = 8; j > 0; j--)
      {
        for (i = 8; i > 0; i--)
        {
          pb2[pos++] += dct_recon[k++];
        }
        pos += col_y_incr; // pixel_per_col_line - 8
      }
      break;
    case 5:
      final int[] pb1 = Pel_buffer[ak_idx][1];
      for (j = 8; j > 0; j--)
      {
        for (i = 8; i > 0; i--)
        {
          pb1[pos++] += dct_recon[k++];
        }
        pos += col_y_incr; // pixel_per_col_line - 8
      }
      break;
    }
  }
}
