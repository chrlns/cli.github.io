/*
 *  Javid
 *  Copyright (C) 2007 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
    Javid
    Copyright (c) 2007 Christian Lins <christian.lins@fh-osnabrueck.de>
    
    based on
    Copyright (c) 2002  Ron <r_breukelaar@hotmail.com>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/

package javid.video.mpeg1;

import java.io.InputStream;


// TODO: This class uses to much memory!
public class CutElement
{
  public static final byte I_FRAME      = 1;
  public static final byte P_FRAME      = 2;
  public static final byte B_FRAME      = 3;
  public static final byte TYPE_VIDEO   = 10;
  public static final byte PACK_START   = 11; 
  public static final byte SLICE_START  = 12;
  public static final byte SYSTEM_START = 13;
  public static final byte TYPE_AUDIO   = 14;
  public static final byte SEQ_START    = 15;
  public static final byte GOP_START    = 16;  
  
  private char        buffer[];  // Buffer for I/P/B/SEQ/GOP
  private InputStream is;        // The InputStream that needs to be parsed
  private CutBuffer   cutBuffer; // Reference to the CutBuffer

  private int cursor;      // Number of bytes in buffer
  private int type;        // The type of frame

  private long readAheadBuffer;         // Read ahead buffer (8 bytes)
  private long low;          // The lower 4 bytes of _long
  private long high;         // The higher 4 bytes of _long
  private long read;         // The number of bytes read from _is

  private boolean eof = false;       // End of file reached?

  private long timeStamp;       // Time stamp for this frame
  private long readTime;        // Time this frame was read

	public CutElement(final long time)
	{
		buffer = new char[128];
		cursor = 0;
		type = -1;
		timeStamp = time;
	}

	public long fill(final InputStream is, final long next32, final CutBuffer buffer) throws Exception
	{
		readAheadBuffer = next32;
		high = readAheadBuffer >>> 32;
		low = readAheadBuffer & 0xffffffff;
		readTime = System.currentTimeMillis();
		read = 0;

		this.is = is;
		type = -1;
		cursor = 0;
		this.cutBuffer = buffer;

		// goto next PIC, SEQ or GOP
		while (high != 0x100 && high != 0x1b3 && high != 0x1b8 && !eof)
			skip_to_1();

		// if found PICURE_START -> read type (I/P/B)
		if (high == 0x100)
		{
			read(); read();
			type = (int)((high >> 3) & 7);
		}
		else if (high == 0x1b3)
			type = SEQ_START;
		else if (high == 0x1b8)
			type = GOP_START;

		// parse to next PIC, SEQ or GOP <-- layer2
		do
		{
			read_to_1();
			//Thread.yield();
		}
    while (high != 0x100 && high != 0x1b3 && high != 0x1b8 && !eof);

		if (eof)
			readAheadBuffer = -1;

		// buffer downsizen ???
		//final char temp[] = new char[cursor];
		//System.arraycopy(this.buffer, 0, temp, 0, cursor);

		//this.buffer = temp;
    
		return readAheadBuffer;
	}

	/***
	 * layer 2 functions
	 */

	// -- replaced copy-loop with System.arraycopy
	private void read() throws Exception
	{
		final int r = is.read();
		read++;

		if (r != -1)
		{
			buffer[cursor++] = (char)((readAheadBuffer >>> 56) & 255);

			readAheadBuffer = (readAheadBuffer << 8) | r;
			high = readAheadBuffer >>> 32;
			low = readAheadBuffer & 0xffffffffL;

			skip_layer_1();

			if (cursor >= buffer.length)
			{
				final char temp[] = new char[buffer.length << 1];
				System.arraycopy(buffer, 0, temp, 0, buffer.length);
				buffer = temp;
			}
		}
		else
			eof = true;
	}

  /*
	private void skip() throws Exception
	{
		final int r = _is.read();
		_read++;

		if (r != -1)
		{
			_long = (_long << 8) | r;
			_high = _long >>> 32;
			_low = _long & 0xffffffffL;

			skip_layer_1();
		}
		else
			_eof = true;
	}*/

	// replaced copy-loop with System.arraycopy
	private void read_to_1() throws Exception
	{
		int r;
		do
		{
			r = is.read();
			read++;

			if (r != -1)
			{
				buffer[cursor++] = (char)((readAheadBuffer >>> 56) & 255);

				readAheadBuffer = (readAheadBuffer << 8) | r;
				high = readAheadBuffer >>> 32;
				low = readAheadBuffer & 0xffffffffL;

				skip_layer_1();

				if (cursor >= buffer.length)
				{
					final char temp[] = new char[buffer.length << 1];
					System.arraycopy(buffer, 0, temp, 0, buffer.length);
					buffer = temp;
				}
			}
			else
				eof = true;
		}
		while ((high >>> 8) != 1 && !eof);
	}

	private void skip_to_1() throws Exception
	{
		int r = 0;
		do
		{
			r = is.read();
			read++;

			if (r != -1)
			{
				readAheadBuffer = (readAheadBuffer << 8) | r;
				high = readAheadBuffer >>> 32;
				low = readAheadBuffer & 0xffffffffL;

				skip_layer_1();
			}
			else
				eof = true;
		}
		while ((high >>> 8) != 1 && !eof);
	}

	/***
	 * layer 1 functions
	 */
	public void skip_layer_1() throws Exception
	{
		boolean done = false;
		while (!done && !eof)
		{
      switch((int)low)
      {
        case 0x1e0:
        {
          skip_1e0();
          break;
        }
        case 0x1c0:
        {
          skip_1c0();
          break;
        }
        case 0x1ba:
        {
          skip_1ba();
          break;
        }
        case 0x1bb:
        {
          skip_1bb();
          break;
        }
        case 0x1be:
        {
          skip_1be();
          break;
        }
        case 0x1b9:
        {
          skip_1b9();
          break;
        }
        case 0x1b2:
        {
          skip_1b2(); // USER_START
          break;
        }
        case 0x1fd:
        {
          skip_1fd();
          break;
        }
        case 0x1fe:
        {
          skip_1fe();
          break;
        }
        default:
          done = true;
      }
		}
	}

	public void skip_1e0() throws Exception
	{
		skip_low(); skip_low();

		skip_low();
		// skip stuffing
		while ((low & 0xff) == 0xff)
			skip_low();

		// skip 01XXXXXX XXXXXXXX
		if (((low >> 6) & 3) == 1)
		{
			skip_low();
			skip_low();
		}

		// skip 0010TTTX TTTTTTTT TTTTTTTX TTTTTTTT TTTTTTTX
		if (((low >> 4) & 15) == 2)
		{
                        timeStamp = ((readAheadBuffer >> 1) & 7);
                        skip_low(); timeStamp = ((timeStamp << 8) | (low & 255));
                        skip_low(); timeStamp = ((timeStamp << 7) | ((low >> 1) & 127));
                        skip_low(); timeStamp = ((timeStamp << 8) | (low & 255));
                        skip_low(); timeStamp = ((timeStamp << 7) | ((low >> 1) & 127));
                        skip_low();
		}

		// skip 0011TTTX TTTTTTTT TTTTTTTX TTTTTTTT TTTTTTTX
		//      XXXXPPPX PPPPPPPP PPPPPPPX PPPPPPPP PPPPPPPX
		else if (((low >> 4) & 15) == 3)
		{
                        timeStamp = (low & 14);
                        skip_low(); timeStamp = (timeStamp << 7) + (low & 255);
			skip_low(); timeStamp = (timeStamp << 7) + ((low >> 1) & 127);
			skip_low(); timeStamp = (timeStamp << 8) + (low & 255);
			skip_low(); timeStamp = (timeStamp << 7) + ((low >> 1) & 127);
                        skip_low(); skip_low();
			skip_low(); skip_low();
			skip_low(); skip_low();
		}

		// skip one byte
		else
			skip_low();

		skip_low(); skip_low(); skip_low();
	}

	public void skip_1c0() throws Exception
	{
		skip_low(); skip_low();
		long length = (low & 0xffff);

		skip_low(); length --;
		// skip stuffing
		while ((low & 0xff) == 0xff)
		{
			skip_low();
			length--;
		}

		// skip 01XXXXXX XXXXXXXX
		if (((low >> 6) & 3) == 1)
		{
			skip_low();
			skip_low();
			length -= 2;
		}

		// skip 0010TTTX TTTTTTTT TTTTTTTX TTTTTTTT TTTTTTTX
		if (((low >> 4) & 15) == 2)
		{
                        timeStamp = ((low >> 1) & 7);
                        skip_low(); timeStamp = ((timeStamp << 8) | (low & 255));
                        skip_low(); timeStamp = ((timeStamp << 7) | ((low >> 1) & 127));
                        skip_low(); timeStamp = ((timeStamp << 8) | (low & 255));
                        skip_low(); timeStamp = ((timeStamp << 7) | ((low >> 1) & 127));
                        skip_low();
			length -= 5;
		}

		// skip 0011TTTX TTTTTTTT TTTTTTTX TTTTTTTT TTTTTTTX
		//      XXXXPPPX PPPPPPPP PPPPPPPX PPPPPPPP PPPPPPPX
		else if (((low >> 4) & 15) == 3)
		{
                        timeStamp = (low & 14);
                        skip_low(); timeStamp = (timeStamp << 7) + (low & 255);
			skip_low(); timeStamp = (timeStamp << 7) + ((low >> 1) & 127);
			skip_low(); timeStamp = (timeStamp << 8) + (low & 255);
			skip_low(); timeStamp = (timeStamp << 7) + ((low >> 1) & 127);
                        skip_low(); skip_low();
			skip_low(); skip_low();
			skip_low(); skip_low();
			length -= 10;
		}

		// skip one byte
		else
		{
			skip_low();
			length --;
		}

		skip_low(); skip_low(); skip_low();
		length -= 3;

		final AudioElement ae = new AudioElement(timeStamp);
		readAheadBuffer = ae.fill(is, readAheadBuffer); // <-- user length
		high = readAheadBuffer >>> 32;
		low = readAheadBuffer & 0xffffffffL;

		if (readAheadBuffer != -1)
		{
			read += ae.getReadBytes();
			cutBuffer.addAudioElement(ae);
		}
		else
			eof = true;
	}

	public void skip_1ba() throws Exception
	{
		skip_low();

		while (low < 0x100 || low > 0x1ff)
			skip_low_to_1();
	}

	public void skip_1bb() throws Exception
	{
		skip_low();
    
		while (low < 0x100 || low > 0x1ff)
			skip_low_to_1();
	}

	public void skip_1be() throws Exception
	{
		skip_low();
		while (low < 0x100 || low > 0x1ff)
			skip_low_to_1();
	}

	public void skip_1b9() throws Exception
	{
		skip_low();
		while (low < 0x100 || low > 0x1ff)
			skip_low_to_1();
	}

	public void skip_1b2() throws Exception
	{
		skip_low();
		while (low < 0x100 || low > 0x1ff)
			skip_low_to_1();
	}

	public void skip_1fd() throws Exception
	{
		skip_low(); skip_low();
		int l = (int)(low & 0xffffL);	// read length of token packet

		String name = "";		// read name of token
		int r = is.read();
		while (r != 32)
		{
			name += (char)r;
			r = is.read();
		}

		l -= (name.length()+1);
		read += name.length() + 1;

		final byte p[] = new byte[l];		// read content of token
		is.read(p);
		read += l;

		cutBuffer.processToken(name, p, this);
	}

	public void skip_1fe() throws Exception
	{
		cutBuffer.tokenReceived(); 	// 0x1fe is interpretted as a signal to
						// switch to a lower bandwith.

		skip_low();
		while (low < 0x100 || low > 0x1ff)
			skip_low_to_1();
	}

	private void skip_low() throws Exception
	{
		final int r = is.read();
		read++;

		if (r != -1)
		{
			low = ((low << 8) & 0xffffffffL) | r;
			readAheadBuffer = (readAheadBuffer & 0xffffffff00000000L) | low;
		}
		else
			eof = true;
	}

	private void skip_low_to_1() throws Exception
	{
		int r = 0;
		do
		{
			r = is.read();
			read++;

			if (r != -1)
			{
				low = ((low << 8) & 0xffffffffL) | r;
				readAheadBuffer = (readAheadBuffer & 0xffffffff00000000L) | low;
			}
			else
				eof = true;
		}
		while ((low >>> 8) != 1 && !eof);
	}

	/***
	 * other functions
	 */

	public int getSize()
	{
		return cursor;
	}

	public long getBytesRead()
	{
		return read;
	}

	public long getReadTime()
	{
		return readTime;
	}

	public int getType()
	{
		return type;
	}

	public char[] getBuffer()
	{
		return buffer;
	}

	public long getTimeStamp()
	{
		return timeStamp;
	}

	public void setTimeStamp(final long time)
	{
		timeStamp = time;
	}
}
