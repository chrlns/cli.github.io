/*
 *  Javid
 *  Copyright (C) 2007 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package javid.video.mpeg1;

import java.awt.Image;
import java.awt.image.ColorModel;
import java.awt.image.MemoryImageSource;

import javid.gui.JavidFrame;

/**
 * The class "Element" can store the information of a single frame. 
 * Exactly "MAXELEMENT" objects of this class exist in an array "EL_ARR[]" which 
 * is used in wrap around manner.
 * The pixels are given as YUV values and they are then translated into the 
 * Java-AWT RGB model.
*/
public class VideoElement 
{ 
  private static final int CR_FAC = 0x166EA;  /* 1.402*2^16 */
  private static final int CB_FAC = 0x1C5A2;  /* 1.772*2^16 */
  private static final int CR_DIFF_FAC = 0xB6D2;  /* 0.71414 * 2^16 */
  private static final int CB_DIFF_FAC = 0x581A;  /* 0.34414 * 2^16 */
  
  public Image Picture;       // The Image
  public int frameIdx;       // notice the frame number (display order)
  public int frameType;      // I, B or P
  public int Pix_Map[];       // The pixels in Java RGB model
  public int w, h;        // The dimensions of the frame
  public ColorModel cm;
  private long pts;       // Presentation timestamp (in milliseconds or 90khz)
  private int picRate = 0;      // Needed to calculate the lag
  
  /**
  //The constructor notices the frame sizes and produces an image and an array
  //to store the RGB pixel values . The Applet (app) object is necessary to call
  //the "createImage" routine.
   * @param app
   * @param cm
   * @param w
   * @param h
   * @param o_w
   * @param o_h
   */
  public VideoElement (final JavidFrame app, final ColorModel cm, final int w, final int h) 
  {
    if (w == 0 || h == 0)
      return;

    Pix_Map = new int[w * h]; // memory for the translated RGB values
    Picture = app.createImage(new MemoryImageSource(w, h, cm, Pix_Map, 0, w));
    this.w = w; this.h = h; this.cm = cm;

    pts = -1;
    picRate = 0;
  }


//Time in milliseconds that this element is to be displayed

  public long getPts() 
  {
    return pts;
  }

  public void setPts(final long presentation_time_stamp) 
  {
    pts = presentation_time_stamp;
  }

  public void setPicRate(final int _picRate) 
  {
    picRate = _picRate;
  }

  public int getPicRate() 
  {
    return picRate;
  }

//The method "Make_Picture" is called every time the scanner has decoded a frame.
//It expects the frame information as YUV values and translates them into the
//Java RGB color system.

//4/3/01: Unrolled inner loop -- shaved 5%

  public void makePicture(final int Pixels[][]/*, int f_idx, int f_type */) 
  {
    int cr, cb, i, red, green, blue, luminance, crb_g;

    // Removed f_idx, f_type so that cr & cb get faster register access
    // Frame_idx = f_idx; Frame_type = f_type;

    //  because one crominance information is applied to 4 luminace values
    //  2 "pointers" are established, which point to the 2 lines containing
    //  the appropriate luminace values:
    //

    int lum_idx1 = 0, lum_idx2 = w;
    final int size = (w * h) >>> 2;

    // Save time looking up array indices
    final int P0[] = Pixels[0];  // Y
    final int P1[] = Pixels[1];  // U
    final int P2[] = Pixels[2];  // V

    for (i = 0; i < size; i++) 
    { // for all crominance values ...

      cb = P2[i] - 128; // extract the
      cr = P1[i] - 128; // chrominace information

      crb_g = cr * CR_DIFF_FAC + cb * CB_DIFF_FAC;

      cb *= CB_FAC;
      cr *= CR_FAC;

      luminance = P0[lum_idx1] << 16; // extract lum.

      red = (luminance + cr);
      red = ((red & 0xff000000) == 0) ? red & 0xff0000: (red > 0xff0000) ? 0xff0000 : 0;

      blue = (luminance + cb) >> 16;
      blue = ((blue & 0xffffff00) == 0) ? blue : (blue > 0xff) ? 0xff : 0;

      green = (luminance - crb_g) >> 8;
      green = ((green & 0xffff0000) == 0) ? green & 0xff00: (green > 0xff00) ? 0xff00 : 0;

      Pix_Map[lum_idx1++] = ( red | green | blue);

      luminance = P0[lum_idx1] << 16; // extract lum.

      red = (luminance + cr);
      red = ((red & 0xff000000) == 0) ? red & 0xff0000: (red > 0xff0000) ? 0xff0000 : 0;

      blue = (luminance + cb) >> 16;
      blue = ((blue & 0xffffff00) == 0) ? blue : (blue > 0xff) ? 0xff : 0;

      green = (luminance - crb_g) >> 8;
      green = ((green & 0xffff0000) == 0) ? green & 0xff00: (green > 0xff00) ? 0xff00 : 0;

      Pix_Map[lum_idx1++] = ( red | green | blue);

      luminance = P0[lum_idx2] << 16; // extract lum.

      red = (luminance + cr);
      red = ((red & 0xff000000) == 0) ? red & 0xff0000: (red > 0xff0000) ? 0xff0000 : 0;

      blue = (luminance + cb) >> 16;
      blue = ((blue & 0xffffff00) == 0) ? blue : (blue > 0xff) ? 0xff : 0;

      green = (luminance - crb_g) >> 8;
      green = ((green & 0xffff0000) == 0) ? green & 0xff00: (green > 0xff00) ? 0xff00 : 0;

      Pix_Map[lum_idx2++] = ( red | green | blue);

      luminance = P0[lum_idx2] << 16; // extract lum.

      red = (luminance + cr);
      red = ((red & 0xff000000) == 0) ? red & 0xff0000: (red > 0xff0000) ? 0xff0000 : 0;

      blue = (luminance + cb) >> 16;
      blue = ((blue & 0xffffff00) == 0) ? blue : (blue > 0xff) ? 0xff : 0;

      green = (luminance - crb_g) >> 8;
      green = ((green & 0xffff0000) == 0) ? green & 0xff00: (green > 0xff00) ? 0xff00 : 0;

      Pix_Map[lum_idx2++] = ( red | green | blue);

      if (lum_idx1 % w == 0) 
      { // end of line ?
        lum_idx1 += w;
        lum_idx2 += w;
      }
    }
    Picture.flush(); // Make sure that the new pixel values are taken
  }
}
