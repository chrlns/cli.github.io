/*
 *  Javid
 *  Copyright (c) 2007 by Christian Lins <christian.lins@web.de>
 *  Copyright (c) 2002 by Ron <r_breukelaar@hotmail.com>
 *  Copyright (c) by Joerg Anders <ja@informatik.tu-chemnitz.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package javid.video.mpeg1;

import java.io.EOFException;
import java.io.IOException;

public class IoTool
{
  public static final int TYPE_AUDIO = 0;
  public static final int TYPE_VIDEO = 1;   
  
  private CutBuffer       dis = null;       // THE input stream
  private int             type;
  private int             bit_pos = 0;        // bit- "pointer" 
  private long            longword = 0L;      // THE bit shift register
  private boolean         eof = false;

  public IoTool(final CutBuffer stream, int type) 
  {
    dis   = stream;
    this.type = type;
  }

  public void stop() 
  {
  }

  public final void setStream(final CutBuffer _dis) 
  {
    dis = _dis;
  }

  public final CutBuffer getStream() 
  {
    return dis;
  }

  /*public final void buhBye() 
  {
  }*/

  public final void close() throws IOException 
  {
    dis.close();
  }

  public final boolean is_eof() 
  { 
    return eof; 
  }

  // The method "skip(long n)" skips over n bytes but takes into account that
  // some of them are already in shift register.
  public final void skip(long n) 
  {
    final int k = bit_pos >> 3; //bit_pos / 8;        // How many bytes are already in shift register ?
    n -= k;           // substract from whole count
    bit_pos -= k << 3; //k * 8;       // skip over the bits in shift register
    try 
    {
      while (n > 0)
        n -= dis.skip(n);
    }
    catch (final IOException e) 
    {
      e.printStackTrace();
    }
  }

  // The method "get_read_bytes()" tells how many bytes are in shift register.
  public final int get_read_bytes() 
  {
    if ((bit_pos & 0x7) != 0) // "bit_pos" sould be byte aligned
    {       
      System.out.println("get_read_bytes: bit_pos = " + bit_pos);
    }
    return (bit_pos / 8);
  }

  // The method "get_long" grabs "bytes" from data input stream
  // into the shift register "longword".
  private final void getLong() throws InterruptedException 
  {
    try 
    {
      longword = (longword << 32) | (((long) readByte()) << 24) |
        (((long) readByte()) << 16) |
        (((long) readByte()) << 8) | readByte();

      bit_pos += 32;
    }
    catch (final EOFException e) 
    {
      eof = true;
      bit_pos += 32;
      longword <<= 32;
      System.out.flush();
    }
    catch (final IOException e) 
    {
      System.out.println("get_long: " + e.toString());
      throw new InterruptedException();
      //System.exit(10);
    }
  }

  // The method "get_bits" gets the next "n" bits from shift register
  // interprets them as integer and returns this integer value.
  // TODO: Takes to much time!
  public synchronized int getBits(final int n) throws InterruptedException 
  {
    if (bit_pos < n) getLong();

    bit_pos -= n; // correct bit "pointer"
    // FIXME: array lookup shift faster??
    return (int) ((longword >>> bit_pos) & ((1L << n) - 1L));
  }

  // The method "skip_bits" skips the next "n" bits from shift register.
  // This method created because too much time was being wasted doing the
  // math in get_bits when the result was just going to be thrown out.
  // TODO: This method is called MANY times
  public synchronized void skip_bits(final int n) throws InterruptedException 
  {
    if (bit_pos < n) 
      getLong();
    bit_pos -= n; // correct bit "pointer"
  }

  // The method "next_bits" checks whether the next "n" bits match the
  // "pattern". If so it returns "true"; otherwise "false".
  // Note: This method changes the bit "pointer" physically BUT NOT
  // logically !!!
  // TODO: This method is called MANY times!!
  public final boolean next_bits(final int pattern, final int n) throws InterruptedException {
    if (bit_pos < n) getLong();
    return (int)((longword >>> (bit_pos - n)) & ((1L << n) - 1L)) == pattern;
  }

  // The method "peek_bits" is like get_bits except it leaves the
  // bits in the shift register.  Use it when you want to read
  // the same bits more than once.

  public synchronized int peek_bits(final int n) throws InterruptedException {
    if (bit_pos < n) getLong();
    return (int)((longword >>> (bit_pos - n)) & ((1L << n) - 1L));
  }

  // The method "unget_bits" gives "n" bits back to the IO system. Because
  // "n" is always less than 32 this can be performed by a simple
  // correction of the bit "pointer".

  // !! Do not unget more then 32 bits... !!

  public final void unget_bits(final int n) 
  {
    bit_pos += n;
  }

  // The method "next_start_code" aligns the bit "pointer" to the next
  // byte and tries to find the next MPEG start code. Because (only) start
  // codes are made of a 24-bit ONE the method searches such a pattern.
  // (see also: ISO 11172-2)

  public final void next_start_code() throws InterruptedException 
  {
    if ((bit_pos & 0x7) != 0) 
      bit_pos &= ~0x7;

    while (!next_bits(0x1, 24) && !eof) skip_bits(8);
  } 

  // Method to call the right read-function...
  // TODO: This method is called LOTS OF times
  private synchronized int readByte() throws IOException
  {
    switch(type) // TODO: BIG FIX!! type does not change while running!!!
    {
      case TYPE_AUDIO:
      {
        return dis.readAudio();
      }
      case TYPE_VIDEO:
      {
        return dis.readVideo();
      }
    }
    return -1;
  }
}


