/*
 *  Javid
 *  Copyright (C) 2007 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package javid.video.mpeg1;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.MemoryImageSource;

import javid.gui.VisualizationCanvas;

/**
 * Image rendering class.
 */
public class MovieScreen 
  extends VisualizationCanvas 
  implements ImageObserver
{
  private VideoElement elem;       // The element to be displayed
  private IoTool mpegStream;    // The io_tool used for video
  private long lastVPts;      // Video timestamp of last frame
  private long lastAPts;      // Audio timestamp of last frame
  private long lastATime;     // Time of last audio time
  
  public boolean playing;
  private boolean _scaling = false; // Should picture be scaled?
  
  private int _scaleMap[] = null;   // Scale array buffer
  private Image _scalePicture;    // Scale image
  private MemoryImageSource _scaleSource; // Source of scaled image
  
  private Graphics graphics = null; // Variable to ensure getGrapics is called only ones
  
  private BufferedImage buffer;      // Double buffering image
  
  // 1/picrate, delay in milliseconds
  private static final int picLags[] = {
    -1,   // forbidden (ISO/IEC 11172-2: 1993 (E) p. 24)
    42,   // 23.976
    42,   // 24
    40,   // 25
    33,   // 29.97
    33,   // 30
    20,   // 50
    17,   // 59.94
    17,   // 60
    -1, -1, -1, -1, -1, -1, -1  // reserved
  };

  public MovieScreen()
  {
    buffer = new BufferedImage(352, 288, BufferedImage.TYPE_INT_RGB);
  }
  
  public Dimension getPreferredSize()
  {
    return new Dimension(buffer.getWidth(), buffer.getHeight());
  }
  
  public void init(final IoTool _mpeg_stream)
  {
    lastVPts = 0;
    mpegStream = _mpeg_stream;
  } 
  
  public void setElement(final VideoElement _elem) 
  {
    elem = _elem;
  }
  
  public VideoElement getElement()
  {
    return elem;
  }
  
  public long getLastVPts()
  {
    return lastVPts;
  }
  
  public long getLastAPts()
  {
    return lastAPts;
  }
  
  public void setScaling(final boolean s)
  {
    _scaling = s;
  }
  
  /**
  * Calculate amount of intra-frame delay from current picRate.
  * This value is used only when an explicit PTS value is not
  * available.
  */
  private int getLag() 
  {
    final int ret = picLags[elem.getPicRate()];
    if (ret == -1) 
    {
      // This only happens on non-standard framerates.
      // We'll just hack it for now.
      // FIXME: return difference between last two valid PTS values.
      System.out.println("TODO: getLag()");
      return 40;
    }
    return ret;
  }
   
  public void resetGraphics()
  {
    graphics = getGraphics();
  }
  
  /***
  * The paint method. If there is no error of any sort and there is a
  * picture to be displayed, wait for the right moment and display the
  * picture.
  */
  // TODO: Takes a lot of time!
  public void paintComponent(Graphics t) 
  {
    final int W = getWidth();
    final int H = getHeight();
    
    if (W == 0 || H == 0)
      return;
  
    if (buffer == null || W != buffer.getWidth(null) 
      || H != buffer.getHeight(null) 
      || (_scaling && _scaleMap == null && elem != null))
    {
      //_buffer = createImage(W, H);
      /*buffer = GraphicsEnvironment.getLocalGraphicsEnvironment()
                  .getDefaultScreenDevice().getDefaultConfiguration()
                  .createCompatibleImage(W, H);*/
      buffer = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
      buffer.setAccelerationPriority(1);
      System.out.println("Create Image!!");
  
      if (_scaling && elem != null)
      {
        int hhh = H;
        if (hhh < elem.h)
          hhh = elem.h;
  
        System.out.println(W+" "+H);
        _scaleMap     = new int[W * H];
        _scaleSource  = new MemoryImageSource(W, H, elem.cm, _scaleMap, 0, W);
        _scalePicture = createImage(_scaleSource);
      }
    }
  
    final Graphics g = buffer.getGraphics();
  
    if (mpegStream == null || elem == null)
    { 
      t.drawImage(buffer, 0, 0, this); // was null
      return;
    }
  
    // Now the initialization should be complete
    // and we can draw some moving pictures..
   
    final CutBuffer cb = mpegStream.getStream();
  
    long pts = elem.getPts(); // PTS = Presentation TimeStamp
    long cat = cb.getAudioPlayingTime();
    //final long ccat = cat;
  
    if (cat == lastAPts && cat > -1)
    {
      cat = lastAPts + System.currentTimeMillis() - lastATime;
    }
    else if (cat > -1)
    {
      lastAPts = cat;
      lastATime = System.currentTimeMillis();
    }
    //System.out.println("PTS: " + pts);
  
    // If pts looped, reset _start_time
    if ((pts < lastVPts - 4000 || pts > lastVPts + 5000) && pts != -1)
    {
      cb.setStartTime(System.currentTimeMillis() - pts);
      lastVPts = pts - getLag();
    }
  
    // If the pts didn't change -> make delay frame-rate dependant
    else if (pts <= lastVPts && cb.getCurrentTime() <= pts + 1000)
      pts = lastVPts + getLag();
  
    long now = cb.getCurrentTime();
    long a_v = now - cat;
  
    // If no audio or weird audio times (with looping)
    if (cat == -1 || a_v < -10000 || a_v > 10000)
    {
      cat = pts;
      a_v = 1;
    }
  
    // sync audio
    if (a_v < -100 || a_v > 100)
    {
      cb.addToStartTime(a_v / 4);
      now = cb.getCurrentTime();

    }
  
    //System.out.println("-- now: "+now+" pts: "+pts+" cat: "+cat+
    //  " a-v: "+a_v+" start: "+cb.getStartTime()+" sleep: "+(pts-now));
    //System.out.flush();
          
    lastVPts = pts;
    //lastAPts = cat;
  
    int sleepieTime = (int)(pts - now);
    if (now == 0)
      sleepieTime = 0;
    
    // This can cause heavy lags, if Audio is not synchronous! 
    if (sleepieTime > 10 && sleepieTime < 5000) 
    {
      try 
      {
        System.out.println("MovieScreen::paintComponent(): Sleep for " + (sleepieTime - 10) + "ms");
        Thread.sleep(sleepieTime - 10); 
        //Thread.yield();
      } 
      catch (final Exception e) 
      {
        System.out.println("Exception : " + e.toString()); 
      }
    }
 
    if (!playing)
    {
      long n = System.currentTimeMillis();
      while (!playing)
        Thread.yield(); 

      long wait = System.currentTimeMillis() - n;
      System.out.println("MovieScreen::paintComponent(): Waited " + wait + "ms");
      cb.addToStartTime(wait);
    }
  
    if (_scaling && _scalePicture != null)
    {
      try
      {
        final int w = elem.w;
        final int h = elem.h;
        int x, y, cx, cy, off1, off2;
        final int map[] = elem.Pix_Map;
  
        for (y = 0; y < h; y++)
        {
          off1 = y*w;
          off2 = y*W;
  
          for (x = 0; x < W; x++)
          {
            cx = x * w / W;
            _scaleMap[off2 + x] = map[off1 + cx];
          }
        }
  
        if (H >= h)
        {
          for (y=H-1; y>=0; y--)
          {
            cy = y * h / H;
            System.arraycopy(_scaleMap, cy*W, _scaleMap, y*W, W);
          }
        }
        else
        {
          for (y=0; y<H; y++)
          {
            cy = y * h / H;
            System.arraycopy(_scaleMap, cy*W, _scaleMap, y*W, W);
          }
        }
  
        _scaleSource.newPixels();
        _scalePicture.flush();
      }
      catch(final Exception e)
      { 
        e.printStackTrace();
      }

      g.drawImage(_scalePicture, 0, 0, null);
    }
    else
      g.drawImage(elem.Picture, 0, 0, null);
   
    t.drawImage(buffer, 0, 0, this);
  }
  
  public void drawBox(final Graphics g, final int x, final int y)
  {
    g.setColor(Color.black);
    g.fillRect(x, y, 20, 20);
  
    g.setColor(Color.white);
    g.drawLine(x, y, x+7, y);
    g.drawLine(x+12, y, x+19, y);
    g.drawLine(x, y+19, x+7, y+19);
    g.drawLine(x+12, y+19, x+19, y+19);
  
    g.drawLine(x, y, x, y+7);
    g.drawLine(x, y+12, x, y+19);
    g.drawLine(x+19, y, x+19, y+7);
    g.drawLine(x+19, y+12, x+19, y+19);
  }
  
  public boolean imageUpdate(final Image img, final int x, final int y, final int w, final int h, final int info)
  {  
    if ((info & ImageObserver.ALLBITS) != 0)
    {
      final Graphics g = buffer.getGraphics();
      System.out.println("--"+g.drawImage(_scalePicture, 0, 0, this));
      graphics.drawImage(buffer, 0, 0, null);
      repaint();
      System.out.println("imageUpdate()");
      return false;
    }
    
    return true;
  }
}
