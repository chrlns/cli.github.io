/*
 *  Javid
 *  Copyright (C) 2007 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
    Javid
    Copyright (c) 2007 Christian Lins <christian.lins@fh-osnabrueck.de>
    
    based on Kutttpech
    Copyright (C) 2002  Ron <r_breukelaar@hotmail.com>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
package javid.video.mpeg1;

import java.io.InputStream;

public class AudioElement
{
  private char        buffer[]; // The buffer
  private InputStream is;       // The InputStream to be parsed
  private int         cursor;   // Number of bytes in buffer

  private boolean eof = false;  // End of file reached?

  private long readAhead;       // 8 byte read ahead buffer
  private long timestamp;       // Time stamp of this frame
  private long read;            // Number of bytes read  
  
	public AudioElement(final long time)
	{
		buffer    = new char[1024];
		cursor    = 0;
		timestamp = time;
	}

	/***
	 * Function will fill an 'AudioElement' and return the last eight bytes read
	 * (will return -1 if end of file is reached)
	 * -- replaced copy-loop with System.arraycopy -> faster
	 */
	public long fill(final InputStream is, final long next32) throws Exception
	{
		this.readAhead = next32;
		this.is        = is;
		this.cursor    = 0;
		this.read      = 0;

		read_to_1();		// read up to next start code

		if (readAhead == -1) 	// if for some reason _long already is -1 -> make it -2
			readAhead = -2; 

		if (eof)		// if end of file is reached -> _long = -1
			readAhead = -1;

		// downsizing buffer for optimal mem-usage...
    // Comment: this is bullshit 'cause we have enormous troubles
    // with the gc
	/*	final char temp[] = new char[cursor];

		//for (int i=0; i<_cursor; i++)
		//	temp[i] = _buffer[i];
		System.arraycopy(_buffer, 0, temp, 0, _cursor);

		_buffer = temp;*/

		return readAhead;
	}

	/***
	 * Will read up to next start code and store the date read in buffer
	 * -- replaced copy loop with System.arraycopy, should be faster
	 */
	private void read_to_1() throws Exception
	{
		int r;
		do
		{
			r = is.read();
			read++;

			if (r != -1)
			{
				buffer[cursor++] = (char)((readAhead >>> 24) & 255);

				readAhead = (readAhead & 0xffffffff00000000L) | ((readAhead & 0xffffffL) << 8) | r;

				// if cursor exceeds buffer -> buffer * 2
				if (cursor >=  buffer.length) 
				{
					//max *= 2;
					final char temp[] = new char[buffer.length << 2];
					System.arraycopy(buffer, 0, temp, 0, buffer.length);

					buffer = temp;
				}
			}
			else
				eof = true;
		}
		//while (((_long & 0xffffffL) >>> 8) != 1 && !_eof);
		while ((readAhead & 0xffffffffL) != 0x1c0 && (readAhead & 0xffffffffL) != 0x1e0 && !eof);
	}

	public int getSize()
	{
		return cursor;
	}

	public char[] getBuffer()
	{
		return buffer;
	}

	public long getTimeStamp()
	{
		return timestamp;
	}

	public long getReadBytes()
	{
		return read;
	}
}
