/*
 *  Javid
 *  Copyright (C) 2007 by Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

/*
    Javid
    Copyright (C) 2002  Ron <r_breukelaar@hotmail.com>

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
*/
package javid.video.mpeg1;

import java.io.IOException;
import java.io.InputStream;
import java.util.Hashtable;
import java.util.Vector;

import javid.audio.player.Player;
import javid.gui.JavidFrame;

public class CutBuffer 
  extends InputStream 
  implements Runnable
{
  private Vector<CutElement>    buffer;           // The video frames (I/P/B/SEQ/GOP)
  private Vector<AudioElement>  audioElements;    // The audio frames
  //private Vector    removedElements;  // To be recycled video frames
  private Hashtable<String, TokenListener> tokenListeners;   // Handlers for special tokens

  private Thread        thread;       // The parse thread
  private InputStream   in;           // The inputstream to parse
  private CutElement    readElement;  // The video frame that is currently read
  private AudioElement  audioElement; // The audio frame that is currently read
  private char readElementBuffer[];
  private char audioElementBuffer[];  // Temporary buffers to speed up reading

  private int vFrameCursor, aFrameCursor;       // Pointer to current A/V frames in buffers
  private int readCursor, audioCursor;          // Read positions in current A/V frames
  private int waiting = 0;              // Number of threads waiting
  private int reopenCount = 0;          // Number of retries

  private boolean cutP;                   // Allow cutting of P/B-frames when needed?
  private boolean buffering     = false;  // Buffer all data (and don't forget)
  private boolean skipbegin;             // Helps to skip to next SEQ_START
  private boolean eof           = false;  // End of file reached?
  private boolean reopen        = false;  // If EOF reopen stream?
  private boolean stopped       = false;  // Stop the current read-thread
  private boolean corrupt       = false;  // Can current Element be corrupt?
  private boolean tokenInGop    = false;  // Was there a token in the last Gop?
  private boolean firstToken    = true;   // Is the next token the first?
  private boolean dropAudio     = false;  // Drop next audio frame
  //private boolean testingAudio  = true;   // Still testing audio

  private long readAhead      = 0;   // The read-ahead-buffer (8 bytes)
  private long timestamp;            // The last time stamp read via read_video
  private long starttime;            // The virtual start time of the movie
  private long readtime       = -1;  // Time to pass on to next CutElement
  private long readBytes      = 0;   // Number of bytes read (unparsed)
  private long frameCount;           // Total number of frames read
  private long skippedFrames  = 0;   // The skipped frames

  private long firstVideoTime     = -1;  // Self explaining
  private long lastVideoTime      = -1;  //  "       "
  private long firstAudioTime     = -1;  //  "       "
  private long lastAudioTime      = -1;  //  "       "
  private long audioBytesCounter  = 0;                          // Used to estimate audio times
  private final long minAudioBuffers = 1000;        // Self explaining
  private final long maxAudioBuffers = 5000;        //  "       "
  private long desiredAudioBuffer    = -1;      //  "       "
  private double streamSpeed;          // Speed of stream in kbps
  //private double lastStreamSpeed;        // Needed for switching...
  private double frameSpeed;         // Speed of stream in fps
  private double audioMsPerByte = 0;            // Number of ms per audio byte

  //private final long frameSize[] = new long[50];     // The last 50 frame sizes
  //private final long frameTime[] = new long[50];     // The last 50 frame times
  //private final long frameType[] = new long[50];     // The last 50 frame types
  //private int frameArrayCursor = 0;        // Wrap around cursor to fill arrays
  private int framesSinceLastGop = 0;        // Counter for GOP size
  private int lastGopSize = 0;         // Last GOP size

  private Player      audioPlayer = null;       // The audio player (needed to check audio)
  private JavidFrame javidApplet = null;        // The JavidApplet applet  
  
	public CutBuffer(final InputStream in, final boolean cutP, final boolean buffering)
	{
		this.in = in;
		if (in == null)
			System.out.println("INPUTSTREAM == NULL !!");
		this.cutP = cutP;
		
		readElement = null;

		readCursor = 0;
		vFrameCursor = 0;
		aFrameCursor = 0;
		frameCount = 0;

		//removedElements = new Vector();
		audioElements   = new Vector<AudioElement>();
		buffer          = new Vector<CutElement>();
		tokenListeners = new Hashtable<String, TokenListener>();

		addTokenListeners();

		//_long = -1;
		starttime = -1;

		skipbegin = true;
		this.buffering = buffering;
	}

	public void start()
	{
    System.out.println("Starting CutBuffer thread...");
		thread = new Thread(this, "Parse thread");
		thread.start();
	}

	public void addTokenListeners()
	{
		//addTokenListener("SHOW", "JavidApplet.ShowTokenListener");
	}

	public void addTokenListener(final String token, final String name)
	{
		try
		{
			final Class c = getClass().getClassLoader().loadClass(name);
			final TokenListener tl = (TokenListener)c.newInstance();
			tl.init(javidApplet);
			tokenListeners.put(token, tl);
			System.out.println("TokenListener '"+token+"' inititalized...");
		}
		catch(final Exception e) 
    { 
		  e.printStackTrace();
    }
	}

	public void processToken(final String token, final byte content[], final CutElement element)
	{
		final TokenListener tl = (TokenListener)tokenListeners.get(token);
		if (tl != null)
			tl.tokenReceived(element, content);
	}

	public void run()
	{
		try
		{
			readToLong();
			readToLong();
			readToLong();
			readToLong();

			while (!eof && !stopped)
			{
				// *** if NOT buffering and NOT cutting

				// If you are not buffering AND not cutting both buffers can
				// stay fairly small -> wait if bigger...
				while (!buffering && !cutP && buffer.size() > 20 && 
					(audioElements.size() > 20 || //_audioElement == null || 
						audioPlayer == null)) // || _audioPlayer.isStopped()))
					waitForRead();

				// NOTE: this is an IF, not a WHILE... 
				// Helps the parse thread to slow down when buffers are getting
				// big enough...
				if (!buffering && !cutP && buffer.size() > 10 && 
					(audioElements.size() > 10 || //_audioElement == null ||
						audioPlayer == null)) // || _audioPlayer.isStopped()))
          waitForRead();

				// *** if cutting (therefor not buffering)

				// Even if you are cutting P-frames... Don't read more then you can handle...
				while (cutP && buffer.size() > 50)
					waitForRead();

				// *** parsing

				// Try to read and parse one element from stream
				try
				{
					readElement();
				}
				catch (final Exception e)
				{ // Socket is closed... (maybe while 'stop' or while switching between streams)
					eof = true;
					System.out.println("Error while parsing: "+e);
				}

				// *** reopen

				// Should I reopen the stream? (handy for switching between streams on server-side)
				if ((eof && reopen && /*in instanceof StreamSwitch &&*/ reopenCount < 100
						&& (javidApplet == null || !javidApplet.isStopped()))
					|| (frameCount < 2 && eof /*&& in instanceof StreamSwitch*/))
				{
					if (reopenCount > 1)
					{
						final double extra = Math.pow(1.3, reopenCount-1);
						Thread.sleep((int)(1000 * extra));
					}
					else
						Thread.sleep(250);

					if (javidApplet != null)
					{
						//if (frameCount < 2)
						//	javidApplet.setProgressText("Can't open stream, retrying");
					}

					System.out.println("Reopen count: "+reopenCount);
					//final StreamSwitch s_switch = (StreamSwitch)in;
					try
					{
						//resetStream();
						//s_switch.reopen();
						//if (Err.reload && javidApplet != null)
						//	javidApplet.reloadPage();
							
					}
					catch(final Exception e)
					{
            System.err.println(e.getMessage());
					}

					eof = false;
					reopenCount++;
				}

				// Leaving some breathing space for other threads...
				Thread.yield();
			}
		}
		catch(final Exception e)
		{
			System.out.println("Stopped with scanning, but not nice...");
			e.printStackTrace();
		}

		//javidApplet.onEOF();
	}

	/***
	 * Read one element from the stream and put this element in buffer
	 */
	public void readElement() throws Exception
	{
		// *** new CutElement (or recycled one)

		CutElement e = null;
	/*	if (_removedElements.size() > 0)
		{
     	e = (CutElement)_removedElements.firstElement();
			_removedElements.removeElement(e); // hmm... :)
			e.setTimeStamp(_read_time);
		}
		else*/
			e = new CutElement(readtime);

		// *** fill the element

		readAhead = e.fill(in, readAhead, this);

		// *** Buffer thingies...

		// If EOF is not reached
		if (readAhead != -1)
		{
			// Remember the last timestamp for the next element
			if (e.getTimeStamp() > -1)
			{
				readtime = e.getTimeStamp();

				// Set some member variables
				if (readtime > lastVideoTime)
					lastVideoTime = readtime;
				if (firstVideoTime == -1)
					firstVideoTime = readtime;
			}

			// Stop looking for a Sequence header if you found one... ;)
			if (skipbegin && e.getType() == CutElement.SEQ_START)
				skipbegin = false;

			// Reset some variables every GOP
			if (e.getType() == CutElement.GOP_START)
			{
				if (!tokenInGop)
					firstToken = true;
				tokenInGop = false;
			}

			// Add element to buffer if everything is ok...
			if (!skipbegin && !corrupt)
			{
				buffer.addElement(e);
				readBytes += e.getBytesRead();
				if (e.getType() == CutElement.I_FRAME || e.getType() == CutElement.P_FRAME
					|| e.getType() == CutElement.B_FRAME)
				{
					frameCount++;
					framesSinceLastGop++;
				}

				if (e.getType() == CutElement.GOP_START)
				{
					lastGopSize = framesSinceLastGop;
					framesSinceLastGop = 0;
				}

				reopenCount = 0;

				//updateInfo();
			}

			// If you are skipping to the next Sequence header -> skip
			else if (skipbegin)
			{
				skippedFrames++;
				if (corrupt)
					corrupt = false;
			}

			// Reset corrupt toggle
			else if (corrupt)
				corrupt = false;

			// Unlock all blocking threads
			notify_reader();
		}
		else
		{
			eof = true;
			System.out.println("End of file reached...");
		}
	}

	/***
	 * Block current thread
	 */
	public synchronized void waitForRead()
	{
		if (stopped)
			return;
		try
		{
			waiting ++;
			wait(500);
			waiting --;
		}
		catch (final Exception e)
		{
			e.printStackTrace();
		}
	}

	/***
	 * Unblock all blocking threads
	 */
	public synchronized void notify_reader()
	{
    notifyAll();
	}

	// function for inputstream !!! but not used???
	/*public int available() 
    throws IOException
	{
		if (readElement == null)
			return 0;
			
		return readElement.getSize() - readCursor;
	}*/

	public Vector getBuffer()
	{
		return buffer;
	}

	public Vector getAudioBuffer()
	{
		return audioElements;
	}

	public long getTimeStamp()
	{
		return timestamp / 90; // 90 kHz
	}

	public long getStartTime()
	{
		return starttime;
	}

	public void addToStartTime(final long wait)
	{
		starttime += wait;
	}

	public void setStartTime(final long time)
	{
		starttime = time;
	}

	/***
	 * Time in millis calibrated from the start of the movie
	 */
	public long getCurrentTime()
	{
		if (starttime > -1)
			return System.currentTimeMillis() - starttime;
		else
			return 0;
	}

	/***
	 * The audio playing time, taking into account all the buffers.
	 * It still is an estimate, but getting realy close to it.
	 */
	public long getAudioPlayingTime()
	{
		long time = -1;
		long pos = 0;
		if (audioElement != null)
		{
			time = audioElement.getTimeStamp();
			pos  = audioCursor;
		}
		else
			return -1;
			//time = _last_audio_time;

		if (audioPlayer != null && !audioPlayer.isStopped() && firstAudioTime != -1
			&& !dropAudio && audioPlayer.hasStarted())
		{
			if (audioPlayer.getPosition() >= 0)
        //	System.out.println("getPosition: "+
			//		(_first_audio_time / 90 + (long)_audioPlayer.getPosition() + 1500));
				return firstAudioTime / 90 + audioPlayer.getPosition() + 1500;
      else
        return time / 90 + (long)(pos * audioMsPerByte)
					- audioPlayer.getBufferPosition();
		}
		else
			return -1;
	}

	public void setCutting(final boolean cut)
	{
		cutP = cut;
	}

  public int read() throws IOException
  {
    throw new IOException("No underlying InputStream!");
  }
  
	/***
	 * This thread is called from the IOTool class instead of calling the
	 * read() method. It reads the first byte of the video buffer and blocks
	 * if that buffer is empty.
	 */
  // TODO: This method is called MANY times and takes A LOT time!!
	public int readVideo() throws IOException
	{
		// If the current element is empty
		if (readElement == null || readCursor >= readElementBuffer.length)
		{
			// *** Goto next element

			boolean done, lagging = false;
			long lastTime = -1;
			if (readElement != null)
				lastTime = readElement.getTimeStamp();

			do
			{
				done = true;

				// garbage-collection workaround
				/*if (!_buffering && _removedElements.size() < 50 && _readElement != null)
					_removedElements.addElement(_readElement);*/

				// don't read beyond buffer-max
				while (buffer.size() <= vFrameCursor && !stopped)
          waitForRead();

				if (stopped)
					throw new IOException();

				// _readElement is next element
				readElement = (CutElement)buffer.elementAt(vFrameCursor);

				lagging = lagging || (  // why + 6000?
          (System.currentTimeMillis() - starttime > readElement.getTimeStamp() / 90 + 6000)
					&& buffer.size() > lastGopSize
					&& readElement.getTimeStamp() != lastTime);

        //System.out.println("Lagging="+lagging);
        
				// skip elements if needed
				if ((readElement.getType() == CutElement.P_FRAME 
                && readElement.getSize() <= 40)
					|| ((readElement.getType() == CutElement.P_FRAME
							|| readElement.getType() == CutElement.B_FRAME)
						&& cutP && starttime > -1 && readElement.getTimeStamp() > -1
					&& lagging)) // lagging is the most important parameter
				{
          System.out.println("Skipping...");
					done = false;
					if (buffering)
						vFrameCursor++;
					else 
          {
					  buffer.removeElement(readElement);
          }
				}
			}
			while (!done && !stopped);

			// If the thread stopped
			if (stopped)
				throw new IOException();
			
			if (buffering)
				vFrameCursor++;
			else
				buffer.removeElement(readElement);

			readCursor = 0;
			readElementBuffer = readElement.getBuffer(); // optimize

			final long t = readElement.getTimeStamp();
			if (t >= 0)
			{
				if (starttime == -1 || timestamp == -1)
					starttime = System.currentTimeMillis() - t / 90 + 1000; // 1 sec buffer
				timestamp = t;
			}

			notify_reader();
			Thread.yield();
		}

		if (stopped)
			throw new IOException();

		//if (_buffer.size() < 5 || _audioElements.size() < 5)
		Thread.yield();

		return readElementBuffer[readCursor++];
	}

  // TODO: This method is called MANY times and takes a lot time!!
	public int readAudio() throws IOException
	{
		if(audioElement == null || audioCursor >= audioElement.getSize())
		{
			while(audioElements.size() <= aFrameCursor && !stopped) 
			{
				audioElement = null; // gaps in audio shouldn't stop video
        waitForRead();
			}

			if (stopped)
				throw new IOException();

			audioElement = (AudioElement)audioElements.elementAt(aFrameCursor);

			if (!buffering)
				audioElements.removeElement(audioElement);
			else
				aFrameCursor++;

			audioCursor = 0;
			audioElementBuffer = audioElement.getBuffer();

			notify_reader();

			//while (_readElement == null && !_stopped)
				//wait_for_read();

			AudioElement le;
			if (audioElements.size() > 0)
				le = (AudioElement)audioElements.lastElement();
			else
				le = audioElement;

			long apt = getAudioPlayingTime();

			if (cutP && apt > -1 && !stopped
				&& le.getTimeStamp() < apt * 90 + minAudioBuffers * 90)
			{
				desiredAudioBuffer = (minAudioBuffers + maxAudioBuffers) / 2;

				while (apt > -1 && !stopped
					&& le.getTimeStamp() < apt * 90 + desiredAudioBuffer * 90)
				{
          waitForRead();
					if (audioElements.size() > 0)
						le = (AudioElement)audioElements.lastElement();
					apt = getAudioPlayingTime();
				}
			}

/*
			if (_cutP && apt > -1 && !_stopped
				&& le.getTimeStamp() > apt*90 + _max_audio_buffer*90)
			{
				_desired_audio_buffer = (_min_audio_buffer + _max_audio_buffer)/2;

				while (apt > -1 && !_stopped && _audioElements.size() > 0
					&& le.getTimeStamp() > apt*90 + _desired_audio_buffer*90)
				{
					_audioElement = (AudioElement)_audioElements.elementAt(_aFrameCursor);

					if (!_buffering)
						_audioElements.removeElement(_audioElement);
					else
						_aFrameCursor++;

					if (_audioElements.size() > 0)
						le = (AudioElement)_audioElements.lastElement();
					apt = getAudioPlayingTime();
				}
			}
*/

			if (apt > -1)
				desiredAudioBuffer = -1;

			if (firstAudioTime == -1 && audioElement.getTimeStamp() > -1)
				firstAudioTime = audioElement.getTimeStamp();
		}
		if (stopped)
			throw new IOException();

		//if (_audioElements.size() < 5 || _buffer.size() < 5)
		Thread.yield();

		return  audioElementBuffer[audioCursor++];
	}

	public void close() throws IOException
	{
		in.close();
	}

	public int read(final byte b[], final int off, final int len) throws IOException
	{
		for (int i = 0; i < len; i++)
			b[i+off] = (byte)readAudio(); // read replaced with readAudio

		return len;
	}

	public void addAudioElement(final AudioElement ae)
	{
		if (((audioPlayer != null && !audioPlayer.isStopped())
          || (audioPlayer == null && audioElements.size() < 50)))
    {
		  if (!dropAudio)
		    audioElements.addElement(ae);
      
      if (ae.getTimeStamp() != lastAudioTime && lastAudioTime != -1)
      {
        audioMsPerByte = (double)(ae.getTimeStamp() - lastAudioTime) / 90 / audioBytesCounter;
        lastAudioTime  = ae.getTimeStamp();
        audioBytesCounter = 0;
      }
      else if (lastAudioTime == -1)
        lastAudioTime = ae.getTimeStamp();

      audioBytesCounter += ae.getReadBytes();
      notify_reader();
    }
                //else
                        //System.out.println("Skipping audio...");
	}

	public void readToLong() throws Exception
	{
		final int r = in.read();
		if (r==-1)
			eof = true;

		readAhead = (readAhead << 8) | r;
	}

	public void setAudioPlayer(final Player player)
	{
		audioPlayer = player;
	}

	public boolean isBuffering()
	{
		return buffering;
	}

	public int getVideoFrameCursor()
	{
		return vFrameCursor;
	}

	public int getAudioFrameCursor()
	{
		return aFrameCursor;
	}

	public long getFirstTimeStamp()
	{
		return firstVideoTime / 90;
	}

	public long getLastTimeStamp()
	{
		return lastVideoTime / 90;
	}

	public long getBufferTime()
	{
		if (buffering)
			return (lastVideoTime - firstVideoTime) / 90;
		return 0;
	}

	public void setReopen(final boolean reopen)
	{
		this.reopen = reopen;
	}
/*
	public void updateInfo()
	{
		if (testingAudio)
		{
			testingAudio = false;
			//if (javidApplet != null && desiredAudioBuffer == -1
				//	&& (audioPlayer == null || audioPlayer.isStopped() 
			//		|| lastVideoTime - firstVideoTime > 6000*90))
				//javidApplet.addMessage("No audio supported");
			
			//else 
        if (javidApplet != null && audioPlayer != null && audioPlayer.hasStarted())
			{
				//javidApplet.addMessage("Synchrone audio supported");
				javidApplet.setVolumeOption(true);
			}
			else
				testingAudio = true;
		}

		final CutElement e = (CutElement)buffer.lastElement();
		frameSize[frameArrayCursor] = e.getBytesRead();
		frameTime[frameArrayCursor] = e.getTimeStamp();
		frameType[frameArrayCursor] = e.getType();

		frameArrayCursor = (frameArrayCursor + 1) % 50;

		long size = -e.getBytesRead();
		long begin = e.getTimeStamp();
		long end = e.getTimeStamp();
		int count = 0;

		for (int i=0; i<50; i++)
		{
			if (frameSize[i] != 0)
			{
				if (frameTime[i] < begin)
					begin = frameTime[i];
				if (frameTime[i] > end)
					end = frameTime[i];

				size += frameSize[i];
				if ((frameType[i] == CutElement.I_FRAME 
					|| frameType[i] == CutElement.P_FRAME
					|| frameType[i] == CutElement.B_FRAME)
						&& frameSize[i] >= 40)
					count++;
			}
		}

		if (e.getType() == CutElement.I_FRAME || e.getType() == CutElement.P_FRAME
			|| e.getType() == CutElement.B_FRAME)
			count--;

		final long time = end - begin;

		if (time > 0 && count > 3)
		{
			streamSpeed = (double)size / (double)time * 90.0 * 8.0;
			frameSpeed = count / (double)time * 90000.0;

			if (in instanceof StreamSwitch)
			{
				final StreamSwitch s_switch = (StreamSwitch)in;
				final int sspeed = s_switch.getSwitchSpeed();
				final Stream current = s_switch.getCurrentStream();

				if (current != null && current.speed == 0
					&& sspeed != -1 && streamSpeed > 1.2 * sspeed
					&& streamSpeed < lastStreamSpeed
					&& frameCount > 20)
				{
					try
					{
						final String old = s_switch.getCurrentStream().name;
						final Stream stream = s_switch.getStreamWithSpeed((int)streamSpeed);
						//javidApplet.addMessage("Switching to "+stream.name
						//	+"... please wait ("+(int)streamSpeed+"kbps)");
						//_JavidApplet.resetVideo();
						s_switch.open(stream.name);
						s_switch.switchTo(stream.name);
						resetStream();
						s_switch.close(old);

						//if (Err.reload && javidApplet != null)
						//	javidApplet.reloadPage();
					}
					catch (final Exception e2)
					{
						System.out.println(e2);
					}
				}

				lastStreamSpeed = (lastStreamSpeed * 4 + streamSpeed) / 5;
			}
		}
	}*/

	public double getBitsPerSecond()
	{
		return streamSpeed;
	}

	public double getFramesPerSecond()
	{
		return frameSpeed;
	}

	public int getGopSize()
	{
		return lastGopSize;
	}

	/***
	* Goto the I-Frame after given time (bin-search)
	*/
	public void setPlayTime(final long time)
	{
		if (!buffering) return;

		//long curTime = getCurrentTime();
		//addToStartTime(time - curTime);

		setStartTime(System.currentTimeMillis() - time);

		// ** video search for right time

		int size = buffer.size();
		int cur = size/2;
		int step = (cur+1)/2;

		CutElement e = (CutElement)buffer.elementAt(cur);
		long etime = e.getTimeStamp()/90;

		int best = cur;
		long btime = -1;

		while (step > 0 && etime != time)
		{
			if (etime < time)
				cur += step;
			else
				cur -= step;
	
			step /= 2;
			
			if (cur < buffer.size())
			{
				e = (CutElement)buffer.elementAt(cur);
				etime = e.getTimeStamp()/90;
			
				if ((btime == -1 || etime < btime) && etime >= time)
				{
					best = cur;
					btime = etime;
				}
			}
		}

		vFrameCursor = best;

		while (vFrameCursor < buffer.size()
			&& ((CutElement)buffer.elementAt(vFrameCursor)).getType() != CutElement.I_FRAME)
			vFrameCursor++;

		// ** audio search for right time

		if (audioElements.size() == 0 || audioPlayer == null) // || _audioPlayer.isStopped())
			return;

		size = audioElements.size();
		cur = size/2;
		step = (cur+1)/2;

		AudioElement a = (AudioElement)audioElements.elementAt(cur);
		long atime = a.getTimeStamp()/90;

		best = cur;
		btime = -1;

		while (step > 0 && atime != time)
		{
			if (atime < time)
				cur += step;
			else
				cur -= step;
	
			step /= 2;
			
			if (cur < audioElements.size())
			{
				a = (AudioElement)audioElements.elementAt(cur);
				atime = a.getTimeStamp()/90;
				
				if ((btime == -1 || atime < btime) && atime >= time)
				{
					best = cur;
					btime = atime;
				}
			}
		}

		aFrameCursor = best;
	}

	/***
	* Clear all data from buffers...
	*/
	public void clear()
	{
		if (buffer != null)
			buffer.removeAllElements();
		if (audioElements != null)
			audioElements.removeAllElements();
	}

	/***
	* Stop reading the stream and clear the buffer(s)
	*/
	public void stop()
	{
		stopped = true;
		notify_reader();
		clear();
	}

	/***
	 * 0x1fe token received... switch back?
	 */
	public void tokenReceived()
	{
		if (frameCount > 10 && !firstToken)
		{
			System.out.println("Second token...");
			//switchBandwith(false);
		}
		else if (frameCount <= 10)
			System.out.println("Ignoring token...");
		else
		{
			tokenInGop = true;
			firstToken = false;
			System.out.println("First token...");
		}
	}
}
