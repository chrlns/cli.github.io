/*
 *  clhttpd/C
 *  Copyright 2008 Christian Lins <christian.lins@web.de>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <sys/types.h>
#include <sys/socket.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define BACKLOG         5
#define DEFAULT_WORKERS 1

#define bool char
#define true 1
#define false 0

/* A queue element
   Basically this is the socket descriptor, but
   we could add useful things later, so I put it
   into a struct.
*/
struct queue_element_t
{
  bool isEmpty;
  int  socket;  // The client socket
};

// Constants
static const char* SERVER_NAME    = "clhttpd";
static const char* SERVER_VERSION = "0.1";

// Global variables
static struct queue_element_t* Queue;
static pthread_cond_t          QueueCond;
static pthread_mutex_t         QueueMutex;
static int                     QueuePos  = 0; // Current position in queue
static int                     QueueSize = 0; // Currently inserted elements

static bool  Running    = true;

/* Inserts a socket into the queue */
void queue_put(struct queue_element_t element)
{
  int idx;

  //printf("Put:Locking QueueMutex...\n");
  pthread_mutex_lock(&QueueMutex);
  //printf("Put:QueueMutex locked!\n");

  if(QueueSize >= sizeof(Queue))
    pthread_cond_wait(&QueueCond, &QueueMutex);

  idx = (QueuePos + QueueSize) % sizeof(Queue);
  Queue[idx] = element;
        
  QueueSize++;
  pthread_cond_signal(&QueueCond);
  pthread_mutex_unlock(&QueueMutex);
  //printf("Put: QueueMutex unlocked\n");
}

/* Retrieves a socket from the queue */
struct queue_element_t queue_get()
{
  struct queue_element_t tmp;

  //printf("Get:Locking QueueMutex...\n");
  if(pthread_mutex_lock(&QueueMutex) != 0)
    printf("[%s] Locking of queue in queue_get() failed!\n", SERVER_NAME);
  //printf("Get:QueueMutex locked!\n");

  if(QueueSize <= 0)
    pthread_cond_wait(&QueueCond, &QueueMutex);
    
  tmp = Queue[QueuePos];
  Queue[QueuePos].isEmpty = true;
        
  QueueSize--;
  QueuePos++;
  QueuePos %= sizeof(Queue);
        
  pthread_cond_signal(&QueueCond);       
  pthread_mutex_unlock(&QueueMutex);
  //printf("Get:QueueMutex unlocked\n");
  return tmp;
}

long filesize(FILE* file)
{
  fseek(file, 0, SEEK_END);
  return ftell(file);
}

/* Processes a HTTP request */
void process_request(int socket)
{
  int   bytes;
  char  buffer[128];
  char* method;
  char* file;
  FILE* fileHandle;
  
  bytes = recv(socket, buffer, 128, 0);
  buffer[127] = 0;

  method = strtok(buffer, " ");

  // Must a get request 
  if(strncmp(method, "GET", 3) == 0)
  {
    file = strtok(NULL, " ") + 1;
    printf("Requesting '%s'\n", file);
    
    // Check for directory requests
    if(strcmp(file, "") == 0)
    {
      file = "index.html";
    }

    fileHandle = fopen(file, "rb");
    if(fileHandle != NULL)
    {
      send(socket, "HTTP/1.1 200 Ok\nContent-Type: text/plain\n\n", strlen("HTTP/1.1 200 Ok\nContent-Type: text/plain\n\n"), 0);

      while(!feof(fileHandle))
      {
        bytes = fread(buffer, 1, 128, fileHandle);
        send(socket, buffer, bytes, 0);
      }
    }
    else
    {
      send(socket, "HTTP/1.1 404 Not Found\n\nError 404 Not Found", strlen("HTTP/1.1 404 Not Found\n\nError 404 Not Found"), 0);
      printf("404 Not Found\n");
    }
  }
  else
  {
    send(socket, "HTTP/1.1 500 Unknown command\n", strlen("HTTP/1.1 500 Unknown command\n"), 0);
    printf("Unknown method %s\n", method);
  }

  // Close the connection to the client
  close(socket);
}

void* work_loop(void* arg)
{
  struct queue_element_t element;

  /* Retrieve an element from the queue if available */
  while(Running)
  {
    element = queue_get();
    //printf("Loop\n");
    process_request(element.socket);
  }
  return NULL;
}

/* The program entry point */
int main(int argc, char* argv[])
{
  // Declare some variables
  int                     sock;
  struct sockaddr_in      sock_addr_server;
  struct sockaddr_in      sock_addr_client;
  socklen_t               sock_addr_client_size;
  int                     sock_client;
  struct queue_element_t  tmp_elem;
  pthread_t*              worker;

  // Initialize variable values
  sock_addr_client_size = sizeof(sock_addr_client);
  
  // Read mime types
  mime_init("mime.types");
  
  // Create a socket
  sock = socket(PF_INET, SOCK_STREAM, 0);
  if(sock == -1)
  {
    printf("[%s] Could not create a socket!\n", SERVER_NAME);
    return -1;
  }

  // Create a socket address for out socket
  sock_addr_server.sin_addr.s_addr = INADDR_ANY;
  sock_addr_server.sin_port        = htons(9000);
  sock_addr_server.sin_family      = AF_INET;

  // Bind socket to all interfaces
  if(bind(sock, (struct sockaddr*)&sock_addr_server, sizeof(sock_addr_server)) == -1)
  {
    printf("[%s] Could not bind to interface! Server already listening on port %u?\n", SERVER_NAME, ntohs(sock_addr_server.sin_port));
    return -1;
  }

  // Put socket in listening mode
  if(listen(sock, BACKLOG) == -1)
  {
    printf("[%s] Could not listen!\n", SERVER_NAME);
    return -1;
  }

  // Create queue
  pthread_mutex_init(&QueueMutex, NULL);
  pthread_cond_init(&QueueCond, NULL);
  Queue = malloc(sizeof(struct queue_element_t) * QueueSize);

  // Start working thread(s)
  worker = (pthread_t*)malloc(sizeof(pthread_t) * DEFAULT_WORKERS);
  if(pthread_create(worker, NULL, work_loop, NULL) != 0)
  {
    printf("[%s] Creating of pthread worker failed!\n", SERVER_NAME);
    return -1;
  }

  // Print version information
  printf("[%s] HTTP Server %s/%s started\n", SERVER_NAME, SERVER_NAME, SERVER_VERSION);

  while(Running)
  {
    // Accept connections
    sock_client = accept(sock, (struct sockaddr*)&sock_addr_client, &sock_addr_client_size);
    if(sock_client == -1)
    {
      printf("[%s] An error has occurred while accepting connection!\n", SERVER_NAME);
      return -1;
    }
    else
    {
      printf("[%s] Connection accepted.\n", SERVER_NAME);

      tmp_elem.isEmpty       = false;
      tmp_elem.socket        = sock_client;
      queue_put(tmp_elem);
    }
  }

  // Wait for working threads
  Running = false;

  // Free resources
  close(sock);
  pthread_mutex_destroy(&QueueMutex);
  pthread_cond_destroy(&QueueCond);
  free(Queue);
  free(worker);

  return 0;
}

