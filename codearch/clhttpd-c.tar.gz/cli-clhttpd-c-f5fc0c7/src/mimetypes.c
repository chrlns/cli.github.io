/*
 *  clhttpd/C
 *  Copyright 2008 Christian Lins <christian.lins@web.de>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <stdio.h>

struct mime_type_t
{
  char extension[12];
  char typename[52];
};

static struct mime_type_t* mime_types = NULL;

/*
 * Returns the MIME-Type for a given filename.
 */
const char* mime_get(char* filename)
{
  
}

/*
 * Initializes the MIME-Types hash map with the values from the
 * given filename. By default this is /etc/mime.types which includes
 * the system-wide MIME-Types.
 * The default file can be very large so that it might be useful to
 * provide a stripped file with the most common file types.
 */
void mime_init(char* filename)
{
  char* buf;
  FILE* file;
  
  file = fopen(filename, "r");
  if(file == NULL)
  {
    file = fopen("/etc/mime.types", "r");
    if(file == NULL)
    {
      printf("Could not read mime.types file!\n");
      return;
    }
  }
  
  buf = malloc(1024);
  while(!feof(file))
  {
    if(fgets(buf, 1024, file) == NULL)
      break;
    else
    {
      // Split the line in type and extension
    }
  }
  
  free(buf);
  fclose(file);
}
