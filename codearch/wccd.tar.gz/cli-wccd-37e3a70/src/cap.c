#include <stdio.h>
#include <pcap.h>

int main(int argc, char *argv[])
{
	char* dev;
	char errbuf[PCAP_ERRBUF_SIZE];
	pcap_t* handle;
	struct pcap_pkthdr header; /* The header that pcap gives us */
	const u_char* packet;

	if(argc >= 2) {
		dev = argv[1];
	} else {
		dev = pcap_lookupdev(errbuf);
		if(dev == NULL) {
			fprintf(stderr, "Couldn't find default device: %s\n", errbuf);
			return -1;
		}
	}
	printf("Device: %s\n", dev);

	/* Open device for sniffing */
	handle = pcap_open_live(dev, BUFSIZ, 1, 1000, errbuf);
	if (handle == NULL) {
		fprintf(stderr, "Couldn't open device: %s\n", errbuf);
		return -2;
	}

	/* Grab a packet */
	packet = pcap_next(handle, &header);

	/* Print its length */
	printf("Jacked a packet with length of [%d]\n", header.len);

	/* And close the session */
	pcap_close(handle);
	return 0;
}
