/*
 *  Xina
 *  Copyright (C) 2008,2009 Christian Lins <cli@openoffice.org>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.xerxys.xina;

import org.xerxys.xina.io.Resource;

/**
 * Main entrypoint class.
 * @author Christian Lins
 */
public class Xina 
{

  /**
   * Entrypoint method.
   * @param args
   */
  public static void main(String[] args)
  {
    if(args.length <= 0)
    {
      printArguments();
      return;
    }
    else // Parse arguments
    {
      String      modeParam   = args[0];
      ModeHandler modeHandler = null;
      
      if(modeParam.equals("moo"))
      {
        printAscii();
        return;
      }
      else if(modeParam.equals("create"))
      {
        modeHandler = new Creator(args);
      }
      else if(modeParam.equals("install"))
      {
        modeHandler = new Installer(args);
      }
      else if(modeParam.equals("purge"))
      {
        modeHandler = new Purger(args);
      }
      else if(modeParam.equals("remove"))
      {
        modeHandler = new Remover(args);
      }
      else
      {
        System.out.println("Unknown command/option!");
        printArguments();
        System.exit(1);
      }

      modeHandler.run();
    }
    
    // Load xina database
  }
  
  private static void printArguments()
  {
    String argHelp = Resource.getAsString("org/xerxys/xina/resource/argument_help");
    System.out.println(argHelp);
  }
  
  private static void printAscii()
  {
    String ascii = Resource.getAsString("org/xerxys/xina/resource/ascii_art");
    System.out.println(ascii);
  }

}
