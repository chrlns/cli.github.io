/*
 *  Xina
 *  Copyright 2008 Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.xerxys.xina.io;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

/**
 * Stellt statische Methoden zum Laden von
 * einzelnen Resourcen zur Verfuegung.
 */
public class Resource
{
  public static byte[] getBytes(File file)
  {
    try
    {
      FileInputStream in = new FileInputStream(file);
      byte[] buffer = new byte[(int)file.length()];
      
      in.read(buffer);
      
      return buffer;
    }
    catch(IOException ex)
    {
      ex.printStackTrace();
      return null;
    }
  }
  
  /**
   * Laedt eine Resource und gibt einen Verweis auf sie als
   * URL zurueck.
   * @return
   */
  public static URL getAsURL(String name)
  {
    return ClassLoader.getSystemClassLoader().getResource(name);
  }
  
  /**
   * Loads a resource as InputStream.
   * @param name
   * @return
   */
  public static InputStream getAsStream(String name)
  {
    try
    {
      URL url = getAsURL(name);
      if(url == null)
        return new FileInputStream(name);
      else
        return url.openStream();
    }
    catch(IOException ex)
    {
      ex.printStackTrace();
      return null;
    }
  }
  
  public static String getAsString(String name)
  {
    try
    {
      BufferedReader in = new BufferedReader(
              new InputStreamReader(getAsStream(name)));
      StringBuffer buf = new StringBuffer();

      for(String line = in.readLine(); line != null; line = in.readLine())
      {
        buf.append(line);
        buf.append("\n");
      }

      return buf.toString();
    }
    catch(IOException ex)
    {
      ex.fillInStackTrace();
      return null;
    }
  }
}
