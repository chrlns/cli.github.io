/*
 *  Xina
 *  Copyright 2008 Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.xerxys.xina;

import java.io.File;
import org.xerxys.xina.db.Packages;

/**
 * Installs a software package and its dependencies from an internet
 * repository or from a local file.
 * @author Christian Lins
 */
class Installer implements ModeHandler
{

  private String packageName;
  
  public Installer(String[] args)
  {
    this.packageName = args[2];
  }

  public int run()
  {
    Packages pkgBase = Packages.initiate(new File("/etc/xpkg/db"));
    if(pkgBase == null)
    {
      System.out.println("Cannot access package index.");
      return 1;
    }
    
    // Lock the database
    pkgBase.lock();
    
    // Unlock the database
    pkgBase.unlock();

    return 0;
  }

}
