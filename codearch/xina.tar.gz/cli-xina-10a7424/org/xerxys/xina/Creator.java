/*
 *  Xina
 *  Copyright (C) 2008,2009 Christian Lins <cli@openoffice.org>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package org.xerxys.xina;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.LinkedList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import org.xerxys.xina.xpkg.ControlFile;

/**
 * Handles mode 'create'. Creates a xna package from a given directory.
 * @author Christian Lins
 */
class Creator implements ModeHandler
{

  private File packageRoot = null;

  public Creator(String[] args)
  {
    this.packageRoot = new File(args[1]);
  }

  public int run()
  {
    File controlFile = new File(packageRoot.getAbsolutePath() + "/xpkg/control");
    if(!controlFile.exists())
    {
      System.out.println(controlFile.getPath() + " file does not exist. Abort.");
      return 1;
    }
    
    try
    {
      ControlFile control = ControlFile.load(new FileInputStream(controlFile));
      
      String packageName = control.get("Package");
      if(packageName == null)
      {
        System.out.println("Control file contains no 'Package' entry.");
      }
      
      String version = control.get("Version");
      if(version == null)
      {
        System.out.println("Control file contains no 'Version' entry.");
      }
      else
        System.out.println("Creating package " + packageName + " " + version);
      
      if(!this.packageRoot.exists())
      {
        System.out.println("Package root does not exist.");
      }
      
      String packageFileName = packageName + "_" + version + ".xpkg";
      ZipOutputStream zipout = new ZipOutputStream(
        new FileOutputStream(packageFileName));
      
      zipout.putNextEntry(new ZipEntry("xpkg/control"));
      writeFileToZIP(this.packageRoot.getAbsolutePath() + "/xpkg/control", zipout);
      zipout.closeEntry();
      
      List<String> allFiles = listAllFiles(
        new LinkedList<String>(), new File(this.packageRoot + "/root"));
     
      for(String file : allFiles)
      {
        String entryName = file.substring(this.packageRoot.getAbsolutePath().length() + 1);
        System.out.println("Writing entry " + entryName);
        zipout.putNextEntry(new ZipEntry(entryName));
        writeFileToZIP(file, zipout);
        zipout.closeEntry();
      }
      
      zipout.flush();
      zipout.close();
      System.out.println("Done.");
    }
    catch(IOException ex)
    {
      ex.printStackTrace();
      return 1;
    }
    return 0;
  }
  
  private List<String> listAllFiles(List<String> list, File root)
  {
    File[] files = root.listFiles();
    if(files == null)
      return list;
    
    for(File file : files)
    {
      if(file.isDirectory())
        listAllFiles(list, file);
      else
        list.add(file.getAbsolutePath());
    }
    return list;
  }
  
  private void writeFileToZIP(String file, OutputStream out)
    throws IOException
  {
    InputStream in  = new FileInputStream(file);
    byte[]      buf = new byte[1024];
    
    for(;;)
    {
      int read = in.read(buf);
      if(read < 0)
        break;
      else
        out.write(buf, 0, read);
    }
  }

}
