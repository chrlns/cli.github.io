package me.lins.kosmos;

import javax.microedition.khronos.opengles.GL10;

public interface Drawable {

	void draw(GL10 gl);
}
