package me.lins.kosmos;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;

public class KosmosView extends GLSurfaceView {

	private final float TOUCH_SCALE_FACTOR = 180.0f / 320;
	
	private GLRenderer renderer;
	private float prevX, prevY;
	
	public KosmosView(Context context) {
		super(context);
		
		renderer = new GLRenderer(context);
		setRenderer(renderer);

		// Render the view only when there is a change
		setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent e) {
		// MotionEvent reports input details from the touch screen
		// and other input controls. In this case, you are only
		// interested in events where the touch position changed.

		float x = e.getX();
		float y = e.getY();

		switch (e.getAction()) {
		case MotionEvent.ACTION_MOVE:

			float dx = x - prevX;
			float dy = y - prevY;

			// reverse direction of rotation above the mid-line
		/*	if (y > getHeight() / 2) {
				dx = dx * -1;
			}

			// reverse direction of rotation to left of the mid-line
			if (x < getWidth() / 2) {
				dy = dy * -1;
			}*/

			renderer.angleX += dy * TOUCH_SCALE_FACTOR;
			renderer.angleY += dx * TOUCH_SCALE_FACTOR;
			requestRender();
			break;
		}

		prevX = x;
		prevY = y;
		return true;
    } 
}
