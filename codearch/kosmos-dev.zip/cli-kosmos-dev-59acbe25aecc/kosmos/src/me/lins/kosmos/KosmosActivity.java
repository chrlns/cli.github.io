package me.lins.kosmos;

import android.app.Activity;
import android.gesture.GestureOverlayView;
import android.opengl.GLSurfaceView;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;

public class KosmosActivity extends Activity  {

	private KosmosView kosmosView;

	/**
	 *  Call back when the activity is started, to initialize the view.
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		// Switch to fullscreen
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		getWindow().setFlags(
				WindowManager.LayoutParams.FLAG_FULLSCREEN, 
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		
		kosmosView = new KosmosView(this); 
		this.setContentView(kosmosView);
	}

	/**
	 *  Call back when the activity is going into the background.
	 */
	@Override
	protected void onPause() {
		super.onPause();
		kosmosView.onPause();
	}

	/**
	 *  Call back after onPause().
	 */
	@Override
	protected void onResume() {
		super.onResume();
		kosmosView.onResume();
	}
}