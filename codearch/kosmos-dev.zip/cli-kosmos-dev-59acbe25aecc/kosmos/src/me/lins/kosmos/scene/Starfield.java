package me.lins.kosmos.scene;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.Random;

import javax.microedition.khronos.opengles.GL10;

import me.lins.kosmos.Drawable;

public class Starfield implements Drawable{

	public static final int NUM_STARS = 16536;
	
	private FloatBuffer vertexBuffer;
	
	public Starfield() {
		float[] vertices = new float[NUM_STARS * 3];
		Random rnd = new Random();
		for(int n = 0; n < NUM_STARS * 3; n++) {
			float v = rnd.nextFloat() * 50;
			if(rnd.nextInt(2) == 0) {
				vertices[n] = v;
			} else {
				vertices[n] = -v;
			}
		}
		
		// Setup vertex-array buffer. Vertices in float. An float has 4 bytes
		ByteBuffer vbb = ByteBuffer.allocateDirect(vertices.length * 4);
		vbb.order(ByteOrder.nativeOrder()); // Use native byte order
		vertexBuffer = vbb.asFloatBuffer(); // Convert from byte to float
		vertexBuffer.put(vertices); // Copy data into buffer
		vertexBuffer.position(0);   // Rewind
	}
	
	public void draw(GL10 gl) {
		gl.glEnableClientState(GL10.GL_VERTEX_ARRAY);
		gl.glVertexPointer(3, GL10.GL_FLOAT, 0, vertexBuffer);
		gl.glColor4f(.5f, .5f, .5f, 1);
		
		// Draw points
		gl.glDrawArrays(GL10.GL_POINTS, 0, NUM_STARS);
		
		gl.glDisableClientState(GL10.GL_VERTEX_ARRAY);
	}
}
