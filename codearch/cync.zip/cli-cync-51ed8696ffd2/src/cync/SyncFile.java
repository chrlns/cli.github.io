/*
 *  CYNC Synchronization Tool
 *  Copyright 2008 Christian Lins <christian.lins@web.de>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package cync;

import cync.hash.Base64;
import cync.xml.SyncFileReader;
import cync.xml.SyncFileWriter;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;

/**
 * Represents a .cync-File.
 * @author Christian Lins (christian.lins@web.de)
 */
public class SyncFile
{
  public static int DEFAULT_BLOCK_SIZE = 65536;
  
  public static SyncFile create(File file, MessageDigest hashAlgorithm, int blockSize)
    throws Exception
  {
    List<String> hashes = new ArrayList<String>();
    long readBytes = 0;
   
    InputStream in = new FileInputStream(file);
    String str = "";
    while(readBytes < file.length())
    {
      byte[] buffer = new byte[blockSize];
      java.security.MessageDigest digest = hashAlgorithm;
      readBytes += in.read(buffer);
      digest.update(buffer, 0, buffer.length);
      String hash = cync.hash.MessageDigest.digestString(digest);
      hashes.add(hash);
      
      if(hashes.size() % 25 == 0)
      {
        // Delete last output
        for(int n = 0; n < str.length(); n++)
          System.out.print("\b");
        // New output
        str = (int)(((double)readBytes / file.length()) * 100.0) + "%";
        System.out.print(str);
        System.out.flush();
      }
      
      // Delete last output
      for(int n = 0; n < str.length(); n++)
        System.out.print("\b");
    }
    return new SyncFile(file.length(), file.getName(), 
      hashes, hashAlgorithm.getAlgorithm(), blockSize);
  }
  
  public static SyncFile load(InputStream ins)
    throws Exception
  {
    return new SyncFileReader().read(ins);
  }
  
  public static SyncFile load(String strUrl, String user, String passwd)
    throws IOException, Exception
  {
    URL           url  = new URL(strUrl);
    URLConnection conn = url.openConnection();
    
    conn.addRequestProperty("User-Agent", Main.VERSION);
    conn.addRequestProperty("Accept-Charset", "UTF-8");
    conn.addRequestProperty("Accept-Encoding", "text/plain");
    
    if(user != null && passwd != null)
    {
      conn.addRequestProperty("Authorization", 
                "Basic " + Base64.encodeBytes((user + ":" + passwd).getBytes()));
    }
      
    return SyncFile.load(new BufferedInputStream(conn.getInputStream()));
  }
  
  private int          blockSize = DEFAULT_BLOCK_SIZE;
  private String       fileName  = null;
  private long         fileSize  = -1;
  private String       hashAlgorithm;
  private List<String> hashes;
  
  public SyncFile(long filesize, String fileName, List<String> hashes, 
                  String hashAlgorithm, int blockSize)
  {
    this.blockSize = blockSize;
    this.fileName  = fileName;
    this.fileSize  = filesize;
    this.hashes    = hashes;
    this.hashAlgorithm = hashAlgorithm;
  }
  
  /**
   * Returns a list of block numbers that are missing in
   * the given SyncFile to this sync file.
   * @param obj
   * @return
   */
  public List<Long> diff(SyncFile obj)
  {
    List<Long> diff = new ArrayList<Long>();
    boolean completeNew = false;
    
    if(!new File(obj.getFileName()).exists())
      completeNew = true;
    
    for(int n = 0; n < this.hashes.size(); n++)
    {
      if(completeNew || obj.getHashes().size() < n ||
         (obj.getHashes().size() > n && !obj.getHashes().get(n).equals(hashes.get(n))))
        diff.add((long)n);
    }
    
    return diff;
  }
  
  public boolean equals(SyncFile obj)
  {
    if(obj.getFileSize() != getFileSize())
      return false;
    
    if(obj.getHashes().size() != hashes.size())
      return false;
    
    for(int n = 0; n < hashes.size(); n++)
    {
      if(!obj.getHashes().get(n).equals(hashes.get(n)))
        return false;
    }
    
    return true;
  }
  
  public String getFileName()
  {
    return this.fileName;
  }
  
  public void write(File file)
    throws Exception
  {
    new SyncFileWriter(this).write(new FileOutputStream(file));
  }

  public int getBlockSize()
  {
    return this.blockSize;
  }
  
  public long getFileSize()
  {
    return fileSize;
  }

  public List<String> getHashes()
  {
    return hashes;
  }

  public String getHashAlgorithm()
  {
    return hashAlgorithm;
  }
}
