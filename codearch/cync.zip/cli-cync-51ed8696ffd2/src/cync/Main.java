/*
 *  CYNC Synchronization Tool
 *  Copyright 2008 Christian Lins <christian.lins@web.de>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package cync;

import cync.io.HttpBlockLoader;
import cync.hash.MessageDigest;
import cync.io.BlockLoader;
import cync.io.FileBlockLoader;
import cync.io.FspBlockLoader;
import cync.io.Resource;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Entry point class.
 * @author Christian Lins (christian.lins@sun.com)
 */
public class Main
{
  public static final String ARG_ALGO      = "--algo";
  public static final String ARG_AUTH      = "--auth";
  public static final String ARG_BLOCKSIZE = "--block-size";
  public static final String ARG_VERSION   = "--version";
  public static final String VERSION       = "cync/0.4-beta1";
  
  public static String HashAlgorithm = "MD5";
  
  private static void init()
  {
    java.net.URL.setURLStreamHandlerFactory(new cync.net.fsp.FspHandler());
  }
  
  /**
   * Main entrypoint method.
   * @param args the command line arguments
   */
  public static void main(String[] args)
    throws Exception
  {
    // Sanity check
    if(args.length < 2)
    {
      for(String arg : args)
      {
        if(arg.equals(ARG_VERSION))
        {
          System.out.println(VERSION);
          System.exit(0);
        }
      }
      
      System.out.println("Too few arguments.");
      printArguments();
      System.exit(1);
    }
    
    // Do some initializations
    init();
    
    String mode = args[0];
    int    ret  = 0;
    
    if(mode.equals("create"))
    {
      ret = modeCreate(args);
    }
    else if(mode.equals("verify"))
    {
      ret = modeVerify(args);
    }
    else if(mode.equals("repair"))
    {
      ret = modeRepair(args);
    }
    else
    {
      System.out.println("Unknown command!");
      System.exit(ret);
    }
  }
  
  /**
   * Creates a cync file.
   * @param args
   * @return
   */
  private static int modeCreate(String[] args)
  {
    int blockSize = SyncFile.DEFAULT_BLOCK_SIZE;
    
    for(String arg : args)
    {
      if(arg.startsWith(ARG_BLOCKSIZE))
      {
        try
        {
          String[] bsizeArg = arg.split("=");
          if(bsizeArg[1].endsWith("M") || bsizeArg[1].endsWith("m"))
          {
            blockSize = Integer.parseInt(bsizeArg[1].substring(0, bsizeArg[1].length() - 1));
            blockSize = blockSize * 1024 * 1024;
          }
          else if(bsizeArg[1].endsWith("K") || bsizeArg[1].endsWith("k"))
          {
            blockSize = Integer.parseInt(bsizeArg[1].substring(0, bsizeArg[1].length() - 1));
            blockSize = blockSize * 1024;
          }
          else
            blockSize = Integer.parseInt(bsizeArg[1]);
          
          System.out.println("Using blocksize of " + blockSize + " bytes.");
        }
        catch(Exception ex)
        {
          System.err.println("Wrong parameter syntax (" + ex.getMessage() + "): " + arg);
          return 3;
        }
      }
    }
    
    String inputFile = args[1];
    try
    {
      System.out.println("Creating .cync file... ");
      
      SyncFile sync = SyncFile.create(
        new File(inputFile), MessageDigest.getInstance(HashAlgorithm), blockSize);
      sync.write(new File(inputFile + ".cync"));
      
      System.out.println("Done.");
      return 0;
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
      return 2;
    }
  }
  
  private static int modeVerify(String[] args)
  {
    if(args.length < 3)
    {
      System.out.println("Too few arguments.");
      printArguments();
      return 1;
    }
    
    String inputFile = args[1];
    String inputHash = args[2];
    
    try
    {
      System.out.println("Verifing file " + inputFile + "...");
      SyncFile syncHash = SyncFile.load(new FileInputStream(inputHash));
      SyncFile syncFile = SyncFile.create(
        new File(inputFile), MessageDigest.getInstance(HashAlgorithm), syncHash.getBlockSize());

      if(syncFile.equals(syncHash))
      {
        System.out.println("File is valid agains hash file.");
        return 0;
      }
      else
      {
        System.out.println("File is NOT valid agains hash file!");
        List<Long> diff = syncHash.diff(syncFile);
        for(Long l : diff)
          System.out.println("Block #" + l + " is not equal!");
        return 255;
      }
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
      return 2;
    }
  }
  
  private static int modeRepair(String[] args)
  {
    if(args.length < 4)
    {
      System.out.println("Too few arguments.");
      printArguments();
      return 1;
    }
    
    String inputFile  = args[1];
    String inputHash  = args[2];
    String healSource = args[3];
    String authUser  = null;
    String authPass  = null;
    
    System.out.println("Repairing " + inputFile + "... ");
    
    Map<String, String> options = parseOptions(3, args);
    if(options.containsKey(ARG_AUTH))
    {
      authUser = options.get(ARG_AUTH).split(":")[0];
      authPass = options.get(ARG_AUTH).split(":")[1];
    }
    
    try
    {
      SyncFile syncHash = SyncFile.load(new FileInputStream(inputHash));
      SyncFile syncFile = SyncFile.create(
        new File(inputFile), MessageDigest.getInstance(HashAlgorithm), syncHash.getBlockSize());

      shrinkFile(new File(inputFile), syncHash.getFileSize());
      repairFile(syncHash, syncFile, authUser, authPass, healSource, inputFile);
      
      System.out.println("Done.");
      
      return 0;
    }
    catch(Exception ex)
    {
      ex.printStackTrace();
      return 2;
    }
  }
  
  private static Map<String, String> parseOptions(int start, String[] args)
  {
    Map<String, String> options = new HashMap<String, String>();
    
    for(int n = start; n < args.length; n++)
    {
      String[] arg = args[n].split("=");
      if(arg.length > 1)
        options.put(arg[0], arg[1]);
    }
    
    return options;
  }
  
  public static void printArguments()
  {
    String argHelp = Resource.getAsString("cync/resource/usage", true);
    System.out.println(argHelp);
  }
  
  private static void repairFile(SyncFile syncHash, SyncFile syncFile, 
          String authUser, String authPass, String healSource, String inputFile)
    throws InterruptedException, IOException
  {
    List<Long>  diff = syncHash.diff(syncFile);
    BlockLoader blockLoader;
    
    if(new File(healSource).exists())
      blockLoader = new FileBlockLoader(healSource);
    else if(healSource.startsWith("http://") || healSource.startsWith("https://"))
      blockLoader = new HttpBlockLoader(new URL(healSource), authUser, authPass);
    else if(healSource.startsWith("fsp://"))
      blockLoader = new FspBlockLoader(new URL(healSource));
    else
    {
      System.out.println("Protocol of heal source not recognized: " + healSource);
      System.exit(2);
      return;
    }
    
    RandomAccessFile file = new RandomAccessFile(new File(inputFile), "rw");

    for (int n = 0; n < diff.size(); n++)
    {
      long l      = diff.get(n);
      int  length = SyncFile.DEFAULT_BLOCK_SIZE;
      
      if (syncHash.getFileSize() < (l + 1) * SyncFile.DEFAULT_BLOCK_SIZE)
      {
        length = (int) (syncHash.getFileSize() % SyncFile.DEFAULT_BLOCK_SIZE);
      }

      System.out.print("Loading block #" + l + "... ");
      
      byte[] block = blockLoader.getBlock(l * SyncFile.DEFAULT_BLOCK_SIZE, length);
      if(block != null)
      {
        System.out.println("OK");
        file.seek(l * SyncFile.DEFAULT_BLOCK_SIZE);
        file.write(block, 0, length);
      }
      else
      {
        System.out.println("Failed. Retry in a few seconds...");
        Thread.sleep(5);
        n--;
      }
    }

    file.close();
  }
  
  private static void shrinkFile(File file, long toShrink)
    throws IOException
  {
    if(file.length() > toShrink)
    {
      System.out.println("Shrinking size...");
      
      FileOutputStream out = new FileOutputStream(file.getName() + ".tmp");
      FileInputStream  in  = new FileInputStream(file);
      
      byte[] buffer = new byte[4096];
      while(toShrink > 0)
      {
        int read = (int)(toShrink > 4096 ? 4096 : toShrink);
        read = in.read(buffer, 0, read);
        toShrink -= read;
        out.write(buffer, 0, read);
      }
      
      in.close();
      out.flush();
      out.close();
      
      file.delete();
      new File(file.getName() + ".tmp").renameTo(file);
    }
  }
}
