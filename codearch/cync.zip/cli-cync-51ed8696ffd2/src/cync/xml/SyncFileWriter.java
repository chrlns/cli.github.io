/*
 *  CYNC Synchronization Tool
 *  Copyright 2008 Christian Lins <christian.lins@web.de>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package cync.xml;

import cync.SyncFile;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;

/**
 * Writes a SyncFile to XML.
 * @author Christian Lins (christian.lins@sun.com)
 */
public class SyncFileWriter 
{
  private SyncFile syncFile = null;
  
  public SyncFileWriter(SyncFile syncFile)
  {
    this.syncFile = syncFile;
  }
  
  public void write(OutputStream outStream)
    throws IOException, UnsupportedEncodingException
  {
    PrintWriter out = new PrintWriter(new OutputStreamWriter(outStream, "UTF-8"));
    
    out.println("<?xml version=\"1.0\" encoding=\"utf-8\"?>");
    out.println("<cync version=\"1.0\">");
    
    // Write file info
    String fileName = this.syncFile.getFileName();
    long   fileSize = this.syncFile.getFileSize();
    out.print("<file name=\"");
    out.print(fileName);
    out.print("\" length=\"");
    out.print(fileSize);
    out.println("\"/>");
    
    // Write hashes
    out.print("<blocks size=\"");
    out.print(this.syncFile.getBlockSize());
    out.print("\" count=\"");
    out.print(this.syncFile.getHashes().size());
    out.print("\" hash-algorithm=\"");
    out.print(this.syncFile.getHashAlgorithm());
    out.println("\">");
    
    // Write a tag for every block hash
    for(String hash : this.syncFile.getHashes())
    {
      out.print("<block hash=\"");
      out.print(hash);
      out.println("\"/>");
    }
    
    out.println("</blocks>");
    
    out.println("</cync>");    
    out.flush();
    out.close();
  }
}
