/*
 *  CYNC Synchronization Tool
 *  Copyright 2008 Christian Lins <christian.lins@web.de>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package cync.xml;

import cync.Main;
import cync.SyncFile;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * Reads a .cync XML file to a cync.SyncFile object.
 * @author Christian Lins (christian.lins@sun.com)
 */
public class SyncFileReader extends DefaultHandler
{
  private int          blockSize     = SyncFile.DEFAULT_BLOCK_SIZE;
  private String       fileName      = null;
  private long         fileSize      = -1;
  private String       hashAlgorithm = Main.HashAlgorithm;
  private List<String> hashes        = new ArrayList<String>();
  
  @Override
  public void characters(char[] ch, int start, int length) 
  {
  }
  
  @Override
  public void endElement(String uri, String localName, String qName) 
  {
  }
  
  public SyncFile read(InputStream in)
    throws ParserConfigurationException, SAXException, IOException
  {    
    SAXParser parser = SAXParserFactory.newInstance().newSAXParser();
    
    parser.parse(new InputSource(new InputStreamReader(in, "UTF-8")), this);
    
    return new SyncFile(fileSize, fileName, hashes, hashAlgorithm, blockSize);
  }
  
  @Override
  public void startElement(String uri, String localName, String qName, Attributes attributes)
  {
    if(qName.equals("file"))
    {
      this.fileName = attributes.getValue("name");
      this.fileSize = Long.parseLong(attributes.getValue("length"));
    }
    else if(qName.equals("blocks"))
    {
      String size = attributes.getValue("size");
      if(size != null)
        this.blockSize = Integer.parseInt(size);
      
      String hashAlgo = attributes.getValue("hash-algorithm");
      if(hashAlgo != null)
        this.hashAlgorithm = hashAlgo;
    }
    else if(qName.equals("block"))
    {
      String hash = attributes.getValue("hash");
      this.hashes.add(hash);
    }
  }
}