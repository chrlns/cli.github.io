/*
 *  CYNC Synchronization Tool
 *  Copyright 2008 Christian Lins <christian.lins@web.de>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package cync.hash;

import java.math.BigInteger;
import java.security.NoSuchAlgorithmException;


public abstract class MessageDigest extends java.security.MessageDigest 
{
  protected MessageDigest(String name)
  {
    super(name);
  }
  
  public static java.security.MessageDigest getInstance(String name)
  {
    try
    {
      if(name.equalsIgnoreCase("Whirlpool"))
      {
        return new Whirlpool2003();
      }
      else
      {
        /* MD2, MD5, SHA-1, SHA-256, SHA-384, SHA-512 */
        return java.security.MessageDigest.getInstance(name);
      }
    }
    catch(NoSuchAlgorithmException ex)
    {
      System.err.println(ex.getLocalizedMessage());
      return null;
    }
  }
  
   public static String digestString(java.security.MessageDigest md)
   {
     StringBuilder builder = new StringBuilder();
     
     byte[] digest = md.digest();
     for(byte b : digest)
       builder.append(Integer.toHexString(b + 128));
     
     return new BigInteger(builder.toString(), 16).toString(36);
   }
}
