/*
 *  CYNC Synchronization Tool
 *  Copyright 2008 Christian Lins <christian.lins@web.de>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package cync.io;

import cync.*;
import cync.hash.Base64;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;

/**
 * Loads byte block via HTTP protocol.
 * @author Christian Lins (christian.lins@sun.com)
 */
public class HttpBlockLoader implements BlockLoader
{
  private String authPass = null;
  private String authUser = null;
  private URL    url      = null;
  
  public HttpBlockLoader(URL url)
  {
    this.url = url;
  }
  
  public HttpBlockLoader(URL url, String user, String password)
  {
    this(url);
    
    this.authPass = password;
    this.authUser = user;
  }
  
  public byte[] getBlock(long offset, int length)
  {
    byte[] buffer = new byte[length];
    
    try
    {
      URLConnection conn = url.openConnection();

      // Add custom HTTP properties
      conn.addRequestProperty("User-Agent", Main.VERSION);
      conn.addRequestProperty("Range", "bytes=" + offset + "-" + offset + length);
      if(authUser != null && authPass != null)
      {
        conn.addRequestProperty("Authorization", 
                "Basic " + Base64.encodeBytes((authUser + ":" + authPass).getBytes()));
      }

      InputStream in = conn.getInputStream();

      int read = 0;

      while(read < length)
        read += in.read(buffer, read, length - read);
    }
    catch(Exception ex)
    {
      System.out.println(ex.getMessage());
      return null;
    }
    
    return buffer;
  }
}
