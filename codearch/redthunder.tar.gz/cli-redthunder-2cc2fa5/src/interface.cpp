/*
 *  Red Thunder
 *  Copyright (C) 2009 Christian Lins <cli@openoffice.org>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "interface.hpp"

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <iostream>

Interface::Interface()
{
  SDL_ShowCursor(SDL_DISABLE);
  this->cursor = IMG_Load("data/cursor_default.png");
  if(this->cursor == NULL)
  {
    std::cerr << "Could not load cursor!" << std::endl;
  }
  
  // Set color key of image
  if(SDL_SetColorKey(this->cursor, SDL_SRCCOLORKEY, 
    SDL_MapRGB(SDL_GetVideoSurface()->format, 0xFF, 0, 0xFF)) < 0)
  {
    std::cerr << "Error setting color key!" << std::endl;
  }
  SDL_SetAlpha(this->cursor, 0, SDL_ALPHA_TRANSPARENT);
}

Interface::~Interface()
{
  SDL_ShowCursor(SDL_ENABLE);
}

void Interface::draw(SDL_Surface* surface)
{
  SDL_Rect dstRect = {this->cursorPosX, this->cursorPosY, 32, 32};
  SDL_BlitSurface(this->cursor, NULL, surface, &dstRect);
}

void Interface::processKeyboardEvent(SDL_KeyboardEvent* event)
{
}

void Interface::processMouseButtonEvent(SDL_MouseButtonEvent* event)
{

}

void Interface::processMouseMotionEvent(SDL_MouseMotionEvent* event)
{
  this->cursorPosX = event->x;
  this->cursorPosY = event->y;
}
