/*
 *  Red Thunder
 *  Copyright (C) 2009 Christian Lins <cli@openoffice.org>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _FLOOR_HPP_
#define _FLOOR_HPP_

#include "tile.hpp"

#include <SDL/SDL.h>
#include <string>

/**
 * A floor is a huge set of image tiles. One tile has the shape of a diamond
 * with width / height = 1.97 ~= 2.0.
 * The tiles are horizontally placed next to each other so that the left and
 * right end of a tile touch the end of another tile.
 * The rows of tiles are placed one after another with an offset of +-(width/2)
 * in x-direction and -(height/2) in y-direction.
 * Of course we cannot store a diamond shaped tile, so we use transparent 
 * (color key) rectangular images containing the diamonds (bounding box).
 * Technically this is not absolutely necessary but the diamond tile based
 * structure supports the isometric view of the floor.
 */
class Floor
{
  private:
    unsigned short cols, rows;
    Tile*** tiles;

  public:
    Floor(std::string filename);
    virtual ~Floor();

    void draw(SDL_Surface* surface, int x, int y, int width, int height);
};

#endif
