/*
 *  Red Thunder
 *  Copyright (C) 2009 Christian Lins <cli@openoffice.org>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "tile.hpp"

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <iostream>
#include <string>

Tile::Tile(std::string filename)
{
  this->image = IMG_Load(filename.c_str());
  if(this->image == NULL)
  {
    std::cerr << "Could not load image " << filename << std::endl;
  }
  
  // Set color key of image
  if(SDL_SetColorKey(this->image, SDL_SRCCOLORKEY, 
    SDL_MapRGB(SDL_GetVideoSurface()->format, 0xFF, 0, 0xFF)) < 0)
  {
    std::cerr << "Error setting color key!" << std::endl;
  }
  SDL_SetAlpha(this->image, 0, SDL_ALPHA_TRANSPARENT);
}

void Tile::draw(SDL_Surface* surface, int x, int y)
{
  SDL_Rect dstRect = {x, y, TILE_WIDTH, TILE_HEIGHT};
  SDL_BlitSurface(this->image, NULL, surface, &dstRect);
}
