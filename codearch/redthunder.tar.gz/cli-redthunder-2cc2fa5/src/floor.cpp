/*
 *  Red Thunder
 *  Copyright (C) 2009 Christian Lins <cli@openoffice.org>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include "floor.hpp"
#include "tile.hpp"

#include <fstream>
#include <iostream>
#include <SDL/SDL.h>
#include <string>

/**
 * Loads and initializes a floor from a file.
 */
Floor::Floor(std::string filename)
{
  std::ifstream in(filename.c_str(), std::ios::binary);
  
  // Reading number of rows and colums from floor map
  // TODO: Do this in a portable way!
  in.read((char*)&cols, 2);
  in.read((char*)&rows, 2);
  
  // Create tiles
  this->tiles = new Tile**[cols];
  for(int c = 0; c < cols; c++)
  {
    this->tiles[c] = new Tile*[rows];
    for(int r = 0; r < rows; r++)
    {
      this->tiles[c][r] = new Tile("data/tile.png");
    }
  }
  
  in.close();
}

Floor::~Floor()
{
}

/**
 * Draws the tile based floor.
 */
void Floor::draw(SDL_Surface* surface, int x, int y, int width, int height)
{
  for(int c = 0; c < cols; c++)
  {
    for(int r = 0; r < rows; r++)
    {
      this->tiles[c][r]->draw(surface, 
        x + c * TILE_WIDTH + (TILE_WIDTH / 2 * (r % 2)), 
        y + r * TILE_HEIGHT / 2);
    }
  }
}
