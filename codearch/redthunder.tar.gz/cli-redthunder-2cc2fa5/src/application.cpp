/*
 *  Red Thunder
 *  Copyright (C) 2009 Christian Lins <cli@openoffice.org>
 *
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#include <SDL/SDL.h>
#include <iostream>

#include "application.hpp"
#include "floor.hpp"

Application::Application()
{
  if(SDL_Init(SDL_INIT_VIDEO) < 0)
  {
    std::cerr << "Could not init SDL video subsystem!" << std::endl;
  }
  
  int flags = SDL_HWSURFACE | SDL_DOUBLEBUF;
  this->surface = SDL_SetVideoMode(640, 480, 24, flags);
  if(this->surface == NULL)
  {
    std::cerr << "Could not setup SDL video mode!" << std::endl;
  }
  
  SDL_WM_SetCaption("Red Thunder", NULL);
  
  this->floor     = new Floor("data/sample.floor");
  this->interface = new Interface();
}

Application::~Application()
{
  SDL_Quit();
  delete this->floor;
  delete this->interface;
}

int Application::run()
{
  SDL_Event event;
  
  int offX = 0;
  int offY = 0;
  
  for(;;)
  {
    // Process all SDL events
    while(SDL_PollEvent(&event))
    {
      switch(event.type)
      {
        case SDL_KEYDOWN:
        {
          if(event.key.keysym.sym == SDLK_LEFT)
          {
            offX += 5;
          }
          else if(event.key.keysym.sym == SDLK_RIGHT)
          {
            offX -= 5;
          }
          else if(event.key.keysym.sym == SDLK_UP)
          {
            offY += 5;
          }
          else if(event.key.keysym.sym == SDLK_DOWN)
          {
            offY -= 5;
          }
          else
          {
            this->interface->processKeyboardEvent((SDL_KeyboardEvent*)&event);
          }
          break;
        }
        case SDL_KEYUP:
        {
          this->interface->processKeyboardEvent((SDL_KeyboardEvent*)&event);
          break;
        }
        case SDL_MOUSEMOTION:
        {
          this->interface->processMouseMotionEvent((SDL_MouseMotionEvent*)&event);
          break;
        }
        case SDL_MOUSEBUTTONDOWN:
        {
          this->interface->processMouseButtonEvent((SDL_MouseButtonEvent*)&event);
          break;
        }
        case SDL_QUIT:
        {
          std::cout << "SDL_QUIT received. Exiting..." << std::endl;
          return 0;
        }
      }
    }
    
    // Clear screen and redraw everything...
    SDL_FillRect(this->surface, NULL, 0);

    // ..Floor
    this->floor->draw(this->surface, offX, offY, 640, 480);
    
    // ..GUI
    this->interface->draw(this->surface);
    
    // and finally swap the buffers and show the rendered image on screen
    SDL_Flip(this->surface);
  }
  
  return 0;
}
