
function Player()
{
	Player.intervalID	= setInterval(nextSprite, 200);
	
	function nextSprite()
	{
	}
}
