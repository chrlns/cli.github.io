function Game(dropzone)
{
	Game.dropzone = dropzone;
	Game.context = dropzone.getContext('2d');
	
	function draw()
	{
	}
}