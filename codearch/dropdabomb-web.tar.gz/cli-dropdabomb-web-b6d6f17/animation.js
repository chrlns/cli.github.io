function Image()
{
	function getImage()
	{
	}
}

function Animation(images)
{
	Animation.images		= images;
	Animation.intervalID	= setInterval(nextSprite, 1000);
	
	function nextSprite()
	{
		
	}
	
	function getImage()
	{
		return images;
	}
}
