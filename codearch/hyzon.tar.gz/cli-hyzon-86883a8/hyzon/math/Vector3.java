package hyzon.math;

import java.awt.Color;
import java.util.Comparator;

/**
 * Three-dimensional vector class. This class uses float primitives types. Generic classes using
 * primitive types is not possible with Java.
 * @author Christian Lins
 * @param <float>
 */
public class Vector3
{
  public static class VerticalComparator implements Comparator<Vector3>
  {
    public int compare(Vector3 a, Vector3 b)
    {
      if(a.getY() == b.getY())
        return 0;
      else if(a.getY() < b.getY())
        return -1;
      else
        return 1;
    }
    
    public boolean equals(Object obj)
    {
      return super.equals(obj);
    }
  }
  
  private Color color    = Color.WHITE;
  private float x, y, z, u, v;
  
  public Vector3()
  {
    setX(0);
    setY(0);
    setZ(0);
  }
  
  /**
   * Constructs a vector using the x,y,z-Position and the texure
   * coordinates u,v. A uv coordinate (0,0) means lower left corner
   * and (1,1) upper right.
   * @param x
   * @param y
   * @param z
   * @param u
   * @param v
   */
  public Vector3(float x, float y, float z, float u, float v)
  {
    this.x = x;
    this.y = y;
    this.z = z;
    this.u = u;
    this.v = v;
  }
  
  public Vector3(float x, float y, float z)
  {
    this(x, y, z, 0, 0);
  }
  
  public Vector3(Vector3 v)
  {
    this.x     = v.x;
    this.y     = v.y;
    this.z     = v.z;
    this.u     = v.u;
    this.v     = v.v;
    this.color = v.color;
  }
  
  public void setColor(Color color)
  {
    this.color = color;
  }
  
  public void setX(float x)
  {
    this.x = x;
  }
  
  public void setY(float y)
  {
    this.y = y;
  }
  
  public void setZ(float z)
  {
    this.z = z;
  }
  
  public float getX()
  {
    return this.x;
  }
  
  public float getY()
  {
    return this.y;
  }
  
  public float getZ()
  {
    return this.z;
  }
  
  public float getU()
  {
    return this.u;
  }
  
  public float getV()
  {
    return this.v;
  }
  
  public int x()
  {
    return (int)this.x;
  }
  
  public int y()
  {
    return (int)this.y;
  }
  
  public int z()
  {
    return (int)this.z;
  }
  
  
  //////////////////////////////////////
  // Arithmetic methods
  //////////////////////////////////////
  
  public Vector3 add(Vector3 v)
  {
    return new Vector3(x + v.x, y + v.y, z + v.z , u + v.u, this.v + v.v);
  }
  
  public Vector3 substract(Vector3 v)
  {
    return new Vector3(getX() - v.getX(), getY() - v.getY(), getZ() - v.getZ(), getU() - v.getU(), getV() - v.getV());
  }
  
  public Vector3 multiply(float s)
  {
    return new Vector3(getX() * s, getY() * s, getZ() * s, getU(), getV());
  }
  
  public Vector3 multiply(Vector3 v)
  {
    Vector3 vn = new Vector3();
    vn.setX(getX() * v.getX());
    vn.setY(getY() * v.getY());
    vn.setZ(getZ() * v.getZ());
    vn.u *= v.u;
    vn.v *= v.v;
    vn.setColor(vn.color);
    
    return vn;
  }
  
  public Vector3 multiply(Matrix4x4 matrix)
  {
    float x, y, z;
    
    x = matrix.getValues()[0][0] * getX()
        + matrix.getValues()[0][1] * getY()
        + matrix.getValues()[0][2] * getZ();
    
    y = matrix.getValues()[1][0] * getX()
        + matrix.getValues()[1][1] * getY()
        + matrix.getValues()[1][2] * getZ();
    
    z = matrix.getValues()[2][0] * getX()
        + matrix.getValues()[2][1] * getY()
        + matrix.getValues()[2][2] * getZ();
    
    return new Vector3(x, y, z, u, v);
  }
  
  /**
  * Returns the length of this vector. Simply calculated using Pythagora's theorem.
  */
  public float length()
  {
    return (float)Math.sqrt(x * x + y * y + z * z); // TODO: Implement faster Sqrt
  }
  
  /**
  * Returns the dot product between this vector and the given parameter. 
  * floathe results is the cosinus of the angle between those two vectors.
  */
  public float dotproduct(Vector3 v)
  {
    return x * v.getX() + y * v.getY() + z * v.getZ();
  }
  
  public Vector3 crossproduct(Vector3 v)
  {
    Vector3 vn = new Vector3();
    vn.setX(y * v.getZ() - z * v.getY());
    vn.setY(z * v.getX() - x * v.getZ());
    vn.setZ(x * v.getY() - y * v.getX());
    
    return vn;
  }
  
  public Vector3 opposition()
  {
    return new Vector3(-x, -y, -z);
  }
   
  public Color getColor()
  {
    return this.color;
  }
  
  @Override
  public String toString()
  {
    StringBuffer buf = new StringBuffer();
    buf.append(super.toString());
    buf.append(": ");
    buf.append(x);
    buf.append(' ');
    buf.append(y);
    buf.append(' ');
    buf.append(z);
    
    return buf.toString();
  }
}
