package hyzon.math;

/**
 * Represents a quadratic two-dimensional matrix.
 * @author Christian Lins
 */
public class Matrix3x3
{
  private float[][] v;
  
  public Matrix3x3(float[][] v)
  {
    this.v = v;
  }
  
  /**
   * Returns the determinant of this matrix.
   * @return
   */
  public float determinant()
  {
    float d = 0;
    
    d += v[0][0] * v[1][1] * v[2][2] +
         v[1][0] * v[2][1] * v[0][2] +
         v[2][0] * v[0][1] * v[1][2];
    d -= v[2][0] * v[1][1] * v[0][2] -
         v[1][0] * v[0][1] * v[2][2] -
         v[0][0] * v[2][1] * v[1][2];
    
    return d;
  }
}
