package hyzon.math;

public class Vector2
{

}
