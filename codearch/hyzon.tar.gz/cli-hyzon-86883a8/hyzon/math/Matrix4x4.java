package hyzon.math;


import java.util.*;

/**
 * @author Christian Lins
 */
public class Matrix4x4
{
  private float[][] v = new float[4][4];
  
  public Matrix4x4()
  {
  }
  
  public Matrix4x4(float f0, float f1, float f2, float f3, float f4, float f5, float f6, float f7, float f8,
      float f9, float f10, float f11, float f12, float f13, float f14, float f15)
  {
    v[0][0] = f0;
    v[1][0] = f1;
    v[2][0] = f2;
    v[3][0] = f3;
    v[0][1] = f4;
    v[1][1] = f5;
    v[2][1] = f6;
    v[3][1] = f7;
    v[0][2] = f8;
    v[1][2] = f9;
    v[2][2] = f10;
    v[3][2] = f11;
    v[0][3] = f12;
    v[1][3] = f13;
    v[2][3] = f14;
    v[3][3] = f15;
  }
  
  public Matrix4x4(float[][] values)
  {
    this.v = values;
  }
  
  public Matrix4x4 multiply(Matrix4x4 matrix)
  {
    float[][] a = this.getValues();
    float[][] b = matrix.getValues();
    float[][] v = new float[4][4];
    
    for(int i = 0; i < 4; i++)
    {
      for(int j = 0; j < 4; j++)
      {
        v[i][j] = a[i][0] * b[0][j] + a[i][1] * b[1][j] + a[i][2] * b[2][j] + a[i][3] * b[3][j];
      }
    }
    
    return new Matrix4x4(v);
  }
  
  public Vector4 multiply(Vector4 m)
  {
    float v0 = v[0][0] * m.getValues()[0] + v[0][1] * m.getValues()[1] + v[0][2] * m.getValues()[2] + v[0][3] * m.getValues()[3];
    float v1 = v[1][0] * m.getValues()[0] + v[1][1] * m.getValues()[1] + v[1][2] * m.getValues()[2] + v[1][3] * m.getValues()[3];
    float v2 = v[2][0] * m.getValues()[0] + v[2][1] * m.getValues()[1] + v[2][2] * m.getValues()[2] + v[2][3] * m.getValues()[3];
    float v3 = v[3][0] * m.getValues()[0] + v[3][1] * m.getValues()[1] + v[3][2] * m.getValues()[2] + v[3][3] * m.getValues()[3];
    
    return new Vector4(v0, v1, v2, v3);
  }
  
  /**
   * Returns the invertible Matrix of this Matrix.
   * @return
   */
  public Matrix4x4 getInvertible()
  {
    float[][] inv = new float[4][4];
    
    
    
    return new Matrix4x4(inv);
  }
  
  public float[][] getValues()
  {
    return v;
  }
  
  public String toString()
  {
    return "[" 
    + Arrays.toString(v[0])
    + Arrays.toString(v[1])
    + Arrays.toString(v[2])
    + Arrays.toString(v[3]) + "]";
  }
}
