package hyzon.math;

public class Vector4
{
  private float[] v = new float[4];
  
  public Vector4(float v1, float v2, float v3, float v4)
  {
    v[0] = v1;
    v[1] = v2;
    v[2] = v3;
    v[3] = v4;
  }
  
  public float[] getValues()
  {
    return this.v;
  }
}
