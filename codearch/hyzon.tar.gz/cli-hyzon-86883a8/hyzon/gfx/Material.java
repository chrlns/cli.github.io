/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hyzon.gfx;

/**
 *
 * @author chris
 */
public class Material 
{
  public void setTexture(int idx, com.sun.opengl.util.texture.Texture tex)
  {
    
  }
}
