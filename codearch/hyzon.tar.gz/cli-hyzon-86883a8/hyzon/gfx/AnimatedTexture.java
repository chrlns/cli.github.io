package hyzon.gfx;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;

public class AnimatedTexture
  implements ActionListener
{
  private int       currentIndex    = 0;
  private Texture[] textures        = null;
  private Timer     timer           = null;
  
  /**
   * @param textures
   * @param switchIntervall Time in milliseconds to switch to the next picture.
   */
  public AnimatedTexture(Texture[] textures, int delay)
  {
    this.textures        = textures;
    this.timer    = new Timer(delay, this);
    this.timer.start();
  }
  
  public void actionPerformed(ActionEvent e)
  {
    if(currentIndex >= textures.length)
      currentIndex = 0;
    else
      currentIndex++;
  }
  
  public void setDelay(int delay)
  {
    this.timer.setDelay(delay);
  }
}
