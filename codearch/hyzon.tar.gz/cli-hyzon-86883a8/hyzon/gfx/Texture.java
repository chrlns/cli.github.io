package hyzon.gfx;

import java.awt.image.*;
import java.io.*;

public class Texture
{
  public static Texture DefaultTexture;
  
  static
  {
    try
    {
      DefaultTexture = new Texture("test.bmp");
    }
    catch(IOException e)
    {
      System.err.println(e.getMessage());
    }
  }
  
  private Bitmap data;
  
  public Texture(String file)
    throws IOException
  {
    File f = new File(file);
    if(!f.exists())
      throw new IOException(file + " cannot be found!");
    
    this.data = new Bitmap(f);
  }
  
  /**
   * Returns the non-interpolated (point sampling) value at the 
   * given texture coordinate.
   * @param x
   * @param y
   * @return
   */
  public int getRGB(float x, float y)
  {
    return this.data.get(x, y).getRGB();
  }
  
  /**
   * Returns the isotropic bilinear filtered texel. 
   * Bilinear filtering uses four nearby texels to cumulate and weight them 
   * to interpolate a nearly correct texel. This method uses a lot of cpu 
   * time in comparison to point sampled textures but the picture quality
   * increases enourmously.
   * @param x
   * @param y
   * @return The bilinear interpolated pixel.
   */
  public int getFilteredRGB(float x, float y)
  {
    x *= data.getWidth();
    y *= data.getHeight();
    
    int xm = (int)Math.ceil(x);
    int ym = (int)Math.ceil(y);

    float xp1 = 0.5f ; //+ (xm - x);
    float xm1 = 0.5f ; //- (xm - 1 - x);
    float yp1 = 0.5f ; //+ (ym - y);
    float ym1 = 0.5f ; //- (ym - 1 - y);        

    int red = data.get(xm, ym).getRed() + (int)
                ((data.get(xm+1, ym).getRed() * xp1)
              + (data.get(xm-1, ym).getRed()  * xm1)
              + (data.get(xm, ym+1).getRed()  * yp1)
              + (data.get(xm, ym-1).getRed()  * ym1));
    red = (red / 3) & 0x000000FF;  // Clamp color

    int green = data.get(xm, ym).getGreen() + (int)
                ((data.get(xm+1, ym).getGreen() * xp1)
              + (data.get(xm-1, ym).getGreen()  * xm1)
              + (data.get(xm, ym+1).getGreen()  * yp1)
              + (data.get(xm, ym-1).getGreen()  * xm1));
    green = (green / 3) & 0x000000FF; 

    int blue = data.get(xm, ym).getBlue() + (int)
                ((data.get(xm+1, ym).getBlue() * xp1)
              + (data.get(xm-1, ym).getBlue()  * xm1)
              + (data.get(xm, ym+1).getBlue()  * yp1)
              + (data.get(xm, ym-1).getBlue()  * xm1));
    blue = (blue / 3) & 0x000000FF;

    return new java.awt.Color(red, green, blue).getRGB(); 
  }
  
  /**
   * Returns the anisotropic bilinear filtered texel.
   * @param x
   * @param y
   * @param z
   * @return
   */
  public int getFilteredRGB(float x, float y, int sampledepth, hyzon.ZBuffer z)
  {
    return 0;
  }
  
  public BufferedImage getImage()
  {
    return this.data.getImage();
  }
}
