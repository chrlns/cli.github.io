/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hyzon;

import javax.media.opengl.GLCanvas;

/**
 *
 * @author Christian Lins (christian.lins@web.de)
 */
public class HyzonComponent 
  extends GLCanvas
{

}
