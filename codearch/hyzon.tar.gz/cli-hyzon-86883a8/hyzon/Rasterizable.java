package hyzon;

import java.awt.image.BufferedImage;

public interface Rasterizable
{
  void rasterize(BufferedImage image, ZBuffer zbuffer);
}
