package hyzon;

import java.nio.IntBuffer;

/**
 * Actually this ZBuffer is more a WBuffer, but the functionality is similar.
 * This WBuffer stores the nearest Z-Value (not range 0.0 to 1.0 as a "real" ZBuffer does)
 * to prevent overdraw.
 * @author Christian Lins (christian.lins@web.de)
 */
public class ZBuffer
{
  private static int   N      = 1 << 31;
  private static int[] FILLER = new int[128];
  
  static
  {
    for(int n = 0; n < FILLER.length; n++)
      FILLER[n] = 0;
  }
  
  private IntBuffer   buffer;
  private int         width;
  private double      a, b;
  
  public ZBuffer(int width, int height, double zNear, double zFar)
  {
    buffer = IntBuffer.allocate(width * height + FILLER.length);
    clear();
    
    this.width  = width;
    this.a      = zFar / (zFar - zNear);
    this.b      = zFar * zNear / (zNear - zFar);
  }
  
  public ZBuffer(int width, int height)
  {
    this(width, height, 0.1, Float.MAX_VALUE);
  }
  
  /**
   * Clears this zbuffer.
   */
  public void clear()
  {
    buffer.clear();
    for(int n = 0; n < buffer.capacity() - FILLER.length; n += FILLER.length)
      buffer.put(FILLER, 0, FILLER.length);
  }
  
  /**
   * If you want to read out the raw zbuffer use this method, 
   * use testVisibility() in the rendering loop instead.
   * @param x
   * @param y
   * @param value
   */
  public void set(int x, int y, double value)
  {
    int zValue = (int)(N * (a + b / value));
    buffer.put(x * width + y, zValue);
  }
  
  public double get(int x, int y)
  {
    try
    {
      int val = buffer.get(x * width + y);

      return b * N / (val - a * N);
    }
    catch(IndexOutOfBoundsException ex)
    {
      System.err.println("Error coordinates: " + x + " " + y);
      throw ex;
    }
  }
  
  /**
   * Returns true if the given pixel is closer to viewpoint and should be
   * drawn. In this case the new value is written to this ZBuffer.
   * @param x
   * @param y
   * @param value
   * @return
   */
  public boolean testVisibility(int x, int y, double value)
  {
    synchronized(this.buffer)
    {
      if(get(x, y) >= value)
        return false;
      else
      {
        set(x, y, value);
        return true;
      }
    }
  }
}
