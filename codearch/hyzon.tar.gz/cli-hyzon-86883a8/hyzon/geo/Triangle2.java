package hyzon.geo;

import hyzon.Rasterizable;
import hyzon.ZBuffer;
import hyzon.math.Vector2;
import java.awt.image.BufferedImage;

public class Triangle2
  implements Rasterizable
{
  private Vector2 a, b;
  
  public Triangle2()
  {
    this.a = new Vector2();
    this.b = new Vector2();
  }
  
  public void rasterize(BufferedImage image, ZBuffer zbuffer)
  {
    
  }
}
