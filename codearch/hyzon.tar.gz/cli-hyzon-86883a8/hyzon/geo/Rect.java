package hyzon.geo;

import hyzon.math.Vector3;

public class Rect
{
  private Triangle3 t0, t1;
  
  public Rect(Vector3 a, Vector3 b, Vector3 c, Vector3 d)
  {
    this.t0 = new Triangle3(a, b, c);
    this.t1 = new Triangle3(a, c, d);
  }
  
  public Triangle3 getTriangle0()
  {
    return t0;
  }
  
  public Triangle3 getTriangle1()
  {
    return t1;
  }
}
