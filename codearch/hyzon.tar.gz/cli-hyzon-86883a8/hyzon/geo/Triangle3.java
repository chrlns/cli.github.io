package hyzon.geo;

import hyzon.Rasterizable;
import hyzon.ZBuffer;
import hyzon.gfx.Texture;
import hyzon.math.Matrix4x4;
import hyzon.math.Vector3;

import java.awt.image.BufferedImage;
import java.util.Arrays;

/**
 * Base 3D-primitive of the Hyzon renderer.
 * @author Christian Lins
 */
public class Triangle3
  implements Rasterizable
{  
  /**
   * Describes the x-axis relation of the third point to the top and bottom point of the 
   * triangle. This is important for the renderer when it interpolates colors and
   * texture coordinates.
   * @author Christian Lins
   */
  class ThirdPointRelation
  {
    /**
     * Third point lies left of top and bottom point.
     */
    public static final byte LEFT_OF = 0;
    
    /**
     * Third point lies left of top and bottom point.
     */
    public static final byte RIGHT_OF = 1;
  }
  
  private Texture   texture;
  private Vector3[] v;
  
  public Triangle3(Vector3 v1, Vector3 v2, Vector3 v3)
  {
    texture = Texture.DefaultTexture;
    this.v = new Vector3[] {v1, v2, v3};
  }
  
  public Triangle3(Triangle3 t)
  {
    v    = new Vector3[3];
    v[0] = new Vector3(t.v[0]);
    v[1] = new Vector3(t.v[1]);
    v[2] = new Vector3(t.v[2]);
  }
  
  /**
   * Rotates the triangle using the following matrix:
   * (  1 0       0       0
   *    0 cos(a)  -sin(a) 0     X-Axis-rotation
   *    0 sin(a)  cos(a)  0
   *    0 0       0       1 )
   *    
   * (  cos(b)  0 sin(b) 0
   *    0       1 0      0      Y-Axis-rotation
   *    -sin(b) 0 cos(b) 0
   *    0       0 0      1)
   *    
   * (  cos(c)  -sin(c) 0 0
   *    sin(c)  cos(c)  0 0     Z-Axis-rotation
   *    0       0       1 0
   *    0       0       0 1)
   *    
   * @param angle
   */
  public void rotate(Vector3 angle)
  {
    float[][] m = new float[4][4];
    
    // X-Axis rotation
    m[0][0] = 1.0f;
    m[0][1] = 0.0f;
    m[0][2] = 0.0f;
    m[0][3] = 0.0f;
    
    m[1][0] = 0.0f;
    m[1][1] = (float)Math.cos(angle.getX());
    m[1][2] = -(float)Math.sin(angle.getX());
    m[1][3] = 0.0f;
    
    m[2][0] = 0.0f;
    m[2][1] = (float)Math.sin(angle.getX());
    m[2][2] = (float)Math.cos(angle.getX());
    m[2][3] = 0.0f;
    
    m[3][0] = 0.0f;
    m[3][1] = 0.0f;
    m[3][2] = 0.0f;
    m[3][3] = 1.0f;
    
    for(int n = 0; n < 3; n++)
      v[n] = v[n].multiply(new Matrix4x4(m));
    
    // Y-Axis-Rotation
    m[0][0] = (float)Math.cos(angle.getY());
    m[0][1] = 0.0f;
    m[0][2] = (float)Math.sin(angle.getY());
    m[0][3] = 0.0f;
    
    m[1][0] = 0.0f;
    m[1][1] = 1.0f;
    m[1][2] = 0.0f;
    m[1][3] = 0.0f;
    
    m[2][0] = -(float)Math.sin(angle.getY());
    m[2][1] = 0.0f;
    m[2][2] = (float)Math.cos(angle.getY());
    m[2][3] = 0.0f;
    
    m[3][0] = 0.0f;
    m[3][1] = 0.0f;
    m[3][2] = 0.0f;
    m[3][3] = 1.0f;
    
    for(int n = 0; n < 3; n++)
      v[n] = v[n].multiply(new Matrix4x4(m));
    
    // Z-Axis-Rotation
    m[0][0] = (float)Math.cos(angle.getZ());
    m[0][1] = -(float)Math.sin(angle.getZ());
    m[0][2] = 0.0f;
    m[0][3] = 0.0f;
    
    m[1][0] = (float)Math.sin(angle.getZ());
    m[1][1] = (float)Math.cos(angle.getZ());
    m[1][2] = 0.0f;
    m[1][3] = 0.0f;
    
    m[2][0] = 0.0f;
    m[2][1] = 0.0f;
    m[2][2] = 1.0f;
    m[2][3] = 0.0f;
    
    m[3][0] = 0.0f;
    m[3][1] = 0.0f;
    m[3][2] = 0.0f;
    m[3][3] = 1.0f;
    
    for(int n = 0; n < 3; n++)
      v[n] = v[n].multiply(new Matrix4x4(m));
  }
  
  /**
   * Translates the triangle with the following matrix:
   * (  1 0 0 x
   *    0 1 0 y     * v   =   v'
   *    0 0 0 z
   *    0 0 0 1 )
   * @param translation
   */
  public void translate(Vector3 translation)
  {
    v[0].add(translation);
    v[1].add(translation);
    v[2].add(translation);
  }
  
  /**
   * (  x 0 0 0
   *    0 y 0 0
   *    0 0 z 0
   *    0 0 0 1   )
   * @param scale
   */
  public void scale(Vector3 scale)
  {
    for(int n = 0; n < 3; n++)
    {
      v[n].multiply(scale);
    }
  }
  
  private int interpolate(int f0, int f1, int x0, int x1, int x)
  {
    int r = f0 + Math.round((float)(f1 - f0) / (float)(x1 - x0) * (x - x0));
    return r;
  }
  
  private float interpolate(float f0, float f1, int x0, int x1, int x)
  {
    float r = f0 + (float)(f1 - f0) / (float)(x1 - x0) * (x - x0);
    return r;
  }  
  
  /**
   * Rasterizes a triangle span. This method is one of the most
   * called methods within the complete engine. It should be as fast
   * as possible.
   * @param buffer
   * @param zbuffer
   * @param y
   * @param xl
   * @param xr
   * @param zl
   * @param zr
   * @param yMax
   * @param u1
   * @param v1
   * @param u2
   * @param v2
   * @return Number of rastered pixels.
   */
  private int rasterSpan(BufferedImage buffer, ZBuffer zbuffer,
      int y, int xl, int xr, float zl, float zr, int yMax, float u1, float v1, float u2, float v2)
  {
    int x1;
    int x2;
    int renderedPixel = 0;
    
    if(xr < xl)
    {
      x1 = xr;
      x2 = xl;
    }
    else
    {
      x1 = xl;
      x2 = xr;
    }
    
    int interpolation = x2 - x1; // x2 is always > x1
    float uDiff = 0.0f;
    float vDiff = 0.0f;
    float zDiff = 0.0f;
    if(interpolation > 0)
    {
      uDiff = (u2 - u1) / interpolation; 
      vDiff = (v2 - v1) / interpolation;
      zDiff = (zr - zl) / interpolation;
    }

    for(int x = x1; x <= x2; x++)
    {
      if(zbuffer.testVisibility(x, y, zl)) // ZBuffer-Test 
      {
        buffer.setRGB(x, y, texture.getRGB(u1, v1));
        renderedPixel++;
      }
      u1 += uDiff;
      v1 += vDiff;
      zl += zDiff;
    }
    
    return renderedPixel;
  }
  
  private byte getThirdPointRelation(Vector3 top, Vector3 third, Vector3 bottom)
  {    
    if(top.x() < third.x() && bottom.x() <= third.x())
      return ThirdPointRelation.RIGHT_OF;
    else if(top.x() >= third.x() && bottom.x() > third.x())
      return ThirdPointRelation.LEFT_OF;
    else
    {
      if(Math.abs(top.x() - third.x()) < Math.abs(bottom.x() - third.x()))
        return ThirdPointRelation.LEFT_OF;
      else 
        return ThirdPointRelation.RIGHT_OF;
    }
  }
  
  /**
   * Rasterizes this triangle using the given texture.
   * @param buffer
   */
  public void rasterize(BufferedImage buffer, ZBuffer zbuffer)
  {
    int halfWidth   = buffer.getWidth() >> 1; // / 2;
    int halfHeight  = buffer.getHeight() >> 1;// / 2;
    int renderedPixel = 0;
    
    int   xl = 0, xr = 0;
    float zl = 0, zr = 0;
    
    // We start rasterizing with the top point
    Arrays.sort(v, new Vector3.VerticalComparator());
    
    Vector3 vTop = v[0];
    Vector3 v3rd = v[1];
    Vector3 vBtm = v[2];
    
    byte posOf3rd = getThirdPointRelation(vTop, v3rd, vBtm);
    
    // Draw the spans from top to third point (middle)
    for(int y = vTop.y() + halfHeight; y < v3rd.y() + halfHeight; y++)
    {
      float u1 = 0.0f, v1 = 0.0f;
      float u2 = 1.0f, v2 = 0.0f;

      // Determine positions of left and right end
      switch(posOf3rd)
      {
        case ThirdPointRelation.LEFT_OF:
        {
          xl = interpolate(vTop.x() + halfWidth, v3rd.x() + halfWidth, vTop.y() + halfHeight, v3rd.y() + halfHeight, y);
          xr = interpolate(vTop.x() + halfWidth, vBtm.x() + halfWidth, vTop.y() + halfHeight, vBtm.y() + halfHeight, y);
          zl = interpolate(vTop.getZ() + halfWidth, v3rd.getZ() + halfWidth, vTop.y() + halfHeight, v3rd.y() + halfHeight, y);
          zr = interpolate(vTop.getZ() + halfWidth, vBtm.getZ() + halfWidth, vTop.y() + halfHeight, vBtm.y() + halfHeight, y);

          
          u1 = interpolate((float)vTop.getU(), (float)v3rd.getU(), vTop.y() + halfHeight, v3rd.y() + halfHeight, y);
          v1 = interpolate((float)vTop.getV(), (float)v3rd.getV(), vTop.y() + halfHeight, v3rd.y() + halfHeight, y);
          u2 = interpolate((float)vTop.getU(), (float)vBtm.getU(), vTop.y() + halfHeight, vBtm.y() + halfHeight, y);
          v2 = interpolate((float)vTop.getV(), (float)vBtm.getV(), vTop.y() + halfHeight, vBtm.y() + halfHeight, y);
          break;
        }
        case ThirdPointRelation.RIGHT_OF:
        {
          xr = interpolate(vTop.x() + halfWidth, vBtm.x() + halfWidth, vTop.y() + halfHeight, vBtm.y() + halfHeight, y);          
          xl = interpolate(vTop.x() + halfWidth, v3rd.x() + halfWidth, vTop.y() + halfHeight, v3rd.y() + halfHeight, y);
          zr = interpolate(vTop.getZ() + halfWidth, vBtm.getZ() + halfWidth, vTop.y() + halfHeight, vBtm.y() + halfHeight, y);          
          zl = interpolate(vTop.getZ() + halfWidth, v3rd.getZ() + halfWidth, vTop.y() + halfHeight, v3rd.y() + halfHeight, y);
          
          u1 = interpolate((float)vTop.getU(), (float)vBtm.getU(), vTop.y() + halfHeight, vBtm.y() + halfHeight, y);
          v1 = interpolate((float)vTop.getV(), (float)vBtm.getV(), vTop.y() + halfHeight, vBtm.y() + halfHeight, y);
          u2 = interpolate((float)vTop.getU(), (float)v3rd.getU(), vTop.y() + halfHeight, v3rd.y() + halfHeight, y);
          v2 = interpolate((float)vTop.getV(), (float)v3rd.getV(), vTop.y() + halfHeight, v3rd.y() + halfHeight, y);  
          break;
        }
        default:
          throw new Error("Internal Error");
      }
      renderedPixel += rasterSpan(buffer, zbuffer, 
          y, xl, xr, zl, xr, Math.abs(v3rd.y() - vTop.y()), u1, v1, u2, v2);
    }
    
    // Draw the spans from third point to bottom
    for(int y = v3rd.y() + halfHeight; y < vBtm.y() + halfHeight; y++)
    {
      float u1 = 0.0f, v1 = 0.0f;
      float u2 = 1.0f, v2 = 0.0f;     
      
      // Determine positions of left and right end
      switch(posOf3rd)
      {
        case ThirdPointRelation.LEFT_OF:
        {
          xl = interpolate(v3rd.x() + halfWidth, vBtm.x() + halfWidth, v3rd.y() + halfHeight, vBtm.y() + halfHeight, y);
          xr = interpolate(vTop.x() + halfWidth, vBtm.x() + halfWidth, vTop.y() + halfHeight, vBtm.y() + halfHeight, y);
          zl = interpolate(v3rd.getZ() + halfWidth, vBtm.getZ() + halfWidth, v3rd.y() + halfHeight, vBtm.y() + halfHeight, y);
          zr = interpolate(vTop.getZ() + halfWidth, vBtm.getZ() + halfWidth, vTop.y() + halfHeight, vBtm.y() + halfHeight, y);

          
          u1 = interpolate((float)v3rd.getU(), (float)vBtm.getU(), v3rd.y() + halfHeight, vBtm.y() + halfHeight, y);
          v1 = interpolate((float)v3rd.getV(), (float)vBtm.getV(), v3rd.y() + halfHeight, vBtm.y() + halfHeight, y);
          u2 = interpolate((float)vTop.getU(), (float)vBtm.getU(), vTop.y() + halfHeight, vBtm.y() + halfHeight, y);
          v2 = interpolate((float)vTop.getV(), (float)vBtm.getV(), vTop.y() + halfHeight, vBtm.y() + halfHeight, y);  
          break;
        }
        case ThirdPointRelation.RIGHT_OF:
        {
          xl = interpolate(vTop.x() + halfWidth, vBtm.x() + halfWidth, vTop.y() + halfHeight, vBtm.y() + halfHeight, y);          
          xr = interpolate(v3rd.x() + halfWidth, vBtm.x() + halfWidth, v3rd.y() + halfHeight, vBtm.y() + halfHeight, y);
          zl = interpolate(vTop.getZ() + halfWidth, vBtm.getZ() + halfWidth, vTop.y() + halfHeight, vBtm.y() + halfHeight, y);          
          zr = interpolate(v3rd.getZ() + halfWidth, vBtm.getZ() + halfWidth, v3rd.y() + halfHeight, vBtm.y() + halfHeight, y);

          
          u1 = interpolate((float)vTop.getU(), (float)vBtm.getU(), vTop.y() + halfHeight, vBtm.y() + halfHeight, y);
          v1 = interpolate((float)vTop.getV(), (float)vBtm.getV(), vTop.y() + halfHeight, vBtm.y() + halfHeight, y);  
          u2 = interpolate((float)v3rd.getU(), (float)vBtm.getU(), v3rd.y() + halfHeight, vBtm.y() + halfHeight, y);
          v2 = interpolate((float)v3rd.getV(), (float)vBtm.getV(), v3rd.y() + halfHeight, vBtm.y() + halfHeight, y);      
          break;
        }
        default:
          throw new Error("Internal Error");
      }      
      renderedPixel += rasterSpan(buffer, zbuffer,
          y, xl, xr, zl, zr, vBtm.y() - v3rd.y(), u1, v1, u2, v2);
    }

    // Debug
    /*java.awt.Graphics g =  buffer.getGraphics();
    g.setColor(java.awt.Color.RED);
    g.drawLine(v[0].x() + halfWidth, v[0].y() + halfHeight, v[1].x() + halfWidth, v[1].y() + halfHeight);
    g.drawLine(v[1].x() + halfWidth, v[1].y() + halfHeight, v[2].x() + halfWidth, v[2].y() + halfHeight);
    g.drawLine(v[2].x() + halfWidth, v[2].y() + halfHeight, v[0].x() + halfWidth, v[0].y() + halfHeight);*/
  }
     
  public Vector3[] getVertices()
  {
    return v;
  }
  
  public float getDepthCentroid()
  {
    return (v[0].getZ() + v[1].getZ() + v[2].getZ()) / 3.0f;
  }
}
