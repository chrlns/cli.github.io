package hyzon;

import hyzon.geo.Rect;
import hyzon.geo.Triangle3;
import hyzon.math.Matrix4x4;
import hyzon.math.Vector3;

import java.awt.Image;
import java.awt.image.BufferedImage;

public class Renderer
{
  private BufferedImage       backbuffer    = null;
  private boolean             locked        = false;
  private int                 renderedPixel = 0;
  private ZBuffer             zbuffer       = null;
  
  // Primitive transformations
  private Vector3 objTranslation = new Vector3();
  private Vector3 objRotation    = new Vector3();
  private Vector3 objScaling     = new Vector3();
  
  public Renderer()
  { 
    //this.backbuffer  = GraphicsEnvironment.getLocalGraphicsEnvironment()
    //  .getDefaultScreenDevice().getDefaultConfiguration()
    //  .createCompatibleImage(400, 300);
    this.backbuffer = new BufferedImage(400, 300, BufferedImage.TYPE_INT_RGB);
    this.backbuffer.setAccelerationPriority(1.0f);
    
    this.zbuffer = new ZBuffer(600, 400);
  }
  
  public void setRotation(Vector3 rotation)
  {
    this.objRotation = rotation;
  }
  
  public void addRotation(Vector3 rotation)
  {
    this.objRotation.add(rotation);
  }
  
  /**
   * Clears the backbuffer with the default color and prepares
   * the renderer for a new scene.
   */
  public void beginScene()
  {  
    //this.backbuffer.getGraphics().setColor(Color.BLACK);
    this.backbuffer.getGraphics().clearRect(0, 0, 640, 480);
    this.zbuffer.clear();
  }
  
  public void draw(Rect obj)
  {
    draw(obj.getTriangle0());
    draw(obj.getTriangle1());
  }
  
  /**
   * Draws the given triangle.
   * @param obj
   */
  public void draw(Triangle3 obj)
  {
    // Deep copy of the triangle
    obj = new Triangle3(obj);
    
    // World transformation (translation, rotation, scaling) of the object
    obj.translate(this.objTranslation);
    obj.rotate   (this.objRotation);
    obj.scale    (this.objScaling);
    
    // Camera transformation (translation^-1, rotation^-1, scaling^-1)
    
    
    // Perspective distortion  
    // (  cot(g)  0      0          0
    //    0       cot(v)
    //    0       0     (B+F)/(B-F) (-2BF)/(B-F)
    //    0       0     0           1             )
    // g: is the angle between a line pointing out of the camera in z 
    // direction and the plane through the camera and the right-hand edge of 
    // the screen
    // v: is the angle between the same line and the plane through the 
    // camera and the top edge of the screen.
    float g = 1;
    float v = 1;
    float f = 0;  // Distance to front-clipping plane
    float b = 1000;  // Distance to back-clipping plane
    
    float[][] matrix = new float[4][4];
    
    matrix[0][0] = 1.0f / (float)Math.tan(g);
    matrix[0][1] = 0;
    matrix[0][2] = 0;
    matrix[0][3] = 0;
    matrix[1][0] = 0;
    matrix[1][1] = 1.0f / (float)Math.tan(v);
    matrix[1][2] = 0;
    matrix[1][3] = 0;
    matrix[2][0] = 0;
    matrix[2][1] = 0;
    matrix[2][2] = (b+f)/(b-f);
    matrix[2][3] = (-2*b*f)/(b-f);
    matrix[3][0] = 0;
    matrix[3][1] = 0;
    matrix[3][2] = 0;
    matrix[3][3] = 1;
    
    Vector3[] vertices = new Vector3[3];
    for(int n = 0; n < 3; n++)
    {
      vertices[n] = obj.getVertices()[n].multiply(new Matrix4x4(matrix));
      vertices[n] = vertices[n].multiply(100);
    }
    
    Triangle3 t = new Triangle3(vertices[0], vertices[1], vertices[2]);
    
    // Rasterize triangle with Texture Mapping
    t.rasterize(backbuffer, zbuffer);
  }
  
  public void endScene()
  {
    
  }
  
  ////////////////////////////////////////////////////
  // Getter / Setter
  ////////////////////////////////////////////////////
  
  public Image getRenderedImage()
  {
    return this.backbuffer;
  }
  
  public void setViewport(long x, long y, long w, long h)
  {
    //this.viewport = new long[] {x, y, w, h};
    
   // this.vHeightHalf = h * 0.5;
   // this.vWidthHalf  = w * 0.5;
  }
  
  // TODO: Add a wait/notify statement
  public void lock()
  {
    try
    {
      while(this.locked)
      {
        // Suspends the thread for a millisecond. Don't use 0 as parameter
        // or Thread.yield()
        Thread.sleep(1);
      }
    }
    catch(InterruptedException e)
    {
      System.err.println(e.getMessage());
    }
    
    this.locked = true;
  }
  
  public void unlock()
  {
    this.locked = false;
  }
  
  public int getRenderedPixelCount(boolean reset)
  {
    int ret = this.renderedPixel;
    if(reset)
      renderedPixel = 0;
    return ret;
  }
}
