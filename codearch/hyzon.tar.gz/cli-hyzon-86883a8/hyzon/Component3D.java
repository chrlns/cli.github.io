package hyzon;

import java.awt.*;
import java.awt.image.*;
import java.util.*;
import javax.swing.*;
import hyzon.geo.*;
import hyzon.math.Vector3;

public class Component3D
  extends JComponent
  implements ImageObserver
{
  public static final long serialVersionUID = 0;
  
  class FPSTimer
    extends TimerTask
  {
    private int         currentFrames   = 0;
    private int         currentFPS      = 0;
    private Component3D parent;
    
    public FPSTimer(Component3D parent)
    {
      this.parent = parent;
    }
    
    public void nextFrame()
    {
      this.currentFrames++;
    }
      
    public int getFPS()
    {
      return this.currentFPS;
    }
    
    public void run()
    {
      this.currentFPS    = this.currentFrames;
      this.currentFrames = 0;
      
      if(parent != null && parent.refresher != null)
        this.parent.refresher.testRot();
    }
  }
  
  class Refresher 
    extends Thread
  {
    private Component3D parent;
    private float       rot     = 0;
    private FPSTimer    timer;
    
    public Refresher(Component3D parent, FPSTimer timer)
    {
      this.parent = parent;
      this.timer  = timer;
      setPriority(Thread.MAX_PRIORITY);
    }
    
    public void run()
    {
      for(;;)
      {
        parent.renderer.lock();       // Lock the renderer
        parent.renderer.beginScene();
        
        Triangle3 t0 = new Triangle3( // Front A
          new Vector3(-10, 10, 10, 0.0f, 0.0f), 
          new Vector3(10, -10, 10, 1.0f, 0.0f),  
          new Vector3(10, 10, 10, 1.0f, 1.0f)    
          );
        
        Triangle3 t1 = new Triangle3( // Front B
            new Vector3(-10, 10, 10, 1.0f, 1.0f),
            new Vector3(-10, -10, 10, 0.0f, 1.0f),
            new Vector3(10, -10, 10, 0.0f, 0.0f)
            );
        
        Triangle3 t2 = new Triangle3( // Right A
            new Vector3(10, 10, 10, 0.0f, 0.0f),
            new Vector3(10, -10, 10, 1.0f, 0.0f),
            new Vector3(10, 10, -10, 1.0f, 1.0f)
            );
          
        Triangle3 t3 = new Triangle3( // Right B
              new Vector3(10, -10, 10, 1.0f, 1.0f),
              new Vector3(10, -10, -10, 0.0f, 1.0f),
              new Vector3(10, 10, -10, 0.0f, 0.0f)
              );
          
        Triangle3 t4 = new Triangle3( // Left A
              new Vector3(-10, 10, 10, 0.0f, 0.0f),
              new Vector3(-10, -10, 10, 0.0f, 1.0f),
              new Vector3(-10, 10, -10, 1.0f, 1.0f)
              );
        
        Triangle3 t5 = new Triangle3( // Left B
            new Vector3(-10, -10, 10, 0.0f, 0.0f),
            new Vector3(-10, -10, -10, 0.0f, 1.0f),
            new Vector3(-10, 10, -10, 1.0f, 1.0f)
            );
        
        Triangle3 t6 = new Triangle3( // Back A
            new Vector3(-10, 10, -10, 0.0f, 0.0f), 
            new Vector3(-10, -10, -10, 1.0f, 0.0f),  
            new Vector3(10, -10, -10, 1.0f, 1.0f)    
            );
          
          Triangle3 t7 = new Triangle3( // Back B
              new Vector3(-10, 10, -10, 1.0f, 1.0f),
              new Vector3(10, 10, -10, 0.0f, 1.0f),
              new Vector3(10, -10, -10, 0.0f, 0.0f)
              );
          
          Triangle3 t8 = new Triangle3( // Top A
              new Vector3(-10, 10, 10, 0.0f, 0.0f), 
              new Vector3(10, 10, 10, 1.0f, 0.0f),  
              new Vector3(10, 10, -10, 1.0f, 1.0f)    
              );
            
            Triangle3 t9 = new Triangle3( // Top B
                new Vector3(-10, 10, 01, 1.0f, 1.0f),
                new Vector3(-10, 10, -10, 0.0f, 1.0f),
                new Vector3(10, 10, -10, 0.0f, 0.0f)
                );
            
            Triangle3 t10 = new Triangle3( // Bottom A
                new Vector3(-10, -10, -10, 0.0f, 0.0f), 
                new Vector3(10, -10, -10, 1.0f, 0.0f),  
                new Vector3(-10, -10, 10, 1.0f, 1.0f)    
                );
              
              Triangle3 t11 = new Triangle3( // Bottom B
                  new Vector3(-10, -10, 10, 1.0f, 1.0f),
                  new Vector3(10, -10, 10, 0.0f, 1.0f),
                  new Vector3(10, -10, -10, 0.0f, 0.0f)
                  );
        
        rot += 0.01;

        parent.renderer.setRotation(new Vector3(rot, rot, rot, 0, 0));
        parent.renderer.draw(t0);
        parent.renderer.draw(t1);
        parent.renderer.draw(t2);
        parent.renderer.draw(t3);
        parent.renderer.draw(t4);
        parent.renderer.draw(t5);
        parent.renderer.draw(t6);
        parent.renderer.draw(t7);
        parent.renderer.draw(t8);
        parent.renderer.draw(t9);
        parent.renderer.draw(t10);
        parent.renderer.draw(t11);
        
        /*Rect r0 = new Rect(new Vector3(-1, 1, -1, 0, 0),
                           new Vector3(-1, 1, 1, 0, 1),
                           new Vector3(1, 1, -1, 1, 0),
                           new Vector3(-1, 1, 1, 1, 1));
       
        Rect r1 = new Rect(new Vector3(-1, -1, -1, 0, 0),
            new Vector3(-1, -1, 1, 0, 1),
            new Vector3(1, -1, -1, 1, 0),
            new Vector3(-1, -1, 1, 1, 1));
        
        parent.renderer.draw(r0);
        parent.renderer.draw(r1);*/
        
        parent.renderer.endScene();
        parent.renderer.unlock();
        
        parent.repaint();
        try
        {
          Thread.sleep(10);
        }
        catch(InterruptedException e){}
        timer.nextFrame();
      }
    }
    
    public void testRot()
    {
      //rot += 0.1;
    }
  }
  
  Refresher refresher;
  Renderer  renderer = new Renderer();
  FPSTimer  timer    = new FPSTimer(this);
  
  public Component3D()
  {
    java.util.Timer timer = new java.util.Timer();
    timer.scheduleAtFixedRate(this.timer, 0, 1000);
    
    refresher = new Refresher(this, this.timer);
    refresher.start();
    
    setDoubleBuffered(false);
  }
  
  /**
   * Returns the Renderer of this Component3D.
   */
  public Renderer getRenderer()
  {
    return this.renderer;
  }
  
  /**
   * Overwrite this method to add Java2D paintings to the screen.
   * But be sure to call super.paintComponent(), otherwise no 
   * 3D-Renderings will be visible.
   */
  public void paintComponent(Graphics g)
  {
    this.renderer.lock();
  
    if(g.drawImage(renderer.getRenderedImage(), 0, 0, 400, 300, this))
      this.renderer.unlock();
  }
  
  public boolean imageUpdate(Image img, int infoflags, int x, int y, int width, int height)
  {
    if((infoflags | ImageObserver.ALLBITS) == infoflags)
    {
      this.renderer.unlock();
      return false;
    }
    else
      return true;
  }
  
  public int getFPS()
  {
    return this.timer.getFPS();
  }
  
  /**
   * Switches the current GraphicsDevice to fullscreen mode or returns to
   * windowed mode (if frame is null).
   * @param frame
   */
  public static Window setFullscreenMode(JFrame frame)
  {
    GraphicsDevice dev = GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice();
    
    if(frame == null)
      dev.setFullScreenWindow(null);
    
    Window window = new Window(frame);    
    
    if(!dev.isFullScreenSupported())
      return null;
    
    dev.setFullScreenWindow(window);
    return window;
  }
}