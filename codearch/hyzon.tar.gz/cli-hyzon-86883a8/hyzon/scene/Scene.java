package hyzon.scene;

import hyzon.HyzonComponent;
import hyzon.math.Vector3;
import java.util.ArrayList;
import java.util.List;
import javax.media.opengl.GL;

public class Scene
  implements Drawable, Node
{

  private List<Node>      children = new ArrayList<Node>();
  private HyzonComponent  comp     = null;
  
  public Scene()
  {  
  }
  
  public Scene(HyzonComponent comp)
  {
    this.comp = comp;
  }
  
  public void draw(GL gl)
  {
    gl.glLoadIdentity();
    
    for(Node node : children)
    {
      if(node instanceof Drawable)
      {
        ((Drawable)node).draw(gl);
      }
    }
  }

  public void addChild(Node node)
  {
    this.children.add(node);
    node.setParent(this);
  }

  public void fireChangedEvent()
  {
    // Process the event as the scene is generally root
    if(this.comp != null)
      this.comp.repaint();
  }
  
  public List<Node> getChildren()
  {
    return this.children;
  }

  /**
   * Always returns null.
   */
  public Node getParent()
  {
    return null;
  }

  public void setParent(Node node)
  {
    // Empty
  }
  
  /**
   * 
   * @return
   */
  public Vector3 getPosition()
  {
    return new Vector3();
  }

  public void removeChild(Node node)
  {
    this.children.remove(node);
    
    if(node.getParent().equals(this))
      node.setParent(null);
  }

  public void setPosition(Vector3 pos)
  {
    System.out.println("Warning: Scene.setPosition() has no effect.");
  }

  public Vector3 getRotation()
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }

  public void setRotation(Vector3 rot)
  {
    throw new UnsupportedOperationException("Not supported yet.");
  }
  
  

}
