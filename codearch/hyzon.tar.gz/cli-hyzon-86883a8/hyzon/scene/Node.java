/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hyzon.scene;

import hyzon.math.Vector3;
import java.util.List;

/**
 *
 * @author chris
 */
public interface Node 
{
  void addChild(Node node);
  Node getParent();
  void setParent(Node node);
  void removeChild(Node node);
  List<Node> getChildren();
  
  Vector3 getPosition();
  void    setPosition(Vector3 pos);
  
  Vector3 getRotation();
  void    setRotation(Vector3 rot);
  
  void fireChangedEvent();
}
