/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hyzon.scene;

import hyzon.math.Vector3;
import java.util.List;
import javax.media.opengl.GL;

/**
 *
 * @author chris
 */
public class DefaultNode 
  implements Drawable, Node
{

  protected Node    parent   = null;
  protected Vector3 position = new Vector3();
  protected Vector3 rotation = new Vector3();
  
  public void draw(GL gl)
  {
    // Empty
  }

  public void addChild(Node node)
  {
    
  }

  public void fireChangedEvent()
  {
    if(getParent() != null)
      getParent().fireChangedEvent();
  }
  
  public List<Node> getChildren()
  {
    return null;
  }

  public Node getParent()
  {
    return this.parent;
  }
  
  public void setParent(Node node)
  {
    this.parent = node;
  }

  public Vector3 getPosition()
  {
    return this.position;
  }

  public void removeChild(Node node)
  {
    
  }

  public void setPosition(Vector3 pos)
  {
    this.position = pos;
  }

  public Vector3 getRotation()
  {
    return this.rotation;
  }

  public void setRotation(Vector3 rot)
  {
    this.rotation = rot;
    fireChangedEvent();
  }
  
  protected static void glRotate(GL gl, Vector3 rot)
  {
    gl.glRotatef(rot.getX(), 1, 0, 0);
    gl.glRotatef(rot.getY(), 0, 1, 0);
    gl.glRotatef(rot.getZ(), 0, 0, 1);
  }
  
}
