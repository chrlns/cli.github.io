/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hyzon.scene.animator;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author chris
 */
public abstract class Animator 
{
  protected List<AnimatorListener> listeners = new ArrayList<AnimatorListener>();
  
  public void addAnimatorListener(AnimatorListener listener)
  {
    this.listeners.add(listener);
  }
  
  protected void notifyListeners(AnimatorEvent event)
  {
    for(AnimatorListener l : this.listeners)
      l.animatorStep(event);
  }
  
  public void removeAnimatorListener(AnimatorListener listener)
  {
    this.listeners.remove(listener);
  }
  
  public abstract void start();
}
