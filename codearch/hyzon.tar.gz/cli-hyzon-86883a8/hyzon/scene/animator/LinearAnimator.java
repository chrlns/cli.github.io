/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hyzon.scene.animator;

import hyzon.math.Vector3;
import java.util.Timer;

/**
 *
 * @author Christian Lins (christian.lins@web.de)
 */
public class LinearAnimator 
  extends Animator
{
  
  private Vector3 value     = null;
  private Vector3 diff      = null;
  private int     duration  = 0;
  private Timer   timer     = new Timer();
  private int     ticked    = 0;
  
  /**
   * 
   * @param startValue
   * @param endValue
   * @param duration Animator duration in milliseconds.
   */
  public LinearAnimator(Vector3 startValue, Vector3 endValue, int duration)
  {
    this.value = startValue;
    this.diff  = endValue.substract(startValue).multiply(1.0f / duration * 10.0f);
    this.duration = duration;
  }
  
  public Vector3 getValue()
  {
    return this.value;
  }
  
  public void start()
  {
    timer.schedule(new LinearAnimatorTimerTask(this), 0, 10);
  }
  
  protected void tick()
  {
    if(duration < ticked)
      timer.cancel();
    
    ticked += 10;
    this.value = this.value.add(this.diff);
    
    // Notify listener
    notifyListeners(new AnimatorEvent(this.value));
  }
}
