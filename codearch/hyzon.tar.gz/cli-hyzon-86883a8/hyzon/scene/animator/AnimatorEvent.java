/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hyzon.scene.animator;

import hyzon.math.Vector3;

/**
 *
 * @author chris
 */
public class AnimatorEvent 
{
  protected Vector3 value;
  
  protected AnimatorEvent(Vector3 value)
  {
    this.value = value;
  }
  
  public Vector3 getValue()
  {
    return this.value;
  }
}
