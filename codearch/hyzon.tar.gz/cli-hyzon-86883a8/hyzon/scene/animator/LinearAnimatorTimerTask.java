/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hyzon.scene.animator;

import java.util.TimerTask;

/**
 *
 * @author Christian Lins (christian.lins@web.de)
 */
class LinearAnimatorTimerTask 
  extends TimerTask
{

  private LinearAnimator animator;
  
  public LinearAnimatorTimerTask(LinearAnimator animator)
  {
    this.animator = animator;
  }
  
  @Override
  public void run()
  {
    this.animator.tick();
  }

}
