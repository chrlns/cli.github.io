/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hyzon.scene;

import javax.media.opengl.GL;

/**
 *
 * @author chris
 */
public interface Drawable 
{
  /**
   * Called by an GLEventListener every time the element needs to
   * be repainted.
   * @param gl
   */
  void draw(GL gl);
}
