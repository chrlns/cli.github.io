package hyzon.shader;

public class RegisterSet
{
  /**
   * A PixelShader 1.4 compliant register set.
   * Note that every register consists of 4 32bit floats.
   * @author C#ris
   */
  public class Pixel
  {
    public float[]    c   = new float[8 * 4];  // Constant float register
    public float[]    r   = new float[6 * 4];  // Temporary register
    public float[]    t   = new float[6 * 4];  // Texture register
    public float[]    v   = new float[2 * 4];  // Color register
  }
}
