package hyzon.shader;

/**
 * Main part of the Virtual Graphics Machine (VGM) that actually executes the
 * pixel shader code. This pixel engine should be compliant with the PixelShader 1.4 spec.
 * @author C#ris
 */
public class PixelEngine
{
  byte[] code;
    
  public PixelEngine(byte[] code)
  {
    this.code = code;
  }
    
  public float process(RegisterSet.Pixel register)
  {
    return 0;
  }
}
