package hyzon.shader;

public enum ShaderType
{
  /**
   * Pixel Shader. This type of shader is called on every processed pixel.
   */
  PIXEL,
  
  /**
   * Vertex Shader. This type of shader is called on every processed pixel.
   */
  VERTEX,
  
  /**
   * Postprocess Image Shader. This type of shader is called on every rendered image.
   */
  IMAGE
}
