package hyzon.shader;

import java.io.*;

public class Shader
  implements Runnable
{
  public Shader(File file, ShaderType type)
  {
    // Load the file
  }
  
  public Shader(byte[] data, ShaderType type)
  {
    
  }
  
  public Shader(String[] data, ShaderType type)
  {
    // Run the compiler
  }
  
  public void run()
  {
    
  }
}
