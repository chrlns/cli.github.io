/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package hyzon.opengl;

import hyzon.scene.Drawable;
import javax.media.opengl.DebugGL;
import javax.media.opengl.GL;
import javax.media.opengl.GLAutoDrawable;
import javax.media.opengl.GLEventListener;
import javax.media.opengl.glu.GLU;

/**
 *
 * @author Christian Lins (christian.lins@web.de)
 */
public class GLEventAdapter 
  implements GLEventListener
{

  private Drawable rootNode = null;
  
  public GLEventAdapter(Drawable root)
  {
    this.rootNode = root;
  }
  
  public void display(GLAutoDrawable drawable)
  {
    // Clears the screen to black
    drawable.getGL().glClearColor(0, 0, 0, 0);
    drawable.getGL().glClear(GL.GL_COLOR_BUFFER_BIT | GL.GL_DEPTH_BUFFER_BIT);
    drawable.getGL().glEnable(GL.GL_DEPTH_TEST);
    drawable.getGL().glDepthMask(true);
    
    this.rootNode.draw(drawable.getGL());
  }

  public void displayChanged(GLAutoDrawable arg0, boolean arg1, boolean arg2)
  {
    
  }

  public void init(GLAutoDrawable drawable)
  {
    drawable.setGL(new DebugGL(drawable.getGL()));
  }

  public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height)
  {
    GL gl = drawable.getGL();
    
    if(height <= 0)
      height = 1;
    
    gl.glViewport(0, 0, width, height);
    gl.glMatrixMode(GL.GL_PROJECTION);
    
    gl.glLoadIdentity();							// Reset The Projection Matrix

	// Calculate The Aspect Ratio Of The Window
    GLU glu = new GLU();
	glu.gluPerspective(45.0f, (float)width / (float)height, 0.1f, 100.0f);

	gl.glMatrixMode(GL.GL_MODELVIEW);   // Select The Modelview Matrix
	gl.glLoadIdentity();                // Reset The Modelview Matrix

  }

}
