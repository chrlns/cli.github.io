package test;

import javax.swing.JFrame;

public class Test2D
  extends JFrame
{
  public static final long serialVersionUID = 0;
  
  /**
   * @param args
   */
  public static void main(String[] args)
  {
    new Test2D().setVisible(true);
  }
  
  public Test2D()
  {
    setSize(640, 480);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    setContentPane(new My3DComponent());
  }

}
