package test;

import hyzon.Component3D;
import java.awt.Color;
import java.awt.Graphics;

public class My3DComponent extends Component3D
{
  public static final long serialVersionUID = 0;
  
  public void paintComponent(Graphics g)
  {
    super.paintComponent(g);
    /*getRenderer().beginScene();
    
    g.setColor(Color.YELLOW);
    g.fillRect(40, 40, 100, 100);
    
    getRenderer().endScene();*/
  }
}
