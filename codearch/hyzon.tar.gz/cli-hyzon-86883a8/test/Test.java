package test;

import hyzon.Component3D;

import java.util.TimerTask;

import javax.swing.JFrame;

public class Test
  extends JFrame
{
  public static final long serialVersionUID = 0;
  
  class FPSTimer
    extends TimerTask
  {
    private JFrame parent;
    
    public FPSTimer(JFrame parent)
    {
      this.parent = parent;
    }
    
    public void run()
    {
      int fps = ((Component3D)parent.getContentPane().getComponent(0)).getFPS();
      this.parent.setTitle("Hyzon Software Renderer - " + fps + " fps");
    }
  }
   
  public Test()
  {
    My3DComponent comp3D = new My3DComponent();
    getContentPane().add(comp3D);
    setSize(400, 300);
    setVisible(true);
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    
    java.util.Timer timer = new java.util.Timer();
    timer.scheduleAtFixedRate(new FPSTimer(this), 0, 1000);
    /*
    Matrix4x4 m = new Matrix4x4(-1,10,9,1,-2,-3,3,0,1,-3,1,-1,0,0,4,-3);
    System.out.println(m.toString());
    System.out.println(m.getInvertible().toString());*/
  }
  
  public static void main(String[] args)
  {
    /*hyzon.low.Math.test();
    
    float a = 0.45f;
    float b = 12.33234234f;
    
    float c = 0, d = 0;
    
    long t = System.nanoTime();
    //for(int n = 0; n < 100; n++)
    {
      c = a * b;
    }
    t = System.nanoTime() - t;
    
    long tt = System.nanoTime();
    //for(int n = 0; n < 100; n++)
    {
      d = hyzon.low.Math.multiply(a, b);
    }
    tt = System.nanoTime() - tt;
    
    System.out.println(c + "(" + t + ")" + d + "(" + tt + ")");
    */
    new Test();
  }
}