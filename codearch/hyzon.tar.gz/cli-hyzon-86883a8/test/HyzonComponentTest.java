/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package test;

import hyzon.HyzonComponent;
import hyzon.math.Vector3;
import hyzon.opengl.GLEventAdapter;
import hyzon.scene.Scene;
import hyzon.scene.animator.AnimatorEvent;
import hyzon.scene.animator.AnimatorListener;
import hyzon.scene.animator.LinearAnimator;
import javax.swing.JFrame;

/**
 *
 * @author chris
 */
public class HyzonComponentTest extends JFrame
{
  
  private HyzonComponent hc = new HyzonComponent();
  
  public HyzonComponentTest()
  {
    setTitle("HyzonComponentTest");
    setDefaultCloseOperation(EXIT_ON_CLOSE);
    
    getContentPane().add(hc);
    setSize(600, 400);
  }
  
  public static void main(String[] args)
  {
    final HyzonComponentTest hct = new HyzonComponentTest();
    final Scene myScene = new Scene(hct.hc);
    final CubeNode cube = new CubeNode();
    cube.setPosition(new Vector3(0, 0, -5));
    myScene.addChild(cube);
    
    LinearAnimator anim = new LinearAnimator(
      new Vector3(0,0,0), new Vector3(900, 800, 700), 18000);
    anim.addAnimatorListener(new AnimatorListener() {

      public void animatorStep(AnimatorEvent event)
      {
        cube.setRotation(event.getValue());
      }
    });
    
    
    hct.setVisible(true);
    hct.hc.addGLEventListener(new GLEventAdapter(myScene));
    anim.start();
  }
}
