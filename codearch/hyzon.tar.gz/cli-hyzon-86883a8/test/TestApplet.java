package test;

import javax.swing.*;

public class TestApplet extends JApplet
{
  public static final long serialVersionUID = 0;
}
