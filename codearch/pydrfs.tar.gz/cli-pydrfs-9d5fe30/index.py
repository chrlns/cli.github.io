import pickle

class Index:

  def __init__:
    return
