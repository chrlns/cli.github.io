#!/usr/bin/python

from twisted.internet.protocol import Factory
from twisted.internet import reactor
from twisted.protocols.basic import LineReceiver
from twisted.web import server, resource, static

class StaticDispatcher(resource.Resource):

  def getChild(self, name, request):
    return static.File(request.path[1:], defaultType="multipart/binary")

def startWebServer():
  site = server.Site(StaticDispatcher())
  reactor.listenTCP(8000, site)
  reactor.run()

def main():
  startWebServer()

if __name__ == '__main__':
  main()
