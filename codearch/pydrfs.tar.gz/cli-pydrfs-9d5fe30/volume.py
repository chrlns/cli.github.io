class Volume:

  def __init__():
    return
