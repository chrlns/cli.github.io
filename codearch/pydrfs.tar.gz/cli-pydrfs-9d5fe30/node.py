class Node:

  def __init__(name, host, hosts):
    return
