/*
 *  Copyright 2008 Christian Lins <christian.lins@web.de>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package clhttpd;

/**
 * Entrypoint class of the clhttpd server. This class starts the
 * listener thread.
 * @author Christian Lins (christian.lins@web.de)
 */
public class Server
{
  public static final String VERSION = "clhttpd/0.1";
  
  public static String DOCUMENT_ROOT = "/var/www/";
  public static int    PORT          = 8080;
  
  /**
   * This method is called on startup.
   * The arguments can have the following values:
   * <ul>
   *    <li>--docroot DOCUMENT_ROOT (Default: /var/www/)</li>
   *    <li>--port PORT (Default: 8080, for lower port clhttpd needs superuser rights)</li>
   *    <li>--queue LENGTH_OF_WORKING_QUEUE (Default: 1, should be at least as high as --worker)</li>
   *    <li>--worker NUMBER_OF_WORKING_THREADS (Default: 1)</li>
   * </ul>
   * @param args
   */
  public static void main(String[] args)
    throws InterruptedException
  {
    int queueLength = 5;
    int numWorkers  = 1;
    
    // Interpret configuration parameter
    for(int n = 0; n < args.length; n++)
    {
      if(args[n].equals("--docroot"))
        DOCUMENT_ROOT = args[n + 1];
      else if(args[n].equals("--port"))
        PORT = Integer.parseInt(args[n + 1]);
      else if(args[n].equals("--queue"))
        queueLength = Integer.parseInt(args[n + 1]);
      else if(args[n].equals("--worker"))
        numWorkers = Integer.parseInt(args[n + 1]);
    }
    
    // Start server listener
    Listener listener = new Listener(queueLength, numWorkers);
    listener.start();
    listener.join();
  }

}
