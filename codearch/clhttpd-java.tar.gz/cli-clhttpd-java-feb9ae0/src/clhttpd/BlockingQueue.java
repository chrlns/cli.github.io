/*
 *  Copyright 2008 Christian Lins <christian.lins@web.de>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package clhttpd;

/**
 * Since Java 1.4 does not provide a BlockingQueue, I have written
 * this one by myself.
 * This queue is created with a specific size. If this size is reached 
 * through several calles to put(), the queue will block all further
 * put() calls until at least one element is removed from the queue using 
 * the take() method.
 * The same happens on a queue underun.
 * @author Christian Lins (christian.lins@web.de)
 */
public class BlockingQueue
{ 
  private int      pos      = 0;
  private int      size     = 0;
  private Object[] value    = null;
  
  /**
   * Creates a new BlockingQueue with the specified capacity.
   * Negative values will cause and exception wheras zero is allowed
   * but does not make any sense because both put() and take() will
   * block indefinitely.
   * @param capacity
   */
  public BlockingQueue(int capacity)
  {
    this.value = new Object[capacity];
  }
  
  /**
   * @return The maximum capacity of this queue.
   */
  public synchronized int capacity()
  {
    return this.value.length;
  }
  
  /**
   * Adds an object to the end of the queue. If the queue has reached
   * its maximum capacity this method blocks until another thread has
   * removed at least one element from the queue.
   * @param obj
   * @throws InterruptedException
   */
  public synchronized void put(Object obj)
    throws InterruptedException
  {
    if(size >= value.length)
    {
      wait();
      put(obj);
    }
    else
    {
      synchronized(this)
      {
        int ppos = (pos + size) % value.length;
        value[ppos] = obj;
        
        size++;
        notifyAll();
      }
    }
  }
  
  /**
   * Returns the number of elements that are currently stored in this
   * queue.
   */
  public synchronized int size()
  {
    return size;
  }
  
  /**
   * Removes and returns the object at the head of the queue.
   * If the queue is empty this method blocks until another
   * thread has filled the queue with at least one element.
   * @return
   * @throws InterruptedException
   */
  public synchronized Object take()
    throws InterruptedException
  {
    if(size <= 0)
    {
      wait();
      return take();
    }
    else
    {
      synchronized(this)
      {
        Object obj  = value[pos];
        value[pos] = null;
        
        size--;
        pos++;
        pos %= value.length;
        
        notifyAll();        
        return obj;
      }
    }
  }
}
