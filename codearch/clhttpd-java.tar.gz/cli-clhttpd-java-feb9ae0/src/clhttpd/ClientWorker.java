/*
 *  Copyright 2008 Christian Lins <christian.lins@web.de>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package clhttpd;

import java.io.BufferedReader;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;

/**
 * This thread retrieves connected socket from the input queue
 * and answers to their requests.
 * @author Christian Lins (christian.lins@web.de)
 */
public class ClientWorker extends Thread
{  
  private BlockingQueue queue = null;
  
  private static void httpError(int no, BufferedReader in, BufferedOutputStream out)
    throws IOException
  {
    String errorStr = "Error " + no + "\n";
    
    out.write(("HTTP/1.1 " + no + " Error\n").getBytes());
    out.write(("Server: " + Server.VERSION + "\n").getBytes());
    out.write("Content-Type: text/html; charset=utf-8\n".getBytes());
    out.write("Connection: close\n".getBytes());
    out.write(("Content-Length: " + errorStr.length() + "\n").getBytes());
    out.write("\n".getBytes());
    out.write(errorStr.getBytes());
  }
  
  private static void httpGetDir(File dir, BufferedOutputStream out)
    throws IOException
  {
    StringBuilder buffer = new StringBuilder();
    File[]        files  = dir.listFiles(new FileFilter()
    {
      public boolean accept(File file)
      {
        if(file.getName().startsWith("."))
          return false;
        else
          return true;
      }
    });
    
    buffer.append("<html><head></head>");
    buffer.append("<body>");
    buffer.append("<h1>Index of ");
    buffer.append(dir.getName());
    buffer.append("</h1>");
    
    for(int n = 0; n < files.length; n++)
    {
      String link = files[n].toString().substring(Server.DOCUMENT_ROOT.length());
      buffer.append("<a href=\"");
      buffer.append(link);
      buffer.append("\">");
      buffer.append(files[n].getName());
      buffer.append("</a>");
      buffer.append("</br>");
    }
    
    buffer.append("</body></html>");
    
    String outStr = buffer.toString();
    
    out.write("HTTP/1.1 200 Ok\n".getBytes());
    out.write(("Server: " + Server.VERSION + "\n").getBytes());
    out.write("Content-Type: text/html; charset=utf-8\n".getBytes());
    out.write("Connection: close\n".getBytes());
    out.write(("Content-Length: " + outStr.length() + "\n").getBytes());
    out.write("\n".getBytes());
    out.write(outStr.getBytes());
  }
  
  private static void httpGet(String httpMethod, BufferedReader in, BufferedOutputStream out)
    throws IOException
  {
    String[] meth     = httpMethod.split(" ");
    String   fileName = meth[1];
    while(fileName.startsWith("/") || fileName.startsWith("."))
      fileName = fileName.substring(1);
    
    fileName = Server.DOCUMENT_ROOT + fileName;
    
    File file = new File(fileName);
    if(file.isDirectory())
    {
      if(new File(fileName + "index.html").exists())
        file = new File(fileName + "index.html");
      else
      {
        httpGetDir(file, out);
        return;
      }
    }
    
    if(!file.exists())
    {
      httpError(404, in, out);
      return;
    }
    
    FileInputStream fileInput;
    try
    {
       fileInput = new FileInputStream(file);
    }
    catch(IOException ex)
    {
      httpError(404, in, out);
      return;
    }
    
    out.write("HTTP/1.1 200 Ok\n".getBytes());
    out.write(("Server: " + Server.VERSION + "\n").getBytes());
    out.write("Connection: close\n".getBytes());
    out.write(("Content-Length: " + file.length() + "\n").getBytes());
    out.write("Content-Type: text/html\n".getBytes());
    out.write("\n".getBytes());
    
    byte[] buffer = new byte[128];
    for(;;)
    {
      int len = fileInput.read(buffer);
      if(len == -1)
        break;
      out.write(buffer, 0, len);
    }
  }
  
  public ClientWorker(BlockingQueue queue)
  {
    setName("Worker");
    
    this.queue = queue;
  }
  
  public void run()
  {
    for(;;)
    {
      try
      {
        Socket socket = (Socket)this.queue.take();   
        socket.setSoTimeout(30000);
        socket.setTcpNoDelay(true);
       
        // Buffered streams are necessary to prevent broken pipes
        BufferedReader       in  = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        BufferedOutputStream out = new BufferedOutputStream(socket.getOutputStream());
        
        String httpMethod = in.readLine();
        if(httpMethod.startsWith("GET"))
          httpGet(httpMethod, in, out);
        else
          httpError(500, in, out);
        
        socket.shutdownInput();
        
        out.flush(); // Absolutely necessary

        socket.shutdownOutput();
        socket.close();
      }
      catch(Exception ex)
      {
        ex.printStackTrace();
      }
    }
  }
}
