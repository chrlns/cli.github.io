/*
 *  Copyright 2008 Christian Lins <christian.lins@web.de>
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation, either version 3 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package clhttpd;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * This thread listens for incoming TCP-connections on the
 * specified port.
 * @author Christian Lins (christian.lins@web.de)
 */
public class Listener extends Thread
{ 
  private BlockingQueue  queue   = null;
  private ClientWorker[] workers = null;
  
  public Listener(int queueLength, int numWorkers)
  {
    setName("Listener");
    
    this.queue   = new BlockingQueue(queueLength);
    this.workers = new ClientWorker[numWorkers];
  }
  
  public void run()
  {
    // Start working thread(s)...
    for(int n = 0; n < workers.length; n++)
    {
      workers[n] = new ClientWorker(queue);
      workers[n].setDaemon(true);
      workers[n].start();
    }
    
    try
    {
      ServerSocket serverSocket = new ServerSocket(Server.PORT);
      System.out.println("[clhttpd] HTTP Daemon listening on port " + Server.PORT);
    
      for(;;)
      {
        Socket socket = serverSocket.accept();
        //System.out.println("[clhttpd] Connection accepted from " + socket.getRemoteSocketAddress());
        queue.put(socket);
      }
    }
    catch(IOException ex)
    {
      ex.printStackTrace();
    }
    catch(InterruptedException ex)
    {
      ex.printStackTrace();
    }
    System.out.println("[clhttpd] HTTP Daemon stopping...");
  }
  
}
