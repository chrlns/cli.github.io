package test;

import clhttpd.BlockingQueue;

public class QueueTest
{
  static BlockingQueue queue = new BlockingQueue(9);
  
  static class PutThread extends Thread
  {
    public void run()
    {
      for(int n = 1; n <= 100; n++)
      {
        try
        {
          queue.put(new Integer(n));
          System.out.println("Put: " + new Integer(n));
          System.out.flush();
        }
        catch(Exception e)
        {
          System.err.println(e.getLocalizedMessage());
        }
      }
    }
  }
  
  static class TakeThread extends Thread
  {
    public void run()
    {
      for(int n = 0; n < 100; n++)
      {
        try
        {
          System.out.println("Take: " + queue.take());
          System.out.flush();
        }
        catch(Exception e)
        {
          System.err.println(e.getLocalizedMessage());
        }
      }
    }
  }
  
  /**
   * @param args
   */
  public static void main(String[] args)
    throws Exception
  {
    Thread t1 = new PutThread();
    Thread t2 = new TakeThread();
    
    t1.start();
    t2.start();
    
    t1.join();
    t2.join();
    
    System.out.flush();
    System.out.println("Queue size: " + queue.size());
  }

}
