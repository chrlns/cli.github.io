<?
/*
  Copyright (C) 2006 Afoot Auction System Developers named below.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 

  Authors:
  - Christian Lins <christian.lins@fh-osnabrueck.de>
*/

  require_once("CDatabase.php");

// Diese Klasse liest die ben�tigten Navigationsmen�eintr�ge aus der Datenbank
  class CMenu
  {
    var $Database;
    var $System;

    function CMenu($system)
    {
      $this->Database = new CDatabase();
      $this->System = $system;
    }

    function GetEntries()
    {
      $this->Database->Query("SELECT * FROM afoot_menu WHERE hidefor != " . $this->System->Authentification . " ORDER BY position ASC");

      while($q = $this->Database->GetResultArray())
      {
        echo "\n<menuentry class=\"menu\" url=\"" . $q['name'] . "\" text=\"" . $q['title'] . "\"/>";
      }
    }
  }
?>