<?
/*
  Copyright (C) 2006 Afoot Auction System Developers named below.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 

  Authors:
  - Christian Lins <christian.lins@fh-osnabrueck.de>
*/

require_once("CDatabase.php");

class CPageSell
{
  var $Database;
  var $System;

  function CPageSell($system)
  {
    $this->Database = new CDatabase();
    $this->System = $system;
  }

  function Dispose()
  {
    $this->Database->Dispose();
  }

  function GetContent()
  {
    $this->Database->Query("SELECT * FROM afoot_page WHERE name = 'sell'");

    $result = $this->Database->GetResultArray();
    $code = $result['code'];

    $this->Database->Query("SELECT * FROM afoot_category ORDER BY caption ASC");

    $categories = "<option>Bitte w�hlen</option>";
    while($q = $this->Database->GetResultArray())
      $categories .= "<option value=\"" . $q['id'] . "\">" . $q['caption'] . "</option>\n";

    $categories = "<select name=\"auction_category\" text=\"Kategorie\">" . $categories . "</select>";

    $code = str_replace("<% FORM_CATEGORIES %>", $categories, $code);

    echo $code;
  }
}

?>