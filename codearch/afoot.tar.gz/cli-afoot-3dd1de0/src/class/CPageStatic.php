<?
/*
  Copyright (C) 2006 Afoot Auction System Developers named below.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 

  Authors:
  - Christian Lins <christian.lins@fh-osnabrueck.de>
*/

require_once("CDatabase.php");
require_once("CSystem.php");

  class CPageStatic
	{
		var $Database;
		var $System;
		
		function CPageStatic($system)
		{
			$this->Database = new CDatabase();
			$this->System = $system;
		}
		
		function GetContent()
		{	
		  $file = file("content/" . $this->System->Content . ".xml");
		  if(empty($file))
			  echo "<text>Die gew�nschte Seite " . $this->System->Content . " konnte leider nicht gefunden werden!</text>";
			else
			{
				if($this->System->Authentification < $result['authentification'])
				{
				  $file = file("content/auth_requ.xml");
				}
					
				foreach($file as $line)
				  echo $line;
			}
    }
		
		function Dispose()
		{
				$this->Database->Dispose();
		}
  }
		
?>