<?
/*
  Copyright (C) 2006 Afoot Auction System Developers named below.

  This program is free software; you can redistribute it and/or modify
  it under the terms of the GNU General Public License as published by
  the Free Software Foundation; either version 2 of the License, or
  (at your option) any later version.

  This program is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  GNU General Public License for more details.

  You should have received a copy of the GNU General Public License
  along with this program; if not, write to the Free Software
  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. 

  Authors:
  - Christian Lins <christian.lins@fh-osnabrueck.de>
*/

require_once("CCategoryList.php");
require_once("CMenu.php");
require_once("CPageDynamic.php");
require_once("CPageSell.php");
require_once("CPageStatic.php");
require_once("CPageAuction.php");
require_once("CPageList.php");

// Diese Klasse stellt Funktionen f�r das Bereitstellen des Seiteninhalts bereit.
class CPage
{
  var $System;
	var $CategoryList;
  var $ContentProvider;
  var $Menu;

    function CPage($system)
    {
		  $this->CategoryList = new CCategoryList();
      $this->Menu = new CMenu($system);
      $this->System = $system;

      if($this->System->Content == "category")
        $this->ContentProvider = new CPageList($system);
      else if($this->System->Content == "auction")
        $this->ContentProvider = new CPageAuction($system);
      else if($this->System->Content == "sell")
        $this->ContentProvider = new CPageSell($system);
      else if(strstr($this->System->Content, "_exec") != false)
        $this->ContentProvider = new CPageDynamic($system);
      else
        $this->ContentProvider = new CPageStatic($system);
    }

    function GetContent()
    {
      if(!empty($this->System->Session))
        echo "<text>Sie sind eingeloggt als " . $this->System->Username . "!</text>";

				  echo "<table>";
				  echo "<row>";
				
				  echo "<column>";
				
			    // Categorieanzeige auf der linken Seite
			    $this->CategoryList->GetCategories(0);
				
				  echo "</column>";
				  echo "<column>";
					
      $this->ContentProvider->GetContent();
							  echo "</column>";
				  echo "</row>";
				  echo "</table>";
    }

    function Dispose()
    {
		  $this->CategoryList->Dispose();
      $this->ContentProvider->Dispose();
    }
  }
?>